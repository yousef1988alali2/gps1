package com.yousef.gpsbridge;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    // الحالة اللي تتشارك بين الخدمة والشاشة
    static volatile String sBt = "غير متصل";
    static volatile String sLoc = "-";
    static volatile String sHdg = "-";
    static volatile String sSpd = "-";
    static volatile String sTx = "-";
    static volatile boolean sRunning = false;

    private TextView tv;
    private Button btn;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ui = new Runnable() {
        @Override public void run() {
            tv.setText("الخدمة: " + (sRunning ? "شغالة" : "واقفة")
                    + "\nالبلوتوث: " + sBt
                    + "\nالموقع: " + sLoc
                    + "\nالاتجاه: " + sHdg
                    + "\nالسرعة: " + sSpd
                    + "\nآخر إرسال: " + sTx);
            btn.setText(sRunning ? "إيقاف" : "ابدأ");
            h.postDelayed(this, 500);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 96, 48, 48);
        root.setBackgroundColor(Color.rgb(12, 12, 16));

        TextView title = new TextView(this);
        title.setText("جسر الموقع لجهاز الصور");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        btn = new Button(this);
        btn.setTextSize(20);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 180);
        lp.topMargin = 64;
        lp.bottomMargin = 64;
        btn.setLayoutParams(lp);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (sRunning) {
                    stopService(new Intent(MainActivity.this, Bridge.class));
                    sRunning = false;
                } else {
                    askAndStart();
                }
            }
        });
        root.addView(btn);

        tv = new TextView(this);
        tv.setTextSize(18);
        tv.setLineSpacing(0, 1.4f);
        tv.setTextColor(Color.rgb(220, 220, 230));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(tv);

        TextView note = new TextView(this);
        note.setText("\nقبل لا تبدأ: سكّر أي تطبيق بلوتوث ثاني متصل بالإطار، وشغّل الموقع (GPS)."
                + " للأفضل، استثنِ التطبيق من توفير البطارية.");
        note.setTextSize(14);
        note.setTextColor(Color.rgb(150, 150, 160));
        note.setTextDirection(View.TEXT_DIRECTION_RTL);
        root.addView(note);

        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        h.post(ui);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(ui);
    }

    private void askAndStart() {
        ArrayList<String> need = new ArrayList<>();
        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        ArrayList<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            startBridge();
        } else {
            requestPermissions(missing.toArray(new String[0]), 7);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= 31) {
            ok = ok && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        if (ok) startBridge();
        else sBt = "لازم توافق على الأذونات";
    }

    private void startBridge() {
        Intent i = new Intent(this, Bridge.class);
        startForegroundService(i);
        sRunning = true;
    }

    // ------------------------------------------------------------------
    // الخدمة اللي تشتغل بالخلفية: موقع + اتجاه + إرسال بلوتوث
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    public static class Bridge extends Service {
        static final UUID NUS = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
        static final String CH = "gpsbridge";

        private final Handler h = new Handler(Looper.getMainLooper());
        private LocationManager lm;
        private SensorManager sm;
        private BluetoothAdapter ad;
        private BluetoothLeScanner scanner;
        private volatile BluetoothGatt gatt;
        private volatile BluetoothGattCharacteristic rx;
        private volatile boolean ready = false;
        private volatile boolean discStarted = false;
        private boolean scanning = false;
        private boolean started = false;
        private boolean dead = false;
        private PowerManager.WakeLock wl;

        private Location loc;
        private long locAt = 0;
        private float compass = -1f;

        @Override public IBinder onBind(Intent i) { return null; }

        @Override public int onStartCommand(Intent in, int flags, int id) {
            if (!started) {
                started = true;
                dead = false;
                goForeground();
                initAll();
            }
            return START_STICKY;
        }

        private void goForeground() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CH, "جسر الموقع", NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("جسر الإطار شغال")
                    .setContentText("يرسل الموقع والاتجاه للإطار")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else {
                startForeground(1, n);
            }
        }

        private void initAll() {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gpsbridge:wl");
            wl.acquire();

            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            try {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0,
                            ll, Looper.getMainLooper());
                } else {
                    sLoc = "شغّل الموقع GPS";
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0,
                            ll, Looper.getMainLooper());
                }
            } catch (Exception e) {
                sLoc = "خطأ: " + e.getMessage();
            }

            sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (rv != null) {
                sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
            } else {
                sHdg = "ما في حساس اتجاه";
            }

            BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            ad = bm.getAdapter();
            if (ad == null || !ad.isEnabled()) {
                sBt = "شغّل البلوتوث";
            }
            startScan();
            h.postDelayed(tick, 1000);
        }

        // ---------------- الموقع ----------------
        private final LocationListener ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                // نفضّل GPS على الشبكة إذا كان GPS حديث
                if (loc != null && LocationManager.GPS_PROVIDER.equals(loc.getProvider())
                        && !LocationManager.GPS_PROVIDER.equals(l.getProvider())
                        && System.currentTimeMillis() - locAt < 5000) {
                    return;
                }
                loc = l;
                locAt = System.currentTimeMillis();
                sLoc = String.format(Locale.US, "%.4f , %.4f", l.getLatitude(), l.getLongitude());
            }
            @Override public void onStatusChanged(String p, int s, Bundle e) { }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
        };

        // ---------------- البوصلة ----------------
        private final SensorEventListener sl = new SensorEventListener() {
            final float[] R = new float[9];
            final float[] R2 = new float[9];
            final float[] o = new float[3];
            float sx = 0f, sy = 0f;
            boolean has = false;

            @Override public void onSensorChanged(SensorEvent e) {
                SensorManager.getRotationMatrixFromVector(R, e.values);
                float[] use = R;
                // الجوال واقف (مثبت بالسيارة): نستخدم اتجاه الكاميرا الخلفية
                if (Math.abs(R[8]) < 0.7f) {
                    SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_X,
                            SensorManager.AXIS_Z, R2);
                    use = R2;
                }
                SensorManager.getOrientation(use, o);
                double az = Math.toDegrees(o[0]);
                if (loc != null) {
                    GeomagneticField g = new GeomagneticField((float) loc.getLatitude(),
                            (float) loc.getLongitude(), (float) loc.getAltitude(),
                            System.currentTimeMillis());
                    az += g.getDeclination();
                }
                double r = Math.toRadians(az);
                float cx = (float) Math.cos(r), cy = (float) Math.sin(r);
                if (!has) { sx = cx; sy = cy; has = true; }
                else { sx = sx * 0.85f + cx * 0.15f; sy = sy * 0.85f + cy * 0.15f; }
                compass = (float) ((Math.toDegrees(Math.atan2(sy, sx)) + 360.0) % 360.0);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) { }
        };

        // ---------------- البلوتوث ----------------
        private void startScan() {
            if (dead) return;
            try {
                if (ad == null || !ad.isEnabled()) {
                    sBt = "شغّل البلوتوث";
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                scanner = ad.getBluetoothLeScanner();
                if (scanner == null) {
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                if (scanning) return;
                scanning = true;
                sBt = "يدور على الإطار...";
                scanner.startScan(scb);
            } catch (Exception e) {
                scanning = false;
                sBt = "خطأ بحث: " + e.getMessage();
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        }

        private void stopScan() {
            try {
                if (scanning && scanner != null) scanner.stopScan(scb);
            } catch (Exception ignored) { }
            scanning = false;
        }

        private final ScanCallback scb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult r) {
                if (gatt != null || dead) return;
                String n = null;
                ScanRecord sr = r.getScanRecord();
                if (sr != null) n = sr.getDeviceName();
                if (n == null) n = r.getDevice().getName();
                if (n != null && n.startsWith("Photo")) {
                    stopScan();
                    sBt = "يتصل...";
                    discStarted = false;
                    gatt = r.getDevice().connectGatt(Bridge.this, false, cb,
                            BluetoothDevice.TRANSPORT_LE);
                }
            }
            @Override public void onScanFailed(int err) {
                scanning = false;
                sBt = "فشل البحث (" + err + ")";
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        };

        private void startDiscovery(BluetoothGatt g) {
            if (discStarted) return;
            discStarted = true;
            g.discoverServices();
        }

        private final BluetoothGattCallback cb = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(final BluetoothGatt g, int status, int ns) {
                if (ns == BluetoothGatt.STATE_CONNECTED) {
                    sBt = "متصل (يجهز)";
                    if (!g.requestMtu(185)) startDiscovery(g);
                    h.postDelayed(new Runnable() {
                        @Override public void run() { startDiscovery(g); }
                    }, 2500);
                } else {
                    ready = false;
                    rx = null;
                    gatt = null;
                    try { g.close(); } catch (Exception ignored) { }
                    sBt = "انقطع، يعيد المحاولة";
                    if (!dead) {
                        h.postDelayed(new Runnable() {
                            @Override public void run() { startScan(); }
                        }, 3000);
                    }
                }
            }

            @Override public void onMtuChanged(BluetoothGatt g, int mtu, int status) {
                startDiscovery(g);
            }

            @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
                BluetoothGattService s = g.getService(NUS);
                BluetoothGattCharacteristic c = (s == null) ? null : s.getCharacteristic(RX);
                if (c != null) {
                    c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                    rx = c;
                    ready = true;
                    sBt = "متصل";
                } else {
                    sBt = "خدمة الإطار مو موجودة";
                    g.disconnect();
                }
            }
        };

        // ---------------- الإرسال كل ثانية ----------------
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                try {
                    Location l = loc;
                    BluetoothGatt g = gatt;
                    BluetoothGattCharacteristic c = rx;
                    long age = System.currentTimeMillis() - locAt;
                    if (l != null) {
                        float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                        int hdg = -1;
                        if (kmh >= 7f && l.hasBearing()) hdg = Math.round(l.getBearing()) % 360;
                        else if (compass >= 0f) hdg = Math.round(compass) % 360;
                        sHdg = hdg < 0 ? "-" : hdg + "°";
                        sSpd = Math.round(kmh) + " km/h";
                        if (age > 15000) sLoc = "الموقع قديم، انتظر GPS";
                        if (ready && g != null && c != null && age < 15000) {
                            String line = String.format(Locale.US, "gps %.4f %.4f %d %d",
                                    l.getLatitude(), l.getLongitude(), hdg, Math.round(kmh));
                            byte[] b = line.getBytes(StandardCharsets.US_ASCII);
                            if (Build.VERSION.SDK_INT >= 33) {
                                g.writeCharacteristic(c, b,
                                        BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                            } else {
                                c.setValue(b);
                                g.writeCharacteristic(c);
                            }
                            sTx = new java.text.SimpleDateFormat("HH:mm:ss", Locale.US)
                                    .format(new java.util.Date());
                        }
                    } else if (!sLoc.startsWith("شغّل") && !sLoc.startsWith("خطأ")) {
                        sLoc = "ينتظر إشارة GPS...";
                    }
                } catch (Exception ignored) { }
                if (!dead) h.postDelayed(this, 1000);
            }
        };

        @Override public void onDestroy() {
            dead = true;
            started = false;
            h.removeCallbacksAndMessages(null);
            try { lm.removeUpdates(ll); } catch (Exception ignored) { }
            try { sm.unregisterListener(sl); } catch (Exception ignored) { }
            stopScan();
            try {
                BluetoothGatt g = gatt;
                if (g != null) { g.disconnect(); g.close(); }
            } catch (Exception ignored) { }
            gatt = null;
            ready = false;
            try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
            sRunning = false;
            sBt = "غير متصل";
            super.onDestroy();
        }
    }
}
