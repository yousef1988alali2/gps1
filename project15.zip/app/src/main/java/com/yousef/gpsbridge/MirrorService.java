package com.yousef.gpsbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;

/** ميرور الشاشة: يلقط شاشة الجوال ويرسلها JPEG للإطار بالواي فاي (POST على /mirror) */
public class MirrorService extends Service {
    static volatile boolean running = false;
    static volatile String status = "";
    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader ir;
    private Thread worker;
    private volatile boolean stop = false;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        if (in == null || in.getBooleanExtra("stop", false)) { shutdown(); stopSelf(); return START_NOT_STICKY; }
        final int code = in.getIntExtra("code", 0);
        final Intent data = (Intent) in.getParcelableExtra("data");
        final String host = in.getStringExtra("host");
        final boolean fill = in.getBooleanExtra("fill", true);
        final int quality = in.getIntExtra("q", 55);
        goForeground();
        shutdown();
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mp = mpm.getMediaProjection(code, data);
        if (mp == null) { status = "ما اشتغل التقاط الشاشة"; stopSelf(); return START_NOT_STICKY; }
        mp.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stop = true; running = false; }
        }, null);
        int dw = getResources().getDisplayMetrics().widthPixels, dh = getResources().getDisplayMetrics().heightPixels;
        if (dw <= 0 || dh <= 0) { dw = 1080; dh = 2340; }
        float sc = 600f / Math.max(dw, dh);
        final int w = Math.max(64, (int) (dw * sc)), h = Math.max(64, (int) (dh * sc));
        ir = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        vd = mp.createVirtualDisplay("frameMirror", w, h, getResources().getDisplayMetrics().densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.getSurface(), null, null);
        stop = false;
        running = true;
        status = "شغّال";
        worker = new Thread(new Runnable() {
            @Override public void run() { loop(host, w, h, fill, quality); }
        });
        worker.start();
        return START_NOT_STICKY;
    }

    private void loop(String host, int w, int h, boolean fill, int quality) {
        final int S = 466;
        long last = 0;
        int fails = 0;
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        while (!stop) {
            long now = System.currentTimeMillis();
            if (now - last < 90) { try { Thread.sleep(15); } catch (InterruptedException e) { break; } continue; }
            Image img = null;
            try { img = ir.acquireLatestImage(); } catch (Exception e) { img = null; }
            if (img == null) { try { Thread.sleep(20); } catch (InterruptedException e) { break; } continue; }
            Bitmap full = null;
            try {
                Image.Plane pl = img.getPlanes()[0];
                ByteBuffer buf = pl.getBuffer();
                int rowStride = pl.getRowStride(), pix = pl.getPixelStride();
                int bw = rowStride / pix;
                full = Bitmap.createBitmap(bw, h, Bitmap.Config.ARGB_8888);
                full.copyPixelsFromBuffer(buf);
            } catch (Exception e) { full = null; }
            try { img.close(); } catch (Exception e) { }
            if (full == null) continue;
            cv.drawColor(0xFF000000);
            // نأخذ الجزء المرئي فقط (بدون حشوة الصف)
            Bitmap src = Bitmap.createBitmap(full, 0, 0, w, h);
            if (fill) {                        // نملأ الدائرة: نقص من النص
                int side = Math.min(w, h);
                Bitmap sq = Bitmap.createBitmap(src, (w - side) / 2, (h - side) / 2, side, side);
                Bitmap sc = Bitmap.createScaledBitmap(sq, S, S, true);
                cv.drawBitmap(sc, 0, 0, null);
            } else {                           // الصورة كاملة بحواف سودا
                float k = Math.min((float) S / w, (float) S / h);
                int tw = Math.max(1, (int) (w * k)), th = Math.max(1, (int) (h * k));
                Bitmap sc = Bitmap.createScaledBitmap(src, tw, th, true);
                cv.drawBitmap(sc, (S - tw) / 2f, (S - th) / 2f, null);
            }
            ByteArrayOutputStream bo = new ByteArrayOutputStream(60000);
            out.compress(Bitmap.CompressFormat.JPEG, quality, bo);
            int code = post(host, bo.toByteArray());
            last = now;
            if (code == 409) { status = "الإطار طلع من وضع الميرور"; break; }
            if (code != 200) { fails++; status = "ما وصل للإطار (" + code + ")"; if (fails > 25) break; }
            else { fails = 0; status = "شغّال"; }
        }
        running = false;
        stopSelf();
    }

    private int post(String host, byte[] jpg) {
        HttpURLConnection c = null;
        try {
            String b = "----mir" + System.currentTimeMillis();
            c = (HttpURLConnection) new URL("http://" + host + "/mirror").openConnection();
            c.setConnectTimeout(1500);
            c.setReadTimeout(2500);
            c.setDoOutput(true);
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + b);
            byte[] head = ("--" + b + "\r\nContent-Disposition: form-data; name=\"f\"; filename=\"m.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").getBytes("UTF-8");
            byte[] tail = ("\r\n--" + b + "--\r\n").getBytes("UTF-8");
            c.setFixedLengthStreamingMode(head.length + jpg.length + tail.length);
            OutputStream os = c.getOutputStream();
            os.write(head); os.write(jpg); os.write(tail); os.flush();
            int rc = c.getResponseCode();
            return rc;
        } catch (Exception e) {
            return -1;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void shutdown() {
        stop = true;
        try { if (vd != null) vd.release(); } catch (Exception e) { }
        try { if (ir != null) ir.close(); } catch (Exception e) { }
        try { if (mp != null) mp.stop(); } catch (Exception e) { }
        vd = null; ir = null; mp = null;
        running = false;
    }

    @Override public void onDestroy() { shutdown(); super.onDestroy(); }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("mirror", "ميرور الشاشة", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "mirror")
                .setContentTitle("ميرور الشاشة شغّال")
                .setContentText("يرسل شاشة الجوال للإطار")
                .setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(2, n);
    }
}
