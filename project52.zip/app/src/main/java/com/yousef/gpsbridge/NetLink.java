package com.yousef.gpsbridge;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;

/** إرسال أسطر الخريطة للإطار عبر الواي فاي (TCP منفذ 8266). إذا فشل نرجع للبلوتوث. */
final class NetLink {
    private NetLink() { }

    static volatile String ip = "";
    static volatile long okAt = 0;
    private static Socket sock;
    private static OutputStream os;
    private static long failAt = 0;

    static synchronized boolean send(List<String> lines) {
        try {
            if (ip.length() < 7 || ip.equals("0")) return false;
            if (sock == null || sock.isClosed() || !sock.isConnected()) {
                if (System.currentTimeMillis() - failAt < 8000) return false;
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, 8266), 2500);
                s.setTcpNoDelay(true);
                s.setSoTimeout(4000);
                sock = s;
                os = s.getOutputStream();
            }
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            os.write(sb.toString().getBytes("UTF-8"));
            os.flush();
            okAt = System.currentTimeMillis();
            return true;
        } catch (Exception e) {
            close();
            failAt = System.currentTimeMillis();
            return false;
        }
    }

    static synchronized void close() {
        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        sock = null; os = null;
    }
}
