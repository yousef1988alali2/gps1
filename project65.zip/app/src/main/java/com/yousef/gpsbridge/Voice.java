package com.yousef.gpsbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;

/** تحكم صوتي بالذكاء الصناعي: النص يروح لـ Claude، وهو يرجع أوامر للإطار أو جواب. المفتاح من إعدادات التطبيق بس. */
final class Voice {
    private Voice() { }

    interface Out {
        void say(String text);
        void cmd(String c);
        void note(String n);
        void status(String s);
    }

    static final String MODEL = "claude-haiku-5-5";

    private static final HashSet<String> OK = new HashSet<>(Arrays.asList(
            "photos", "analog", "digital", "pendulum", "weather", "gforce", "alali", "yousef", "names", "yousefen", "alalien", "mixen", "mixaren", "hypno", "mix",
            "ana", "dig", "wx", "hyp", "al", "ys", "ye", "ae", "next", "prev", "pause", "snext", "sprev", "bup", "bdn", "bright", "vol", "on", "off", "screen",
            "sc", "scores", "lg", "goal", "pm", "back", "colstep", "rot", "lfc", "ft", "battscr", "dots", "car", "cam", "camsnd", "flash", "malert", "list", "map", "rdr", "cmp", "spd", "pin", "unpin"));

    private static final String SYS =
            "أنت مساعد صوتي يتحكم بإطار صور دائري (ESP32) وتجيب على أسئلة كورة. المستخدم كويتي يتكلم بلهجته، فاكتب الرد بلهجة خليجية قصيرة جداً (جملة أو جملتين). "
            + "للتحكم بالإطار استخدم الأداة frame_command (تقدر تناديها أكثر من مرة بنفس الرد). الأوامر المسموحة (كلها حروف صغيرة):\n"
            + "- أوضاع: photos (صور), analog, digital (ساعات), pendulum, weather, gforce, alali, yousef, names, yousefen, alalien, mixen, mixaren, hypno, mix (ميكس)\n"
            + "- شكل داخل الوضع: ana N (ساعة عقارب 1-6), dig N (رقمية 1-3), wx N (طقس 1-5), hyp N (1-15), next/prev (الصورة أو الشكل اللي بعده/قبله), snext/sprev, pause\n"
            + "- لون الوضع الحالي: colstep next أو colstep prev\n"
            + "- المباريات: sc (يفتح النتائج), sc N (يفتح دوري رقم N), sc next/prev/back; الدوريات: 1 الإنجليزي 2 الإسباني 3 الإيطالي 4 الألماني 5 دوري الأبطال 6 الأوروبي (7 كأس الاتحاد 8 كأس الرابطة، ليفربول بس)\n"
            + "- تشغيل/إيقاف دوري من القائمة: lg N on أو lg N off\n"
            + "- تنبيهات: goal on/off, ft on/off, pm on/off (تذكير ما قبل المباراة), malert on/off, lfc on/off\n"
            + "- شاشة وصوت: bright N (10-100), bup, bdn, vol N (0-100), on, off, back\n"
            + "- غير ذلك: map, rot 0|90|180|270, cam on/off, dots on/off, car on/off\n"
            + "استخدم الأداة scoreboard لمعرفة مباريات اليوم ونتائجها (يعطيك id لكل مباراة) والأداة match_events لأحداث مباراة (أهداف وكروت وتبديلات). "
            + "لو سأل سؤال كورة جاوب منها بدون تخمين، ولو ما لقيت المعلومة قل إنك ما لقيتها. الأسئلة اللي ما لها علاقة بالإطار والكورة جاوبها باختصار. "
            + "لو ما قدرت تسوي شي (مثل البحث عن بنزينة) قل بصراحة إنه مو متوفر بعد. "
            + "لو استخدم المستخدم كلمة أو تعبير خاص يتكرر (اسم فريق بلهجته أو تفضيل ثابت) استخدم الأداة remember مرة وحدة لحفظها بجملة قصيرة. "
            + "لا تقترح شي مو مسموح ولا تخترع أوامر.";

    private static final String TOOLS =
            "[{\"name\":\"frame_command\",\"description\":\"أرسل أمر واحد للإطار من القائمة المسموحة\",\"input_schema\":{\"type\":\"object\",\"properties\":{\"cmd\":{\"type\":\"string\"}},\"required\":[\"cmd\"]}},"
            + "{\"name\":\"scoreboard\",\"description\":\"مباريات اليوم ونتائجها لدوري: 1 إنجليزي 2 إسباني 3 إيطالي 4 ألماني 5 أبطال 6 أوروبي\",\"input_schema\":{\"type\":\"object\",\"properties\":{\"league\":{\"type\":\"integer\"}},\"required\":[\"league\"]}},"
            + "{\"name\":\"match_events\",\"description\":\"أحداث مباراة (أهداف، كروت، تبديلات) بالـ id من scoreboard\",\"input_schema\":{\"type\":\"object\",\"properties\":{\"league\":{\"type\":\"integer\"},\"id\":{\"type\":\"string\"}},\"required\":[\"league\",\"id\"]}},"
            + "{\"name\":\"remember\",\"description\":\"احفظ ملاحظة قصيرة عن كلام المستخدم أو تفضيله\",\"input_schema\":{\"type\":\"object\",\"properties\":{\"note\":{\"type\":\"string\"}},\"required\":[\"note\"]}}]";

    static void run(final String key, final String said, final String mem, final Out o) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    o.status("⏳ أفكر...");
                    JSONArray msgs = new JSONArray();
                    msgs.put(new JSONObject().put("role", "user").put("content", said));
                    String sys = SYS + "\nتاريخ اليوم: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(new java.util.Date())
                            + (mem == null || mem.isEmpty() ? "" : "\nملاحظات عن المستخدم (تعلّمتها قبل):\n" + mem);
                    for (int round = 0; round < 6; round++) {
                        JSONObject body = new JSONObject();
                        body.put("model", MODEL).put("max_tokens", 700).put("system", sys).put("tools", new JSONArray(TOOLS)).put("messages", msgs);
                        JSONObject r = post(key, body.toString());
                        JSONArray ct = r.getJSONArray("content");
                        if (!"tool_use".equals(r.optString("stop_reason"))) {
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < ct.length(); i++) { JSONObject b = ct.getJSONObject(i); if ("text".equals(b.optString("type"))) sb.append(b.optString("text")); }
                            String t = sb.toString().trim();
                            o.say(t.isEmpty() ? "تم" : t);
                            return;
                        }
                        msgs.put(new JSONObject().put("role", "assistant").put("content", ct));
                        JSONArray res = new JSONArray();
                        for (int i = 0; i < ct.length(); i++) {
                            JSONObject b = ct.getJSONObject(i);
                            if (!"tool_use".equals(b.optString("type"))) continue;
                            String out;
                            try { out = tool(b.getString("name"), b.optJSONObject("input"), o); } catch (Exception e) { out = "خطأ: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()); }
                            res.put(new JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id")).put("content", out));
                        }
                        msgs.put(new JSONObject().put("role", "user").put("content", res));
                    }
                    o.say("طوّلت بالتفكير، جرب مرة ثانية");
                } catch (Exception e) {
                    o.say("صار خطأ: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
                }
            }
        }).start();
    }

    private static String tool(String name, JSONObject in, Out o) throws Exception {
        if (in == null) in = new JSONObject();
        if (name.equals("frame_command")) {
            String c = in.optString("cmd", "").trim().toLowerCase(java.util.Locale.ROOT);
            String w = c.split("\\s+")[0];
            if (c.isEmpty() || !OK.contains(w) || c.length() > 40) return "هذا الأمر غير مسموح";
            o.cmd(c);
            return "انرسل: " + c;
        }
        if (name.equals("remember")) { String n = in.optString("note", "").trim(); if (n.length() > 0) o.note(n); return "تم"; }
        int li = in.optInt("league", 1) - 1;
        if (li < 0 || li >= Feeds.SLUG.length) return "رقم الدوري غلط";
        if (name.equals("scoreboard")) return scoreboard(li);
        if (name.equals("match_events")) return events(li, in.optString("id", ""));
        return "أداة غير معروفة";
    }

    private static String scoreboard(int li) throws Exception {
        JSONObject j = new JSONObject(Feeds.get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + Feeds.SLUG[li] + "/scoreboard"));
        JSONArray ev = j.optJSONArray("events");
        if (ev == null || ev.length() == 0) return "ما فيه مباريات اليوم";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ev.length() && i < 20; i++) {
            JSONObject e = ev.getJSONObject(i);
            JSONObject comp = e.getJSONArray("competitions").getJSONObject(0);
            JSONArray cs = comp.getJSONArray("competitors");
            String h = "", a = "", hs = "", as = "";
            for (int k = 0; k < cs.length(); k++) {
                JSONObject c = cs.getJSONObject(k); String nm = c.getJSONObject("team").optString("displayName"), sc = c.optString("score", "");
                if ("home".equals(c.optString("homeAway"))) { h = nm; hs = sc; } else { a = nm; as = sc; }
            }
            JSONObject st = e.optJSONObject("status") == null ? new JSONObject() : e.getJSONObject("status");
            JSONObject ty = st.optJSONObject("type") == null ? new JSONObject() : st.getJSONObject("type");
            sb.append("id=").append(e.optString("id")).append(" | ").append(h).append(" ").append(hs).append("-").append(as).append(" ").append(a)
                    .append(" | ").append(ty.optString("detail", ty.optString("description"))).append(" | ").append(e.optString("date")).append("\n");
        }
        return sb.toString();
    }

    private static String events(int li, String id) throws Exception {
        if (id.isEmpty()) return "ما عطيتني id";
        JSONObject j = new JSONObject(Feeds.get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + Feeds.SLUG[li] + "/summary?event=" + id));
        JSONArray ke = j.optJSONArray("keyEvents");
        if (ke == null || ke.length() == 0) return "ما فيه أحداث للمباراة";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ke.length() && i < 60; i++) {
            JSONObject k = ke.getJSONObject(i);
            String min = k.optJSONObject("clock") == null ? "" : k.getJSONObject("clock").optString("displayValue");
            String ty = k.optJSONObject("type") == null ? "" : k.getJSONObject("type").optString("text");
            String tx = k.optString("text", k.optString("shortText"));
            if (tx.length() > 160) tx = tx.substring(0, 160);
            sb.append(min).append(" | ").append(ty).append(" | ").append(tx).append("\n");
        }
        return sb.toString();
    }

    private static JSONObject post(String key, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
        try {
            c.setConnectTimeout(10000);
            c.setReadTimeout(40000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("x-api-key", key);
            c.setRequestProperty("anthropic-version", "2023-06-01");
            c.setRequestProperty("content-type", "application/json");
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.close();
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder(); String ln;
            while ((ln = br.readLine()) != null) sb.append(ln);
            br.close();
            if (code >= 400) {
                String m = sb.toString();
                try { m = new JSONObject(m).getJSONObject("error").optString("message", m); } catch (Exception ignored) { }
                throw new Exception(code == 401 ? "المفتاح غلط أو منتهي" : "HTTP " + code + ": " + m);
            }
            return new JSONObject(sb.toString());
        } finally {
            c.disconnect();
        }
    }
}
