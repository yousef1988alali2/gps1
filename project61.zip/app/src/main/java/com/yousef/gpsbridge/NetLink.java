package com.yousef.gpsbridge;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;

/** إرسال أسطر الخريطة للإطار عبر الواي فاي (TCP منفذ 8266). إذا فشل نرجع للبلوتوث. */
final class NetLink {
    private NetLink() { }

    static volatile String ip = "";
    static volatile long okAt = 0;
    private static Socket sock;
    private static OutputStream os;
    private static long failAt = 0;

    static synchronized boolean send(List<String> lines) {
        try {
            if (ip.length() < 7 || ip.equals("0")) return false;
            if (sock == null || sock.isClosed() || !sock.isConnected()) {
                if (System.currentTimeMillis() - failAt < 8000) return false;
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, 8266), 2500);
                s.setTcpNoDelay(true);
                s.setSoTimeout(4000);
                sock = s;
                os = s.getOutputStream();
            }
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            os.write(sb.toString().getBytes("UTF-8"));
            os.flush();
            okAt = System.currentTimeMillis();
            return true;
        } catch (Exception e) {
            close();
            failAt = System.currentTimeMillis();
            return false;
        }
    }

    static synchronized void close() {
        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        sock = null; os = null;
    }

    interface Prog { void on(long done, long total); }

    private static String readLine(java.io.InputStream in, int ms) throws java.io.IOException {
        long end = System.currentTimeMillis() + ms; StringBuilder sb = new StringBuilder();
        while (System.currentTimeMillis() < end) {
            try {
                int c = in.read();
                if (c < 0) throw new java.io.IOException("انقطع الاتصال");
                if (c == '\n') { String t = sb.toString().trim(); if (t.length() > 0) return t; sb.setLength(0); }
                else sb.append((char) c);
            } catch (java.net.SocketTimeoutException e) { /* نكمل لين ينتهي الوقت */ }
        }
        throw new java.io.IOException("الإطار ما رد");
    }

    /** يرسل ملف للإطار عبر الواي فاي (نفس اتصال الخريطة). يرمي IOException مع السبب. */
    static synchronized void putFile(String name, java.io.File f, Prog pr) throws java.io.IOException {
        if (ip.length() < 7 || ip.equals("0")) throw new java.io.IOException("الإطار مو متصل بالواي فاي (ما عندي عنوانه)");
        try {
            if (sock == null || sock.isClosed() || !sock.isConnected()) {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, 8266), 3500);
                s.setTcpNoDelay(true);
                s.setSoTimeout(1500);
                sock = s; os = s.getOutputStream();
            }
            sock.setSoTimeout(1500);
            java.io.InputStream in = sock.getInputStream();
            while (in.available() > 0) in.read();
            long len = f.length();
            os.write(("fput " + name + " " + len + "\n").getBytes("UTF-8")); os.flush();
            String r = readLine(in, 10000);
            if (!r.startsWith("FPUT GO")) throw new java.io.IOException(r.startsWith("FPUT ERR space") ? "المساحة ما تكفي بالإطار" : r);
            java.io.FileInputStream fi = new java.io.FileInputStream(f);
            try {
                byte[] buf = new byte[4096]; long done = 0; int n;
                while ((n = fi.read(buf)) > 0) { os.write(buf, 0, n); done += n; if (pr != null) pr.on(done, len); }
                os.flush();
            } finally { fi.close(); }
            r = readLine(in, 25000);
            okAt = System.currentTimeMillis();
            if (!r.startsWith("FPUT OK")) throw new java.io.IOException(r);
        } catch (java.io.IOException e) {
            close(); throw e;
        }
    }
}
