package com.yousef.gpsbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** بحث الوجهات (من بيانات الخريطة المحملة) + حساب الطريق + تتبع التقدم وتوليد أوامر التوجيه للإطار. */
final class Nav {
    private Nav() { }

    // ====================================================================================
    //                                      البحث
    // ====================================================================================
    static final class Entry { String name, lower; int kind, sub, la, lo; }   // kind: 0 منطقة 1 شارع 2 مكان (sub=1..4) 3 معلم

    static volatile ArrayList<Entry> index = null;
    static volatile String indexState = "";
    private static volatile boolean building = false;

    /** أسماء مناطق شائعة بالعربي → الإنجليزي (OSM عندنا بأسماء إنجليزية) */
    private static final String[][] AR = {
        { "سلوى", "salwa" }, { "حولي", "hawally" }, { "السالمية", "salmiya" }, { "الجابرية", "jabriya" }, { "الرميثية", "rumaithiya" }, { "بيان", "bayan" },
        { "مشرف", "mishref" }, { "السلام", "salam" }, { "الشعب", "shaab" }, { "الشويخ", "shuwaikh" }, { "الفحيحيل", "fahaheel" }, { "المنقف", "mangaf" },
        { "أبوحليفة", "abu halifa" }, { "ابوحليفة", "abu halifa" }, { "الفنطاس", "fintas" }, { "العديلية", "adailiya" }, { "الروضة", "rawda" }, { "الخالدية", "khaldiya" },
        { "كيفان", "kaifan" }, { "القادسية", "qadsiya" }, { "قرطبة", "qurtuba" }, { "اليرموك", "yarmouk" }, { "الدسمة", "dasma" }, { "الشرق", "sharq" },
        { "المرقاب", "mirqab" }, { "دسمان", "dasman" }, { "بنيد القار", "bneid al gar" }, { "الصالحية", "salhiya" }, { "الجهراء", "jahra" }, { "الفروانية", "farwaniya" },
        { "خيطان", "khaitan" }, { "جليب الشيوخ", "jleeb al shuyoukh" }, { "العارضية", "ardiya" }, { "الأندلس", "andalous" }, { "الرقة", "riqqa" }, { "الصباحية", "sabahiya" },
        { "الأحمدي", "ahmadi" }, { "المهبولة", "mahboula" }, { "الفنيطيس", "fnaitees" }, { "صباح السالم", "sabah al salem" }, { "العدان", "adan" }, { "القرين", "qurain" },
        { "مبارك الكبير", "mubarak al kabeer" }, { "الصديق", "siddeeq" }, { "حطين", "hateen" }, { "الزهراء", "zahra" }, { "السرة", "surra" }, { "النزهة", "nuzha" },
        { "الشامية", "shamiya" }, { "الصليبيخات", "sulaibikhat" }, { "الدوحة", "doha" }, { "القيروان", "qairawan" }, { "النهضة", "nahda" }, { "الري", "rai" },
        { "الخيران", "khiran" }, { "الوفرة", "wafra" }, { "الزور", "zour" }, { "أم الهيمان", "umm al hayman" }, { "الظهر", "dhaher" }, { "الشدادية", "shadadiya" },
        { "عبدالله المبارك", "abdullah al mubarak" }, { "غرناطة", "granada" }, { "اشبيلية", "ishbiliya" }, { "إشبيلية", "ishbiliya" }, { "الفردوس", "firdous" }, { "صبحان", "subhan" },
        { "ميدان حولي", "maidan hawally" }, { "أبو فطيرة", "abu fatira" }, { "المسيلة", "messila" }, { "الأفنيوز", "avenues" }, { "الكويت", "kuwait" },
    };

    static String normalize(String q) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < q.length(); i++) {
            char c = q.charAt(i);
            if (c >= '٠' && c <= '٩') c = (char) ('0' + (c - '٠'));
            else if (c >= '۰' && c <= '۹') c = (char) ('0' + (c - '۰'));
            sb.append(c);
        }
        String s = sb.toString().toLowerCase(Locale.US).replace('،', ' ').replace(',', ' ').replace('-', ' ');
        for (String[] a : AR) s = s.replace(a[0], " " + a[1] + " ");
        return s.replaceAll("\\s+", " ").trim();
    }

    /** يبني فهرس البحث من ملفات الخرائط (مرة وحدة، ويتخزن) */
    static void buildIndex(final File base, final Runnable done) {
        if (building) return;
        building = true;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    indexState = "جاري تجهيز البحث...";
                    File cache = new File(base, "search.idx");
                    String key = MapData.cachedCells(base) + ":" + MapData.cacheBytes(base);
                    ArrayList<Entry> out = loadIndex(cache, key);
                    if (out == null) {
                        out = new ArrayList<>();
                        File[] fs = MapData.dir(base).listFiles();
                        HashMap<String, ArrayList<Entry>> streets = new HashMap<>();
                        int n = 0;
                        if (fs != null) for (File f : fs) {
                            if (!f.getName().startsWith("c_") || !f.getName().endsWith(".gz")) continue;
                            MapData.Cell c = MapData.readCell(f);
                            for (MapData.Place p : c.places) out.add(mk(p.name, 0, 0, p.la, p.lo));
                            for (MapData.Poi q : c.pois) if (q.kind >= 1 && q.name.length() > 0) out.add(mk(q.name, 2, q.kind, q.la, q.lo));
                            for (MapData.Way w : c.ways) {
                                if (w.name.length() == 0 || w.la.length < 2 || (w.fl & 1) != 0 && w.cls == 0) continue;
                                int m = w.la.length / 2; String lk = w.name.toLowerCase(Locale.US);
                                ArrayList<Entry> l = streets.get(lk); if (l == null) { l = new ArrayList<>(); streets.put(lk, l); }
                                boolean dup = false;
                                for (Entry e : l) if (Math.abs(e.la - w.la[m]) < 300 && Math.abs(e.lo - w.lo[m]) < 300) { dup = true; break; }
                                if (!dup) l.add(mk(w.name, 1, w.cls, w.la[m], w.lo[m]));
                            }
                            if (++n % 40 == 0) indexState = "تجهيز البحث: " + n + " خلية";
                        }
                        for (ArrayList<Entry> l : streets.values()) out.addAll(l);
                        List<int[]> lms = MapData.loadLandmarks(base);
                        for (int[] m : lms) if (m[0] >= 0 && m[0] < MapData.LMS.length) {
                            String nm = MapData.LMS[m[0]][1].split("\\|")[0].replace("\\", "").replaceAll("\\[ -\\]", " ").replaceAll("[^A-Za-z0-9 ']", "").trim();
                            out.add(mk(nm, 3, 0, m[1], m[2]));
                        }
                        saveIndex(cache, key, out);
                    }
                    index = out;
                    indexState = "البحث جاهز: " + out.size() + " عنصر";
                } catch (Throwable t) {
                    indexState = "فشل تجهيز البحث: " + t.getMessage();
                } finally {
                    building = false;
                    if (done != null) done.run();
                }
            }
        }).start();
    }

    private static Entry mk(String name, int kind, int sub, int la, int lo) {
        Entry e = new Entry(); e.name = name; e.lower = name.toLowerCase(Locale.US); e.kind = kind; e.sub = sub; e.la = la; e.lo = lo; return e;
    }

    private static void saveIndex(File f, String key, ArrayList<Entry> l) {
        try {
            DataOutputStream o = new DataOutputStream(new java.io.BufferedOutputStream(new FileOutputStream(f), 65536));
            try {
                o.writeUTF(key); o.writeInt(l.size());
                for (Entry e : l) { o.writeUTF(e.name); o.writeByte(e.kind); o.writeByte(e.sub); o.writeInt(e.la); o.writeInt(e.lo); }
            } finally { o.close(); }
        } catch (IOException ignored) { }
    }

    private static ArrayList<Entry> loadIndex(File f, String key) {
        if (!f.exists()) return null;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f), 65536));
            try {
                if (!in.readUTF().equals(key)) return null;
                int n = in.readInt(); ArrayList<Entry> l = new ArrayList<>(n);
                for (int i = 0; i < n; i++) { String nm = in.readUTF(); int k = in.readByte(), s = in.readByte(), la = in.readInt(), lo = in.readInt(); l.add(mk(nm, k, s, la, lo)); }
                return l;
            } finally { in.close(); }
        } catch (IOException e) { return null; }
    }

    static final class Hit { String title; double la, lo; double dist = -1; }

    private static double dm(double la1, double lo1, double la2, double lo2) {
        double cl = Math.cos(Math.toRadians((la1 + la2) / 2)), dy = (la2 - la1) * 111320.0, dx = (lo2 - lo1) * 111320.0 * cl;
        return Math.hypot(dx, dy);
    }

    /** بحث نصي: "سلوى قطعة 5 شارع 3" أو "Salwa street 3" أو اسم مكان. القطعة والمنزل ما نلقاهم دايماً بـ OSM فنعرضها كملاحظة */
    static List<Hit> search(String raw, double curLa, double curLo) {
        ArrayList<Hit> res = new ArrayList<>();
        ArrayList<Entry> idx = index;
        if (idx == null) return res;
        String q = normalize(raw);
        if (q.length() == 0) return res;
        String block = "", street = "", house = "";
        String rest = " " + q + " ";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\s(block|blk|قطعة|قطعه)\\s*(\\d+)").matcher(rest);
        if (m.find()) { block = m.group(2); rest = rest.replace(m.group(), " "); }
        m = java.util.regex.Pattern.compile("\\s(house|bldg|منزل|بيت)\\s*(\\d+)").matcher(rest);
        if (m.find()) { house = m.group(2); rest = rest.replace(m.group(), " "); }
        m = java.util.regex.Pattern.compile("\\s(street|st|شارع|ش)\\s*([a-z0-9 ]*?)(\\s|$)").matcher(rest);
        String stTok = "";
        if (m.find()) { stTok = m.group(2).trim(); street = stTok; rest = rest.replace(m.group(), " "); }
        rest = rest.replaceAll("\\s+", " ").trim();
        String[] toks = rest.length() == 0 ? new String[0] : rest.split(" ");
        // 1) مناطق تطابق الكلمات
        ArrayList<Entry> areas = new ArrayList<>();
        for (Entry e : idx) if (e.kind == 0 && matchAll(e.lower, rest, toks)) areas.add(e);
        Collections.sort(areas, new Comparator<Entry>() { @Override public int compare(Entry a, Entry b) { return a.lower.length() - b.lower.length(); } });
        if (street.length() > 0 && !areas.isEmpty()) {              // شارع داخل المنطقة: أقرب شوارع بالاسم لوسط المنطقة
            Entry a = areas.get(0);
            ArrayList<Entry> sts = new ArrayList<>();
            for (Entry e : idx) if (e.kind == 1 && streetMatch(e.lower, street) && dm(a.la / 1e5, a.lo / 1e5, e.la / 1e5, e.lo / 1e5) < 3500) sts.add(e);
            final Entry A = a;
            Collections.sort(sts, new Comparator<Entry>() { @Override public int compare(Entry x, Entry y) { return Double.compare(dm(A.la / 1e5, A.lo / 1e5, x.la / 1e5, x.lo / 1e5), dm(A.la / 1e5, A.lo / 1e5, y.la / 1e5, y.lo / 1e5)); } });
            for (int i = 0; i < Math.min(4, sts.size()); i++) {
                Hit h = new Hit(); Entry s = sts.get(i);
                h.title = a.name + " · " + s.name + (block.length() > 0 ? " (القطعة " + block + " غير متوفرة بالخريطة)" : "");
                h.la = s.la / 1e5; h.lo = s.lo / 1e5; res.add(h);
            }
            if (!sts.isEmpty()) { fillDist(res, curLa, curLo); return res; }
        }
        for (int i = 0; i < Math.min(4, areas.size()); i++) {
            Hit h = new Hit(); Entry a = areas.get(i);
            h.title = a.name + (street.length() > 0 ? " (الشارع غير موجود بالخريطة، وسط المنطقة)" : block.length() > 0 ? " (وسط المنطقة)" : "");
            h.la = a.la / 1e5; h.lo = a.lo / 1e5; res.add(h);
        }
        // 2) أماكن ومعالم وشوارع بالاسم
        ArrayList<Entry> other = new ArrayList<>();
        for (Entry e : idx) if (e.kind != 0 && matchAll(e.lower, q, q.split(" "))) other.add(e);
        final double cl = curLa, co = curLo;
        Collections.sort(other, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                if (a.kind != b.kind) return (a.kind == 3 ? 0 : a.kind == 2 ? 1 : 2) - (b.kind == 3 ? 0 : b.kind == 2 ? 1 : 2);
                if (cl == 0) return a.name.length() - b.name.length();
                return Double.compare(dm(cl, co, a.la / 1e5, a.lo / 1e5), dm(cl, co, b.la / 1e5, b.lo / 1e5));
            }
        });
        for (int i = 0; i < other.size() && res.size() < 8; i++) {
            Entry e = other.get(i); Hit h = new Hit();
            String tag = e.kind == 3 ? "معلم" : e.kind == 2 ? (e.sub == 1 ? "بنزين" : e.sub == 2 ? "ترولي" : e.sub == 3 ? "جمعية" : "بنك") : "شارع";
            h.title = e.name + " (" + tag + ")"; h.la = e.la / 1e5; h.lo = e.lo / 1e5; res.add(h);
        }
        fillDist(res, curLa, curLo);
        return res;
    }

    private static void fillDist(List<Hit> res, double la, double lo) { if (la != 0) for (Hit h : res) h.dist = dm(la, lo, h.la, h.lo); }
    private static boolean matchAll(String name, String q, String[] toks) {
        if (toks.length == 0) return false;
        for (String t : toks) if (t.length() > 0 && !name.contains(t)) return false;
        return true;
    }
    private static boolean streetMatch(String name, String tok) {
        if (tok.length() == 0) return false;
        if (tok.matches("\\d+")) return name.matches(".*\\b(street|st|road|rd)\\.? ?" + tok + "\\b.*") || name.equals(tok) || name.matches(".*\\b" + tok + "(st|th|nd|rd)? street.*");
        return name.contains(tok);
    }

    // ---- لصق رابط جوجل مابس أو إحداثيات ----
    static double[] parseCoords(String s) {
        if (s == null) return null;
        String[] pats = { "@(-?\\d{1,2}\\.\\d+),(-?\\d{1,3}\\.\\d+)", "!3d(-?\\d{1,2}\\.\\d+)!4d(-?\\d{1,3}\\.\\d+)", "[?&](?:q|ll|query|destination)=(-?\\d{1,2}\\.\\d+)(?:,|%2C)(-?\\d{1,3}\\.\\d+)", "(-?\\d{1,2}\\.\\d{3,})\\s*[,، ]\\s*(-?\\d{1,3}\\.\\d{3,})" };
        for (String p : pats) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile(p).matcher(s);
            if (m.find()) {
                double la = Double.parseDouble(m.group(1)), lo = Double.parseDouble(m.group(2));
                if (la > 20 && la < 35 && lo > 40 && lo < 55) return new double[] { la, lo };
            }
        }
        return null;
    }

    /** يفتح رابط (مختصر مثل maps.app.goo.gl) ويرجع الرابط النهائي */
    static String resolveUrl(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setInstanceFollowRedirects(true); c.setConnectTimeout(10000); c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36");
        c.getResponseCode();
        String fin = c.getURL().toString();
        if (parseCoords(fin) == null) {                               // أحياناً الإحداثيات داخل الصفحة
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder(); char[] b = new char[8192]; int r, tot = 0;
            while ((r = br.read(b)) > 0 && tot < 200000) { sb.append(b, 0, r); tot += r; }
            br.close(); return fin + " " + sb;
        }
        c.disconnect();
        return fin;
    }

    // ====================================================================================
    //                                    حساب الطريق والملاحة
    // ====================================================================================
    static final class Step { int type, exit, lanes, good, rel = -1; String name = ""; double dist; double la, lo; }

    static volatile boolean active = false;
    static volatile String status = "";
    static volatile boolean autoReroute = true, avoidHwy = false;
    static double destLa, destLo; static String destName = "";
    private static double[] rla, rlo, cum;
    private static final ArrayList<Step> steps = new ArrayList<>();
    private static double totalDist, totalDur;
    private static int hint = 0, offCount = 0, sndStep = -2, lastStepI = -1;
    private static long lastReroute = 0, arrivedAt = 0, routeAt = 0;
    private static volatile boolean routing = false;
    static volatile Runnable onRouteChanged = null;

    private static final String[] OSRM = {
        "https://router.project-osrm.org/route/v1/driving/",
        "https://routing.openstreetmap.de/routed-car/route/v1/driving/",
    };

    static boolean isRouting() { return routing; }

    /** يحسب مسار من الموقع الحالي للوجهة (خيط خلفي). cb يرجع رسالة */
    static void start(final File base, final double la, final double lo, final double dla, final double dlo, final String name, final boolean reroute, final Runnable cb) {
        if (routing) return;
        routing = true;
        if (!reroute) { destLa = dla; destLo = dlo; destName = name; }
        status = reroute ? "جاري إعادة الحساب..." : "جاري حساب الطريق...";
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    JSONObject r = null; String err = "";
                    outer:
                    for (int round = 0; round < 2; round++) {
                        for (String srv : OSRM) {
                            for (int ex = (avoidHwy ? 0 : 1); ex < 2; ex++) {
                                try {
                                    String u = srv + String.format(Locale.US, "%.6f,%.6f;%.6f,%.6f", lo, la, dlo, dla) + "?overview=full&geometries=geojson&steps=true&alternatives=false" + (ex == 0 ? "&exclude=motorway" : "");
                                    String body = Feeds.get(u, 20000);
                                    JSONObject o = new JSONObject(body);
                                    if ("Ok".equals(o.optString("code")) && o.optJSONArray("routes") != null && o.getJSONArray("routes").length() > 0) { r = o.getJSONArray("routes").getJSONObject(0); break outer; }
                                    err = o.optString("code", "?");
                                } catch (Exception e) { err = String.valueOf(e.getMessage()); }
                            }
                        }
                    }
                    if (r == null) { status = "✕ ما قدرت أحسب الطريق (" + err + ") — تأكد من النت"; return; }
                    apply(base, r); save(base);
                    status = "✓ " + String.format(Locale.US, "%.1f km", totalDist / 1000) + " · " + Math.round(totalDur / 60) + " min → " + destName;
                    active = true; arrivedAt = 0; sndStep = -2; lastStepI = -1; offCount = 0; hint = 0; routeAt = System.currentTimeMillis(); if (!reroute) ovPending = true;
                    Runnable oc = onRouteChanged; if (oc != null) oc.run();
                } catch (Throwable t) {
                    status = "✕ خطأ: " + t.getMessage();
                } finally {
                    routing = false;
                    if (cb != null) cb.run();
                }
            }
        }).start();
    }

    static void stop() {
        deleteSaved(); active = false; MapData.route = null; steps.clear(); status = "";
        Runnable oc = onRouteChanged; if (oc != null) oc.run();
    }

    private static void apply(File base, JSONObject r) throws Exception {
        JSONArray co = r.getJSONObject("geometry").getJSONArray("coordinates");
        int n = co.length();
        double[] la = new double[n], lo = new double[n], cu = new double[n];
        for (int i = 0; i < n; i++) {
            JSONArray p = co.getJSONArray(i); lo[i] = p.getDouble(0); la[i] = p.getDouble(1);
            cu[i] = i == 0 ? 0 : cu[i - 1] + dm(la[i - 1], lo[i - 1], la[i], lo[i]);
        }
        ArrayList<Step> st = new ArrayList<>();
        JSONArray legs = r.getJSONArray("legs");
        int from = 0; boolean prevTunnel = false; Step lastRb = null; double rbBefore = 0;
        for (int li = 0; li < legs.length(); li++) {
            JSONArray ss = legs.getJSONObject(li).getJSONArray("steps");
            for (int si = 0; si < ss.length(); si++) {
                JSONObject s = ss.getJSONObject(si), mn = s.getJSONObject("maneuver");
                JSONArray loc = mn.getJSONArray("location");
                double mla = loc.getDouble(1), mlo = loc.getDouble(0);
                int best = from; double bd = 1e18;
                for (int i = from; i < n; i++) { double d = (la[i] - mla) * (la[i] - mla) + (lo[i] - mlo) * (lo[i] - mlo); if (d < bd) { bd = d; best = i; } else if (d > bd * 25 && i > best + 40) break; }
                from = best;
                // نفق (من أصناف التقاطعات)
                boolean tun = false; JSONArray ints = s.optJSONArray("intersections");
                if (ints != null) for (int k = 0; k < ints.length() && !tun; k++) { JSONArray cl = ints.getJSONObject(k).optJSONArray("classes"); if (cl != null) for (int q = 0; q < cl.length(); q++) if ("tunnel".equals(cl.getString(q))) tun = true; }
                Step x = new Step(); x.dist = cu[best]; x.la = mla; x.lo = mlo; x.name = clean(s.optString("name", ""));
                String type = mn.optString("type", ""), mod = mn.optString("modifier", "");
                int t = mapType(type, mod);
                if (type.equals("roundabout") || type.equals("rotary")) { x.exit = Math.max(1, Math.min(9, mn.optInt("exit", 1))); t = 8; lastRb = x; rbBefore = mn.optDouble("bearing_before", -1); }
                if ((type.equals("exit roundabout") || type.equals("exit rotary")) && lastRb != null && rbBefore >= 0) {
                    double ba = mn.optDouble("bearing_after", -1);
                    if (ba >= 0) lastRb.rel = (int) (((ba - rbBefore) % 360 + 360) % 360); lastRb = null;
                }
                if (type.equals("arrive")) { t = 18; x.name = clean(destName.length() > 0 ? destName : x.name); }
                if (ints != null && ints.length() > 0 && t > 0 && t != 18) {
                    JSONArray lanes = ints.getJSONObject(0).optJSONArray("lanes");
                    if (lanes != null && lanes.length() >= 2 && lanes.length() <= 6) {
                        int good = 0, cnt = 0;
                        for (int q = 0; q < lanes.length(); q++) if (lanes.getJSONObject(q).optBoolean("valid", false)) { good |= 1 << q; cnt++; }
                        if (cnt > 0 && cnt < lanes.length()) { x.lanes = lanes.length(); x.good = good; }
                    }
                }
                if (t > 0) { x.type = t; st.add(x); }
                if (tun && !prevTunnel && si > 0) { Step tn = new Step(); tn.type = 17; tn.dist = cu[best]; tn.la = mla; tn.lo = mlo; st.add(tn); }
                prevTunnel = tun;
            }
        }
        // جسور: من بيانات الخرائط المحملة
        try { addBridgeSteps(base, la, lo, cu, st); } catch (Throwable ignored) { }
        Collections.sort(st, new Comparator<Step>() { @Override public int compare(Step a, Step b) { return Double.compare(a.dist, b.dist); } });
        rla = la; rlo = lo; cum = cu; totalDist = r.optDouble("distance", cu[n - 1]); totalDur = r.optDouble("duration", cu[n - 1] / 12.0);
        synchronized (steps) { steps.clear(); steps.addAll(st); }
        int[][] rt = new int[n][2];
        for (int i = 0; i < n; i++) { rt[i][0] = (int) Math.round(la[i] * 100000.0); rt[i][1] = (int) Math.round(lo[i] * 100000.0); }
        MapData.route = rt;
    }

    // ---- حفظ المسار بملف (يرجع لو انقفل التطبيق) ----
    private static File saveFile(File base) { return new File(base, "nav_route.dat"); }
    private static File savedBase = null;
    private static void deleteSaved() { if (savedBase != null) saveFile(savedBase).delete(); }
    static void save(File base) {
        savedBase = base;
        try {
            DataOutputStream o = new DataOutputStream(new java.io.BufferedOutputStream(new FileOutputStream(saveFile(base))));
            try {
                o.writeLong(System.currentTimeMillis()); o.writeDouble(destLa); o.writeDouble(destLo); o.writeUTF(destName);
                o.writeDouble(totalDist); o.writeDouble(totalDur);
                int n = rla.length; o.writeInt(n);
                for (int i = 0; i < n; i++) { o.writeDouble(rla[i]); o.writeDouble(rlo[i]); }
                synchronized (steps) {
                    o.writeInt(steps.size());
                    for (Step s : steps) { o.writeInt(s.type); o.writeInt(s.exit); o.writeInt(s.lanes); o.writeInt(s.good); o.writeInt(s.rel); o.writeUTF(s.name); o.writeDouble(s.dist); o.writeDouble(s.la); o.writeDouble(s.lo); }
                }
            } finally { o.close(); }
        } catch (IOException ignored) { }
    }
    /** يرجّع مسار محفوظ (أقل من 6 ساعات). يرجع true لو رجع */
    static boolean restore(File base) {
        savedBase = base;
        File f = saveFile(base);
        if (active || !f.exists()) return false;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f)));
            try {
                long t = in.readLong();
                if (System.currentTimeMillis() - t > 6L * 3600 * 1000) { in.close(); f.delete(); return false; }
                destLa = in.readDouble(); destLo = in.readDouble(); destName = in.readUTF();
                totalDist = in.readDouble(); totalDur = in.readDouble();
                int n = in.readInt(); double[] la = new double[n], lo = new double[n], cu = new double[n];
                for (int i = 0; i < n; i++) { la[i] = in.readDouble(); lo[i] = in.readDouble(); cu[i] = i == 0 ? 0 : cu[i - 1] + dm(la[i - 1], lo[i - 1], la[i], lo[i]); }
                int m = in.readInt(); ArrayList<Step> st = new ArrayList<>();
                for (int i = 0; i < m; i++) { Step s = new Step(); s.type = in.readInt(); s.exit = in.readInt(); s.lanes = in.readInt(); s.good = in.readInt(); s.rel = in.readInt(); s.name = in.readUTF(); s.dist = in.readDouble(); s.la = in.readDouble(); s.lo = in.readDouble(); st.add(s); }
                rla = la; rlo = lo; cum = cu;
                synchronized (steps) { steps.clear(); steps.addAll(st); }
                int[][] rt = new int[n][2];
                for (int i = 0; i < n; i++) { rt[i][0] = (int) Math.round(la[i] * 100000.0); rt[i][1] = (int) Math.round(lo[i] * 100000.0); }
                MapData.route = rt; hint = 0; offCount = 0; sndStep = -2; arrivedAt = 0;
                status = "✓ رجع المسار المحفوظ → " + destName; active = true;
                return true;
            } finally { in.close(); }
        } catch (Exception e) { return false; }
    }

    private static String clean(String s) {
        if (s == null) return "";
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 126) return "";
        return s.length() > 26 ? s.substring(0, 26) : s;
    }

    private static int mapType(String type, String mod) {
        if (type.equals("depart") || type.equals("notification") || type.equals("exit roundabout") || type.equals("exit rotary")) return 0;
        if (type.equals("arrive")) return 18;
        if (type.equals("fork")) return mod.contains("left") ? 9 : mod.contains("right") ? 10 : 0;
        if (type.equals("off ramp")) return mod.contains("left") ? 11 : 12;
        if (type.equals("merge")) return mod.contains("left") ? 13 : 10;
        if (type.equals("roundabout") || type.equals("rotary")) return 8;
        if (mod.equals("uturn")) return 14;
        if (mod.equals("sharp left")) return 5;
        if (mod.equals("sharp right")) return 6;
        if (mod.equals("slight left")) return 3;
        if (mod.equals("slight right")) return 4;
        if (mod.equals("left")) return 1;
        if (mod.equals("right")) return 2;
        return 0;                                                   // مستقيم / تغيير اسم: ما نحتاج لوحة
    }

    // ---- جسور فوق / تحت ----
    private static boolean segCross(double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy) {
        double d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax), d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax);
        double d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx), d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx);
        return d1 * d2 < 0 && d3 * d4 < 0;
    }

    private static void addBridgeSteps(File base, double[] la, double[] lo, double[] cu, ArrayList<Step> st) {
        int n = la.length;
        HashSet<Long> cells = new HashSet<>();
        for (int i = 0; i < n; i++) cells.add(((long) MapData.cellOf(la[i])) << 32 | (MapData.cellOf(lo[i]) & 0xffffffffL));
        ArrayList<double[]> bsegs = new ArrayList<>();               // {la1, lo1, la2, lo2}
        for (long key : cells) {
            File f = MapData.cellFile(base, (int) (key >> 32), (int) key);
            if (!f.exists()) continue;
            MapData.Cell c = MapData.readCell(f);
            for (MapData.Way w : c.ways) if ((w.fl & 1) != 0 && w.cls >= 1)
                for (int k = 0; k + 1 < w.la.length; k++) bsegs.add(new double[] { w.la[k] / 1e5, w.lo[k] / 1e5, w.la[k + 1] / 1e5, w.lo[k + 1] / 1e5 });
        }
        if (bsegs.isEmpty()) return;
        boolean[] on = new boolean[n];
        for (int i = 0; i < n; i++) {
            for (double[] b : bsegs) {
                double cl = Math.cos(Math.toRadians(la[i]));
                double px = (lo[i] - b[1]) * 111320 * cl, py = (la[i] - b[0]) * 111320, ex = (b[3] - b[1]) * 111320 * cl, ey = (b[2] - b[0]) * 111320;
                double L = ex * ex + ey * ey, t = L == 0 ? 0 : Math.max(0, Math.min(1, (px * ex + py * ey) / L));
                if (Math.hypot(px - t * ex, py - t * ey) < 9) { on[i] = true; break; }
            }
        }
        int i = 0;
        while (i < n) {                                              // فوق جسر: مقطع طويل ≥ 100م
            if (!on[i]) { i++; continue; }
            int j = i; while (j + 1 < n && on[j + 1]) j++;
            if (cu[j] - cu[i] >= 100 && i > 0) { Step s = new Step(); s.type = 15; s.dist = cu[i]; s.la = la[i]; s.lo = lo[i]; st.add(s); }
            i = j + 1;
        }
        double lastUnder = -1e9;
        for (int k = 0; k + 1 < n; k++) {                            // من تحت جسر: جسر يقطع المسار وإحنا مو عليه
            if (on[k] || on[k + 1]) continue;
            for (double[] b : bsegs) {
                if (segCross(lo[k], la[k], lo[k + 1], la[k + 1], b[1], b[0], b[3], b[2])) {
                    if (cu[k] - lastUnder > 250) { Step s = new Step(); s.type = 16; s.dist = cu[k]; s.la = la[k]; s.lo = lo[k]; st.add(s); lastUnder = cu[k]; }
                    break;
                }
            }
        }
    }

    // ---- التتبع: يستدعى كل ثانية من الخدمة، يرجع أسطر أوامر للإطار ----
    static List<String> tick(File base, double la, double lo, float speedKmh) {
        ArrayList<String> out = new ArrayList<>();
        if (!active || rla == null) return out;
        int n = rla.length;
        // أقرب نقطة على المسار (بحث أمامي من آخر موقع)
        double cl = Math.cos(Math.toRadians(la)); int bi = hint; double bd = 1e18, bt = 0;
        int lim = Math.min(n - 1, hint + 120);
        for (int i = Math.max(0, hint - 6); i < lim; i++) {
            double ex = (rlo[i + 1] - rlo[i]) * 111320 * cl, ey = (rla[i + 1] - rla[i]) * 111320, px = (lo - rlo[i]) * 111320 * cl, py = (la - rla[i]) * 111320;
            double L = ex * ex + ey * ey, t = L == 0 ? 0 : Math.max(0, Math.min(1, (px * ex + py * ey) / L));
            double d = Math.hypot(px - t * ex, py - t * ey);
            if (d < bd) { bd = d; bi = i; bt = t; }
        }
        if (bd > 60) {                                               // بعيد: نفحص كامل المسار قبل ما نقول خرجنا
            for (int i = 0; i < n - 1; i++) {
                double ex = (rlo[i + 1] - rlo[i]) * 111320 * cl, ey = (rla[i + 1] - rla[i]) * 111320, px = (lo - rlo[i]) * 111320 * cl, py = (la - rla[i]) * 111320;
                double L = ex * ex + ey * ey, t = L == 0 ? 0 : Math.max(0, Math.min(1, (px * ex + py * ey) / L));
                double d = Math.hypot(px - t * ex, py - t * ey);
                if (d < bd) { bd = d; bi = i; bt = t; }
            }
        }
        long now = System.currentTimeMillis();
        if (bd > 45 && speedKmh > 2) offCount++; else offCount = 0;
        if (offCount >= 4 && autoReroute && !routing && now - lastReroute > 15000) {
            lastReroute = now; offCount = 0;
            start(base, la, lo, destLa, destLo, destName, true, null);
            out.add("nv 7 0 0 0 0 0 0 0 0 0 0|Recalculating");
            return out;
        }
        if (bd <= 60) hint = bi;
        double s = cum[bi] + (cum[Math.min(n - 1, bi + 1)] - cum[bi]) * bt;
        double rem = Math.max(0, totalDist - s);
        // الالتفاتة القادمة
        Step ns = null, then = null; int nsi = -1;
        synchronized (steps) {
            for (int i = 0; i < steps.size(); i++) if (steps.get(i).dist - s > -12) { ns = steps.get(i); nsi = i; if (i + 1 < steps.size()) then = steps.get(i + 1); break; }
        }
        if (rem < 25 || (ns != null && ns.type == 18 && ns.dist - s < 25)) {
            if (arrivedAt == 0) arrivedAt = now;
            out.add("nv 18 0 0 0 0 0 0 0 0 0 0|" + destName.replace('|', ' '));
            if (now - arrivedAt > 15000) { deleteSaved(); active = false; MapData.route = null; status = "وصلت ✓"; out.add("nvoff"); Runnable oc = onRouteChanged; if (oc != null) oc.run(); }
            return out;
        }
        if (ns == null) { out.add("nv 7 " + (int) rem + " 0 0 0 0 0 0 0 0 0|"); return out; }
        double dist = Math.max(0, ns.dist - s);
        int tt = 0, td = 0;
        if (then != null && then.dist - ns.dist <= 250 && then.type != 18) { tt = then.type; td = (int) Math.round(then.dist - s); }
        double rate = totalDur / Math.max(1, totalDist);
        int min = (int) Math.max(1, Math.round(rem * rate / 60.0));
        java.util.Calendar cal = java.util.Calendar.getInstance(); cal.add(java.util.Calendar.MINUTE, min);
        int eta = cal.get(java.util.Calendar.HOUR_OF_DAY) * 100 + cal.get(java.util.Calendar.MINUTE);
        int snd = 0;
        if (dist <= 320 && sndStep != nsi && ns.type != 16 && ns.type != 7) { snd = 1; sndStep = nsi; }
        if (dist > 450 && ns.type != 7 && ns.type != 16 && ns.type != 15 && ns.type != 17) {
            // بعيد: نعرض الالتفاتة برضو (اللوحة العادية) لأن المسافة مكتوبة
        }
        out.add("nv " + ns.type + " " + (int) Math.round(dist) + " " + (ns.type == 8 && ns.rel >= 0 ? ns.exit + 10 * (ns.rel / 10) : ns.exit) + " " + tt + " " + td + " " + (int) Math.round(rem / 100.0) + " " + min + " " + eta + " " + ns.lanes + " " + ns.good + " " + snd + "|" + ns.name.replace('|', ' '));
        return out;
    }


    // ---- نظرة المسار على الإطار: مسار + طرق رئيسية + أسماء مناطق وشوارع (إحداثيات جاهزة بالبكسل) ----
    static volatile boolean ovPending = false;

    private static void dpKeep(double[] x, double[] y, int a, int b, double eps, boolean[] keep) {
        if (b <= a + 1) return;
        double bd = -1; int bi = a; double dx = x[b] - x[a], dy = y[b] - y[a], L = Math.hypot(dx, dy);
        for (int i = a + 1; i < b; i++) {
            double d = L < 1e-9 ? Math.hypot(x[i] - x[a], y[i] - y[a]) : Math.abs(dy * (x[i] - x[a]) - dx * (y[i] - y[a])) / L;
            if (d > bd) { bd = d; bi = i; }
        }
        if (bd > eps) { keep[bi] = true; dpKeep(x, y, a, bi, eps, keep); dpKeep(x, y, bi, b, eps, keep); }
    }
    private static double[][] simp(double[] x, double[] y, int n, double eps, int maxPts) {
        for (int it = 0; it < 12; it++) {
            boolean[] keep = new boolean[n]; keep[0] = true; keep[n - 1] = true; dpKeep(x, y, 0, n - 1, eps, keep);
            int c = 0; for (boolean b : keep) if (b) c++;
            if (c <= maxPts || it == 11) {
                double[][] o = new double[2][c]; int k = 0;
                for (int i = 0; i < n; i++) if (keep[i]) { o[0][k] = x[i]; o[1][k] = y[i]; k++; }
                return o;
            }
            eps *= 1.7;
        }
        return new double[][] { x, y };
    }
    private static void polyLines(ArrayList<String> out, int k, double[][] p) {
        int n = p[0].length;
        for (int i = 0; i < n - 1; i += 11) {
            StringBuilder sb = new StringBuilder("ovp ").append(k);
            int e = Math.min(n - 1, i + 11);
            for (int j = i; j <= e; j++) sb.append(' ').append(Math.round(p[0][j])).append(',').append(Math.round(p[1][j]));
            out.add(sb.toString());
        }
    }
    private static boolean asciiOk(String s) { if (s == null || s.length() == 0) return false; for (int i = 0; i < s.length(); i++) if (s.charAt(i) < 32 || s.charAt(i) > 126) return false; return true; }

    static List<String> overview(File base, boolean labels) {
        ArrayList<String> out = new ArrayList<>();
        double[] la = rla, lo = rlo; if (la == null || la.length < 2) return out;
        int n = la.length;
        double minLa = 1e9, maxLa = -1e9, minLo = 1e9, maxLo = -1e9;
        for (int i = 0; i < n; i++) { minLa = Math.min(minLa, la[i]); maxLa = Math.max(maxLa, la[i]); minLo = Math.min(minLo, lo[i]); maxLo = Math.max(maxLo, lo[i]); }
        double cla = (minLa + maxLa) / 2, clo = (minLo + maxLo) / 2, cl = Math.cos(Math.toRadians(cla));
        double wm = Math.max((maxLo - minLo) * cl, 0.004), hm = Math.max(maxLa - minLa, 0.004);
        double sc = Math.min(316.0 / wm, 236.0 / hm);                     // بكسل لكل درجة
        double[] sx = new double[n], sy = new double[n];
        for (int i = 0; i < n; i++) { sx[i] = 233 + (lo[i] - clo) * cl * sc; sy[i] = 236 - (la[i] - cla) * sc; }
        out.add("ovclr");
        double[][] rp = simp(sx, sy, n, 1.2, 70);
        // خلايا المسار
        java.util.HashSet<Long> cells = new java.util.HashSet<>(); ArrayList<int[]> cl2 = new ArrayList<>();
        for (int i = 0; i < n; i += 3) { int ci = MapData.cellOf(la[i]), cj = MapData.cellOf(lo[i]); long key = ci * 100000L + cj; if (cells.add(key)) cl2.add(new int[] { ci, cj }); }
        if (cl2.size() > 120) { cl2 = new ArrayList<>(cl2.subList(0, 120)); }
        ArrayList<double[][]> hw = new ArrayList<>(), mn = new ArrayList<>(); int budget = 380;
        ArrayList<Object[]> roadCand = new ArrayList<>();   // {name, ref, len, x, y}
        ArrayList<double[]> places = new ArrayList<>(); ArrayList<String> placeNm = new ArrayList<>();
        for (int[] c : cl2) {
            MapData.Cell cell = MapData.readCell(MapData.cellFile(base, c[0], c[1]));
            for (MapData.Place p : cell.places) {
                if (!asciiOk(p.name)) continue;
                double x = 233 + (p.lo / 1e5 - clo) * cl * sc, y = 236 - (p.la / 1e5 - cla) * sc;
                if (x < 50 || x > 416 || y < 96 || y > 376) continue;
                places.add(new double[] { x, y }); placeNm.add(p.name);
            }
            for (MapData.Way w : cell.ways) {
                if (w.cls < 2 || (w.fl & 2) != 0 || w.la.length < 2) continue;
                int m = w.la.length; double[] x = new double[m], y = new double[m]; boolean any = false; double len = 0;
                for (int i = 0; i < m; i++) {
                    x[i] = 233 + (w.lo[i] / 1e5 - clo) * cl * sc; y[i] = 236 - (w.la[i] / 1e5 - cla) * sc;
                    if (x[i] > 20 && x[i] < 446 && y[i] > 70 && y[i] < 400) any = true;
                    if (i > 0) len += Math.hypot(x[i] - x[i - 1], y[i] - y[i - 1]);
                }
                if (!any || len < 18) continue;
                double[][] sp = simp(x, y, m, 2.0, 12);
                (w.cls >= 3 ? hw : mn).add(sp);
                if (labels && (w.ref.length() > 0 || w.name.length() > 0)) {
                    int mid = m / 2;   // منتصف الخط
                    double tl = 0, half = len / 2, mx = x[0], my = y[0];
                    for (int i = 1; i < m; i++) { double d = Math.hypot(x[i] - x[i - 1], y[i] - y[i - 1]); if (tl + d >= half) { double f = d == 0 ? 0 : (half - tl) / d; mx = x[i - 1] + (x[i] - x[i - 1]) * f; my = y[i - 1] + (y[i] - y[i - 1]) * f; break; } tl += d; }
                    roadCand.add(new Object[] { w.name, w.ref, len, mx, my });
                }
            }
        }
        int pts = 0;
        for (int pass = 0; pass < 2; pass++) for (double[][] sp : (pass == 0 ? mn : hw)) {
            if (pts + sp[0].length > budget) continue; pts += sp[0].length; polyLines(out, pass, sp);
        }
        polyLines(out, 2, rp);
        if (labels) {
            ArrayList<int[]> used = new ArrayList<>();      // مستطيلات {x,y,w,h}
            used.add(new int[] { 233, 54, 270, 62 }); used.add(new int[] { 233, 417, 290, 64 });
            // دروع أرقام الطرق + أسماء الشوارع (الأطول أول)
            java.util.Collections.sort(roadCand, new Comparator<Object[]>() { @Override public int compare(Object[] a, Object[] b) { return Double.compare((Double) b[2], (Double) a[2]); } });
            java.util.HashSet<String> seen = new java.util.HashSet<>(); int nl = 0;
            for (Object[] r : roadCand) {
                if (nl >= 7) break;
                String nm = (String) r[0], rf = (String) r[1]; double x = (Double) r[3], y = (Double) r[4];
                boolean shield = rf.length() > 0 && rf.length() <= 4 && asciiOk(rf);
                String t = shield ? rf.toUpperCase(Locale.US) : (asciiOk(nm) ? nm : null);
                if (t == null || t.length() > 14 || !seen.add(t.toLowerCase(Locale.US))) continue;
                double dxc = x - 233, dyc = y - 233; if (dxc * dxc + dyc * dyc > 200 * 200) continue;
                int w = shield ? t.length() * 6 + 14 : t.length() * 6 + 4, h = shield ? 20 : 12;
                if (overlaps(used, (int) x, (int) y, w, h)) continue;
                used.add(new int[] { (int) x, (int) y, w, h }); nl++;
                out.add("ovl " + (shield ? 2 : 1) + " " + (int) x + " " + (int) y + " " + t.replace('|', ' '));
            }
            // أسماء المناطق: الأقرب للمسار أول، مع مسافة بينها
            final double[][] route = rp; final ArrayList<double[]> pl = places;
            Integer[] idx = new Integer[places.size()]; for (int i = 0; i < idx.length; i++) idx[i] = i;
            final double[] dmin = new double[places.size()];
            for (int i = 0; i < dmin.length; i++) { double d = 1e9; for (int j = 0; j < route[0].length; j++) d = Math.min(d, Math.hypot(places.get(i)[0] - route[0][j], places.get(i)[1] - route[1][j])); dmin[i] = d; }
            java.util.Arrays.sort(idx, new Comparator<Integer>() { @Override public int compare(Integer a, Integer b) { return Double.compare(dmin[a], dmin[b]); } });
            int na = 0; java.util.HashSet<String> seenP = new java.util.HashSet<>();
            for (int q : idx) {
                if (na >= 7) break;
                String t = placeNm.get(q); if (t.length() > 14 || !seenP.add(t.toLowerCase(Locale.US))) continue;
                double x = places.get(q)[0], y = places.get(q)[1]; double dxc = x - 233, dyc = y - 233; if (dxc * dxc + dyc * dyc > 190 * 190) continue;
                int w = t.length() * 12 + 4, h = 18;
                if (overlaps(used, (int) x, (int) y, w, h)) continue;
                used.add(new int[] { (int) x, (int) y, w, h }); na++;
                out.add("ovl 0 " + (int) x + " " + (int) y + " " + t.replace('|', ' '));
            }
        }
        double rate = totalDur / Math.max(1, totalDist);
        java.util.Calendar cal = java.util.Calendar.getInstance(); cal.add(java.util.Calendar.MINUTE, (int) Math.round(totalDur / 60));
        out.add("ovi " + (int) Math.round(totalDist / 100.0) + " " + (int) Math.round(totalDur / 60) + " " + (cal.get(java.util.Calendar.HOUR_OF_DAY) * 100 + cal.get(java.util.Calendar.MINUTE)) + "|" + (destName.length() > 0 ? destName.replace('|', ' ') : ""));
        out.add("ovgo");
        return out;
    }
    private static boolean overlaps(ArrayList<int[]> used, int x, int y, int w, int h) {
        for (int[] u : used) if (Math.abs(x - u[0]) < (w + u[2]) / 2 + 3 && Math.abs(y - u[1]) < (h + u[3]) / 2 + 3) return true;
        return false;
    }

    static String summary() {
        if (!active) return status;
        return status;
    }
}
