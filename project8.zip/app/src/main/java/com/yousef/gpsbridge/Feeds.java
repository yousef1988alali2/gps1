package com.yousef.gpsbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** جلب الرادار والنتائج من الإنترنت (من الجوال) وتحويلها لأسطر مضغوطة يفهمها الإطار. */
final class Feeds {
    private Feeds() { }

    static final String[] SLUG = { "eng.1", "esp.1", "ita.1", "ger.1", "uefa.champions", "uefa.europa" };
    static final String[] LG_AR = { "الدوري الإنجليزي", "الدوري الإسباني", "الدوري الإيطالي",
            "الدوري الألماني", "دوري الأبطال", "الدوري الأوروبي" };

    static String get(String url) throws IOException { return get(url, 12000); }

    static String get(String url, int readMs) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(readMs);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) PhotoFrameBridge");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (bo.size() > 4 * 1024 * 1024) throw new IOException("too big");
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    /** يحوّل الحروف الأوروبية لإنجليزية ويشيل الفواصل اللي تخرب البروتوكول، ويقص الطول. */
    static String clean(String s, int max) {
        if (s == null) return "";
        String t = Normalizer.normalize(s, Normalizer.Form.NFD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length() && sb.length() < max; i++) {
            char ch = t.charAt(i);
            if (ch == '|' || ch == ';' || ch == '\n' || ch == '\r' || ch == '\t') ch = ' ';
            if (ch >= 32 && ch < 127) sb.append(ch);
            else if (ch >= 0x300 && ch < 0x370) continue;   // علامات التشكيل بعد التفكيك
            else if (ch == 0xF8) sb.append('o');
            else if (ch == 0xD8) sb.append('O');
            else if (ch == 0xDF) sb.append("ss");
            else if (ch == 0x141) sb.append('L');
            else if (ch == 0x142) sb.append('l');
            else sb.append('?');
        }
        return sb.toString().trim();
    }

    /** كاميرات السرعة من OpenStreetMap حول نقطة (نصف القطر بالمتر). يرجع {lat×1e5, lon×1e5} الأقرب أول. */
    static List<int[]> cameras(double lat0, double lon0, int radiusM) throws Exception {
        String q = String.format(Locale.US,
                "[out:json][timeout:25];(node[\"highway\"=\"speed_camera\"](around:%d,%.5f,%.5f);"
                        + "node[\"enforcement\"~\"maxspeed|traffic_signals|average_speed\"](around:%d,%.5f,%.5f););out 4000;",
                radiusM, lat0, lon0, radiusM, lat0, lon0);
        String enc = java.net.URLEncoder.encode(q, "UTF-8");
        String body;
        try {
            body = get("https://overpass-api.de/api/interpreter?data=" + enc, 30000);
        } catch (Exception e) {
            body = get("https://overpass.kumi.systems/api/interpreter?data=" + enc, 30000);
        }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("elements");
        final double cl = Math.cos(Math.toRadians(lat0));
        final ArrayList<double[]> tmp = new ArrayList<>();
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.optJSONObject(i);
                if (a == null || !a.has("lat") || !a.has("lon")) continue;
                long la = Math.round(a.optDouble("lat") * 100000.0), lo = Math.round(a.optDouble("lon") * 100000.0);
                if (!seen.add(la * 100000000L + lo)) continue;
                double dx = (lo / 100000.0 - lon0) * cl * 111320.0, dy = (la / 100000.0 - lat0) * 111320.0;
                tmp.add(new double[] { Math.sqrt(dx * dx + dy * dy), la, lo });
            }
        }
        Collections.sort(tmp, new Comparator<double[]>() {
            @Override public int compare(double[] x, double[] y) { return Double.compare(x[0], y[0]); }
        });
        ArrayList<int[]> out = new ArrayList<>();
        for (int i = 0; i < tmp.size() && i < 2900; i++) out.add(new int[] { (int) tmp.get(i)[1], (int) tmp.get(i)[2], (int) tmp.get(i)[0] });
        return out;
    }

    private static final class Ac {
        double km, brg, trk, alt, gs, lat, lon;
        String fl, ty = "-", air = "-", emerg = "";
        int vr, sq;
    }

    /** شركات الطيران الشائعة حسب أول 3 حروف من رمز الرحلة */
    private static final java.util.HashMap<String, String> AIRL = new java.util.HashMap<>();
    static {
        String[] a = { "KAC", "Kuwait Airways", "JZR", "Jazeera", "UAE", "Emirates", "QTR", "Qatar Airways", "ETD", "Etihad", "SVA", "Saudia",
                "FDB", "flydubai", "ABY", "Air Arabia", "GFA", "Gulf Air", "OMA", "Oman Air", "MEA", "MEA", "RJA", "Royal Jordanian",
                "THY", "Turkish", "PGT", "Pegasus", "IRA", "Iran Air", "MAH", "Mahan Air", "IAW", "Iraqi Airways", "MSR", "EgyptAir",
                "BAW", "British Airways", "DLH", "Lufthansa", "AFR", "Air France", "KLM", "KLM", "SIA", "Singapore", "THA", "Thai",
                "AIC", "Air India", "IGO", "IndiGo", "PIA", "PIA", "SEP", "Fly Sepahan", "FIN", "Finnair", "SWR", "Swiss", "UPS", "UPS",
                "FDX", "FedEx", "DHL", "DHL", "GEC", "Lufthansa Cargo", "RYR", "Ryanair", "AAL", "American", "UAL", "United", "DAL", "Delta",
                "QFA", "Qantas", "CPA", "Cathay", "ANA", "ANA", "JAL", "Japan Air", "EVA", "EVA Air", "SAS", "SAS", "VIR", "Virgin Atl",
                "PAK", "Pakistan Intl", "SKY", "Sky Air", "RBG", "Royal Brunei", "AXB", "Air India Exp", "SDM", "Rossiya", "AFL", "Aeroflot" };
        for (int i = 0; i + 1 < a.length; i += 2) AIRL.put(a[i], a[i + 1]);
    }
    private static String airline(String fl) { return fl.length() >= 4 && fl.matches("[A-Z]{3}[0-9].*") ? AIRL.get(fl.substring(0, 3)) : null; }

    /** آخر طيارات الرادار (لجلب مساراتها) */
    static volatile List<Ac> lastAcs = new ArrayList<>();

    private static Ac parseAc(JSONObject a, double lat0, double lon0, double cl) {
        if (a == null || !a.has("lat") || !a.has("lon")) return null;
        Ac x = new Ac();
        x.lat = a.optDouble("lat"); x.lon = a.optDouble("lon");
        double dx = (x.lon - lon0) * cl * 111.32, dy = (x.lat - lat0) * 110.57;
        x.km = Math.sqrt(dx * dx + dy * dy);
        double b = Math.toDegrees(Math.atan2(dx, dy));
        x.brg = b < 0 ? b + 360 : b;
        x.trk = a.optDouble("track", 0);
        Object ab = a.opt("alt_baro");
        x.alt = (ab instanceof Number) ? ((Number) ab).doubleValue() : 0;
        x.gs = a.optDouble("gs", 0);
        String fl = clean(a.optString("flight", ""), 8).replace(" ", "");
        x.fl = fl.isEmpty() ? "-" : fl;
        String t = clean(a.optString("t", ""), 4).replace(" ", "");
        x.ty = t.isEmpty() ? "-" : t;
        String al = airline(x.fl);
        x.air = al == null ? "-" : clean(al, 14).replace(' ', '_');
        Object br = a.opt("baro_rate");
        x.vr = (br instanceof Number) ? ((Number) br).intValue() : 0;
        try { x.sq = Integer.parseInt(a.optString("squawk", "0").trim()); } catch (Exception e) { x.sq = 0; }
        String em = a.optString("emergency", "none");
        x.emerg = "none".equals(em) || em.isEmpty() ? "" : em;
        return x;
    }

    private static String emReason(Ac x) {
        switch (x.emerg) {
            case "lifeguard": return "MEDICAL";
            case "minfuel": return "LOW FUEL";
            case "nordo": return "NO RADIO";
            case "unlawful": return "HIJACK";
            case "downed": return "DOWNED";
            case "general": return "GENERAL";
            default: break;
        }
        return x.sq == 7700 ? "GENERAL" : x.sq == 7600 ? "NO RADIO" : x.sq == 7500 ? "HIJACK" : "";
    }

    /** الطيارات اللي بحالة طوارئ ضمن نصف قطر واسع. أسطر em للإطار */
    static List<String> emergencies(double lat0, double lon0, int radiusKm) throws Exception {
        int nm = (int) Math.ceil(radiusKm / 1.852);
        if (nm < 20) nm = 20;
        if (nm > 250) nm = 250;
        String body;
        String p = String.format(Locale.US, "%.4f/%.4f/%d", lat0, lon0, nm);
        try { body = get("https://api.adsb.lol/v2/point/" + p); }
        catch (Exception e) { body = get("https://api.airplanes.live/v2/point/" + p); }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("ac");
        if (arr == null) arr = o.optJSONArray("aircraft");
        ArrayList<String> out = new ArrayList<>();
        if (arr == null) return out;
        double cl = Math.cos(Math.toRadians(lat0));
        for (int i = 0; i < arr.length() && out.size() < 3; i++) {
            JSONObject a = arr.optJSONObject(i);
            Ac x = parseAc(a, lat0, lon0, cl);
            if (x == null || x.km > radiusKm) continue;
            String why = emReason(x);
            if (why.isEmpty()) continue;
            String hex = clean(a.optString("hex", x.fl), 8);
            String code = x.sq > 0 ? String.valueOf(x.sq) : "----";
            String ta = ("-".equals(x.ty) ? "" : x.ty) + ("-".equals(x.air) ? "" : (x.ty.equals("-") ? "" : " ") + x.air.replace('_', ' '));
            String[] rt = ROUTES.get(x.fl);
            String route = rt != null && rt.length >= 2 ? rt[0] + " > " + rt[1] : "";
            String info = String.format(Locale.US, "%.0f km  %,d ft", x.km, (int) x.alt);
            out.add("em " + hex + "|" + x.fl + "|" + code + "|" + why + "|" + clean(ta, 23) + "|" + route + "|" + info);
        }
        return out;
    }

    // ---- مسارات الرحلات (من وين ولوين) ----
    private static final java.util.HashMap<String, String[]> ROUTES = new java.util.HashMap<>();      // callsign → {o, d, oCity, dCity, dLat, dLon, oLat, oLon}
    private static final java.util.HashMap<String, Long> ROUTE_TRY = new java.util.HashMap<>();       // وقت آخر محاولة (لا نكرر الفاشلة)

    private static double hav(double la1, double lo1, double la2, double lo2) {
        double dla = Math.toRadians(la2 - la1), dlo = Math.toRadians(lo2 - lo1);
        double h = Math.sin(dla / 2) * Math.sin(dla / 2) + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dlo / 2) * Math.sin(dlo / 2);
        return 12742.0 * Math.asin(Math.min(1, Math.sqrt(h)));
    }

    private static String post(String url, String json) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) PhotoFrameBridge");
            c.getOutputStream().write(json.getBytes(StandardCharsets.UTF_8));
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 512 * 1024) break; }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    /** أسطر rt لأقرب 8 طيارات (يجلب المسارات الناقصة بطلب واحد، ويحسب المسافة المتبقية للوجهة). */
    static List<String> routes() {
        ArrayList<String> out = new ArrayList<>();
        List<Ac> acs = lastAcs;
        long now = System.currentTimeMillis();
        try {
            JSONArray req = new JSONArray();
            int cnt = 0;
            for (int i = 0; i < acs.size() && i < 8; i++) {
                Ac x = acs.get(i);
                if (!x.fl.matches("[A-Z]{3}[0-9].*") || ROUTES.containsKey(x.fl)) continue;
                Long t = ROUTE_TRY.get(x.fl);
                if (t != null && now - t < 10 * 60 * 1000L) continue;
                ROUTE_TRY.put(x.fl, now);
                JSONObject j = new JSONObject();
                j.put("callsign", x.fl); j.put("lat", x.lat); j.put("lng", x.lon);
                req.put(j); cnt++;
            }
            if (cnt > 0) {
                JSONObject body = new JSONObject();
                body.put("planes", req);
                String r = post("https://api.adsb.lol/api/0/routeset", body.toString());
                JSONArray ra = r.trim().startsWith("[") ? new JSONArray(r) : new JSONArray();
                for (int i = 0; i < ra.length(); i++) {
                    JSONObject e = ra.optJSONObject(i);
                    if (e == null) continue;
                    String cs = clean(e.optString("callsign", ""), 8);
                    JSONArray ap = e.optJSONArray("_airports");
                    if (cs.isEmpty() || ap == null || ap.length() < 2) continue;
                    JSONObject o0 = ap.optJSONObject(0), d0 = ap.optJSONObject(ap.length() - 1);
                    if (o0 == null || d0 == null) continue;
                    String oc = clean(o0.optString("iata", ""), 4), dc = clean(d0.optString("iata", ""), 4);
                    if (oc.isEmpty()) oc = clean(o0.optString("icao", ""), 4);
                    if (dc.isEmpty()) dc = clean(d0.optString("icao", ""), 4);
                    ROUTES.put(cs, new String[] { oc, dc, clean(o0.optString("location", ""), 13), clean(d0.optString("location", ""), 13),
                            String.valueOf(d0.optDouble("lat", 0)), String.valueOf(d0.optDouble("lon", 0)),
                            String.valueOf(o0.optDouble("lat", 0)), String.valueOf(o0.optDouble("lon", 0)) });
                }
            }
        } catch (Exception ignored) { }
        for (int i = 0; i < acs.size() && i < 8; i++) {
            Ac x = acs.get(i);
            String[] r = ROUTES.get(x.fl);
            if (r == null) continue;
            double dl = Double.parseDouble(r[4]), dn = Double.parseDouble(r[5]), ol = Double.parseDouble(r[6]), on = Double.parseDouble(r[7]);
            double rem = (dl == 0 && dn == 0) ? 0 : hav(x.lat, x.lon, dl, dn), tot = (dl == 0 && ol == 0) ? 0 : hav(ol, on, dl, dn);
            out.add(String.format(Locale.US, "rt %s %s|%s|%s|%s|%.0f|%.0f", x.fl, r[0], r[1], r[2], r[3], rem, tot));
        }
        return out;
    }

    /** أسطر الرادار: الأقرب أول. إذا ما في طيارات يرجع سطر واحد "rp 0 0". */
    static List<String> radar(double lat0, double lon0, int rangeKm) throws Exception {
        int nm = (int) Math.ceil(rangeKm / 1.852);
        if (nm < 5) nm = 5;
        if (nm > 250) nm = 250;
        String p = String.format(Locale.US, "%.4f/%.4f/%d", lat0, lon0, nm);
        String body;
        try {
            body = get("https://api.adsb.lol/v2/point/" + p);
        } catch (Exception e) {
            body = get("https://api.airplanes.live/v2/point/" + p);
        }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("ac");
        if (arr == null) arr = o.optJSONArray("aircraft");
        ArrayList<Ac> list = new ArrayList<>();
        double cl = Math.cos(Math.toRadians(lat0));
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                Ac x = parseAc(arr.optJSONObject(i), lat0, lon0, cl);
                if (x == null || x.km > rangeKm * 1.05) continue;
                list.add(x);
            }
        }
        Collections.sort(list, new Comparator<Ac>() {
            @Override public int compare(Ac a, Ac b) { return Double.compare(a.km, b.km); }
        });
        ArrayList<String> out = new ArrayList<>();
        int n = Math.min(list.size(), 24);
        lastAcs = new ArrayList<>(list.subList(0, n));
        if (n == 0) {
            out.add("rp 0 0");
            return out;
        }
        for (int i = 0; i < n; i++) {
            Ac x = list.get(i);
            out.add(String.format(Locale.US, "rp %d %d %.1f %.0f %.0f %.0f %.0f %s %s %s %d %d",
                    i, n, x.km, x.brg, x.trk, x.alt, x.gs, x.fl, x.ty, x.air, x.vr, x.sq));
        }
        return out;
    }

    /** نتيجة دوري: الأسطر + هل في مباراة شغالة (عشان نعرف نحدّث كل 20 ثانية). */
    static final class Scores {
        final ArrayList<String> lines = new ArrayList<>();
        boolean live = false;     // في مباراة شغالة (كل 5 ثواني)
        boolean soon = false;     // مباراة تبدأ خلال 5 دقايق (كل 20 ثانية)
        final ArrayList<String[]> ms = new ArrayList<>();   // {id, hAr, aAr, hN, aN, hs, as, state, clk}
    }

    private static int rank(int st) { return st == 1 ? 0 : st == 2 ? 1 : 2; }

    private static final class M {
        String id = "", hA = "", aA = "", hN = "", aN = "", hId = "", aId = "", clk = "", gName = "", gClk = "", gTid = "";
        int hs, as, state;
        long ko;
        int nRed;
        String rName = "", rClk = "", rTid = "";
        final ArrayList<String[]> goals = new ArrayList<>();   // {name, clk, tid}
    }

    private static String shortNm(String n, int cap) {
        if (n.length() < cap) return n;
        int sp = n.lastIndexOf(' ');
        String r = sp >= 0 ? n.substring(sp + 1) : n;
        return r.length() > cap - 1 ? r.substring(0, cap - 1) : r;
    }

    static Scores scores(int li) throws Exception {
        String body = get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + SLUG[li] + "/scoreboard");
        JSONObject o = new JSONObject(body);
        JSONArray ev = o.optJSONArray("events");
        ArrayList<M> ms = new ArrayList<>();
        if (ev != null) {
            for (int i = 0; i < ev.length() && ms.size() < 14; i++) {
                JSONObject e = ev.optJSONObject(i);
                if (e == null) continue;
                M m = new M();
                m.id = clean(e.optString("id", ""), 11);
                JSONObject st = e.optJSONObject("status");
                if (st != null) {
                    m.clk = clean(st.optString("displayClock", ""), 9);
                    JSONObject ty = st.optJSONObject("type");
                    String s = ty == null ? "" : ty.optString("state", "");
                    m.state = "in".equals(s) ? 1 : "post".equals(s) ? 2 : 0;
                }
                m.ko = parseDate(e.optString("date", ""));
                if (m.state == 0 && m.ko > 0) {                                  // وقت البداية بتوقيت الكويت (HH:mm)
                    java.text.SimpleDateFormat kf = new java.text.SimpleDateFormat("HH:mm", Locale.US);
                    kf.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Kuwait"));
                    m.clk = kf.format(new java.util.Date(m.ko));
                }
                JSONArray comps = e.optJSONArray("competitions");
                JSONObject comp = comps == null ? null : comps.optJSONObject(0);
                if (comp == null) continue;
                JSONArray cs = comp.optJSONArray("competitors");
                if (cs == null || cs.length() < 2) continue;
                JSONObject home = null, away = null;
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject c = cs.optJSONObject(k);
                    if (c == null) continue;
                    String ha = c.optString("homeAway", "");
                    if ("home".equals(ha)) home = c;
                    else if ("away".equals(ha)) away = c;
                }
                if (home == null) home = cs.optJSONObject(0);
                if (away == null) away = cs.optJSONObject(1);
                if (home == null || away == null) continue;
                JSONObject ht = home.optJSONObject("team"), at = away.optJSONObject("team");
                if (ht != null) {
                    m.hA = clean(ht.optString("abbreviation", ""), 5);
                    m.hN = clean(ht.optString("displayName", ""), 23);
                    m.hId = clean(ht.optString("id", ""), 7);
                }
                if (at != null) {
                    m.aA = clean(at.optString("abbreviation", ""), 5);
                    m.aN = clean(at.optString("displayName", ""), 23);
                    m.aId = clean(at.optString("id", ""), 7);
                }
                m.hs = parseInt(home.optString("score", "0"));
                m.as = parseInt(away.optString("score", "0"));
                JSONArray det = comp.optJSONArray("details");
                if (det != null) {
                    for (int k = 0; k < det.length(); k++) {
                        JSONObject d = det.optJSONObject(k);
                        if (d == null) continue;
                        if (d.optBoolean("redCard", false)) {
                            JSONArray ra = d.optJSONArray("athletesInvolved");
                            JSONObject r0 = ra == null ? null : ra.optJSONObject(0);
                            JSONObject rc = d.optJSONObject("clock"), rt = d.optJSONObject("team");
                            m.nRed++;
                            m.rName = r0 == null ? "" : clean(r0.optString("displayName", ""), 21);
                            m.rClk = rc == null ? "" : clean(rc.optString("displayValue", ""), 7);
                            m.rTid = rt == null ? "" : clean(rt.optString("id", ""), 7);
                            continue;
                        }
                        if (!d.optBoolean("scoringPlay", false)) continue;
                        JSONArray ai = d.optJSONArray("athletesInvolved");
                        JSONObject a0 = ai == null ? null : ai.optJSONObject(0);
                        JSONObject ck = d.optJSONObject("clock");
                        JSONObject tm = d.optJSONObject("team");
                        m.gName = a0 == null ? "" : clean(a0.optString("displayName", ""), 21);
                        m.gClk = ck == null ? "" : clean(ck.optString("displayValue", ""), 7);
                        m.gTid = tm == null ? "" : clean(tm.optString("id", ""), 7);
                        m.goals.add(new String[] { shortNm(m.gName, 16), m.gClk, m.gTid });
                    }
                }
                ms.add(m);
            }
        }
        Collections.sort(ms, new Comparator<M>() {                         // ثابت: شغالة، منتهية، قادمة
            @Override public int compare(M a, M b) {
                int d = rank(a.state) - rank(b.state);
                if (d == 0 && a.state == 0 && a.ko > 0 && b.ko > 0) return Long.compare(a.ko, b.ko);
                return d;
            }
        });
        Scores r = new Scores();
        int n = ms.size();
        if (n == 0) {
            r.lines.add("sm " + li + " 0 0");
            return r;
        }
        for (int i = 0; i < n; i++) {
            M m = ms.get(i);
            if (m.state == 1) r.live = true;
            long dt = m.ko - System.currentTimeMillis();
            if (m.state == 0 && m.ko > 0 && dt < 5 * 60 * 1000L && dt > -30 * 60 * 1000L) r.soon = true;   // قرّبت البداية: نجلب كل 20 ثانية
            r.ms.add(new String[] { m.id, m.hA, m.aA, m.hN, m.aN, String.valueOf(m.hs), String.valueOf(m.as), String.valueOf(m.state), m.clk });
            r.lines.add("sm " + li + " " + i + " " + n + " " + m.id + "|" + m.hA + "|" + m.aA + "|" + m.hN + "|" + m.aN + "|"
                    + m.hId + "|" + m.aId + "|" + m.hs + "|" + m.as + "|" + m.state + "|" + m.clk + "|"
                    + m.gName + "|" + m.gClk + "|" + m.gTid + "|" + m.nRed);
            int ng = Math.min(m.goals.size(), 7);
            for (int k = 0; k < ng; k++) {
                String[] g = m.goals.get(k);
                r.lines.add("sg " + li + " " + m.id + "|" + ng + "|" + k + "|" + g[0] + "|" + g[1] + "|" + g[2]);
            }
            if (m.nRed > 0) r.lines.add("sr " + li + " " + m.id + "|" + shortNm(m.rName, 16) + "|" + m.rClk + "|" + m.rTid);
        }
        return r;
    }

    /** تاريخ ESPN مثل 2026-11-23T20:00Z → مللي ثانية (UTC)، أو 0 إذا ما فهمه */
    private static long parseDate(String d) {
        if (d == null || d.length() < 16) return 0;
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return f.parse(d.substring(0, 16)).getTime();
        } catch (Exception e) { return 0; }
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
}
