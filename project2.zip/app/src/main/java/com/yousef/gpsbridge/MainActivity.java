package com.yousef.gpsbridge;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // ---------------- الحالة اللي تتشارك بين الخدمة والشاشة ----------------
    static volatile String sBt = "غير متصل";
    static volatile String sLoc = "-";
    static volatile String sHdg = "-";
    static volatile String sSpd = "-";
    static volatile String sTx = "-";
    static volatile String sRdrInfo = "-";
    static volatile String sScInfo = "-";
    static volatile boolean sRunning = false;
    static volatile int sLgMask = 63;     // أي دوريات يجلبها الجوال
    static volatile int sRange = 40;      // مدى الرادار (كم)
    static volatile int sLogVer = 0;
    static final ArrayList<String> sLog = new ArrayList<>();

    static void log(String s) {
        synchronized (sLog) {
            sLog.add(s);
            while (sLog.size() > 80) sLog.remove(0);
        }
        sLogVer++;
    }

    // الأوضاع اللي تدخل بالميكس المخصص: اسم الأمر + الوصف
    static final String[][] MIXI = {
            { "photos", "الصور" }, { "analog", "ساعة عقارب" }, { "digital", "ساعة رقمية" }, { "weather", "الطقس" },
            { "pendulum", "البندول" }, { "gforce", "قوة الحركة" }, { "alali", "العلي (عربي)" }, { "yousef", "يوسف (عربي)" },
            { "names", "الأسماء" }, { "yousefen", "Yousef إنجليزي" }, { "alalien", "Alali إنجليزي" }, { "mixen", "مكس إنجليزي" },
            { "mixaren", "مكس عربي/إنجليزي" }, { "hypno", "الخدع البصرية" }, { "compass", "البوصلة (يحتاج موقع)" },
            { "radar", "الرادار" }, { "scores", "النتائج (إذا في مباراة شغالة)" }, { "speed", "السرعة (يحتاج موقع)" } };
    static final String MIX_DEF = ",analog,weather,pendulum,gforce,compass,radar,scores,";
    static final int[] MIX_SECS = { 5, 10, 15, 20, 30, 60 };

    private static final int C_BG = Color.rgb(12, 12, 16);
    private static final int C_CARD = Color.rgb(32, 32, 40);
    private static final int C_BLUE = Color.rgb(48, 110, 210);
    private static final int C_PURP = Color.rgb(120, 80, 190);
    private static final int C_GOLD = Color.rgb(180, 130, 20);
    private static final int C_GRN = Color.rgb(30, 140, 80);
    private static final int C_RED = Color.rgb(190, 55, 55);
    private static final int C_GRAY = Color.rgb(70, 70, 82);

    private TextView tv, logTv;
    private Button btn;
    private LinearLayout content;
    private ScrollView scroll;
    private LinearLayout[] panels = new LinearLayout[4];
    private Button[] tabBtns = new Button[4];
    private Button[] subBtns = new Button[4];
    private LinearLayout ctlBody;
    private int tabSel = 0, subSel = 0, lastLogVer = -1;
    private SharedPreferences cfg;
    private final ArrayList<CheckBox> mixBoxes = new ArrayList<>();
    private int mixSec = 10;
    private final Button[] secBtns = new Button[MIX_SECS.length];
    private EditText cmdEdit;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ui = new Runnable() {
        @Override public void run() {
            tv.setText("الخدمة: " + (sRunning ? "شغالة" : "واقفة") + "   |   البلوتوث: " + sBt
                    + "\nالموقع: " + sLoc + "   |   الاتجاه: " + sHdg + "   |   السرعة: " + sSpd
                    + "\nرادار: " + sRdrInfo + "\nنتائج: " + sScInfo + "\nآخر إرسال: " + sTx);
            btn.setText(sRunning ? "إيقاف" : "ابدأ");
            if (lastLogVer != sLogVer) {
                lastLogVer = sLogVer;
                StringBuilder sb = new StringBuilder();
                synchronized (sLog) {
                    for (int i = sLog.size() - 1; i >= 0; i--) sb.append(sLog.get(i)).append('\n');
                }
                logTv.setText(sb.length() == 0 ? "(ما في ردود لين الحين)" : sb.toString());
            }
            h.postDelayed(this, 500);
        }
    };

    // ---------------- أدوات بناء الواجهة ----------------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Button mkBtn(String label, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(4), dp(6), dp(4));
        paint(b, color);
        b.setOnClickListener(l);
        return b;
    }

    private void paint(Button b, int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(12));
        b.setBackground(gd);
    }

    private Button cmdBtn(String label, final String cmd, int color) {
        return mkBtn(label, color, new View.OnClickListener() {
            @Override public void onClick(View v) { send(cmd); }
        });
    }

    private void send(String cmd) {
        if (Bridge.sendCmd(cmd)) log("> " + cmd);
        else Toast.makeText(this, "الإطار مو متصل (شغّل الخدمة وانتظر 'متصل')", Toast.LENGTH_SHORT).show();
    }

    private TextView title(String t) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(15);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setTextColor(Color.rgb(255, 205, 90));
        x.setTextDirection(View.TEXT_DIRECTION_RTL);
        x.setPadding(dp(4), dp(14), dp(4), dp(4));
        return x;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    /** شبكة أزرار: كل عنصر {نص، أمر} */
    private LinearLayout grid(String[][] items, int cols, int color) {
        LinearLayout col = vbox();
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(cmdBtn(items[i][0], items[i][1], color), lp);
        }
        int rem = items.length % cols;
        if (rem != 0 && row != null) {
            for (int k = rem; k < cols; k++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
                row.addView(new View(this), lp);
            }
        }
        return col;
    }

    /** صف أزرار أرقام 1..n لأمر مثل "cmp 3" */
    private LinearLayout numGrid(String prefix, int n, int color) {
        String[][] it = new String[n][2];
        for (int i = 0; i < n; i++) { it[i][0] = String.valueOf(i + 1); it[i][1] = prefix + " " + (i + 1); }
        return grid(it, 5, color);
    }

    private void selectSub(int i) {
        subSel = i;
        for (int k = 0; k < 4; k++) paint(subBtns[k], k == i ? C_BLUE : C_GRAY);
        ctlBody.removeAllViews();
        if (i == 0) {
            ctlBody.addView(grid(new String[][] {
                    { "الصور", "photos" }, { "ساعة عقارب", "analog" }, { "ساعة رقمية", "digital" }, { "الطقس", "weather" } }, 2, C_BLUE));
        } else if (i == 1) {
            ctlBody.addView(grid(new String[][] {
                    { "العلي", "alali" }, { "يوسف", "yousef" }, { "الأسماء", "names" }, { "Yousef EN", "yousefen" },
                    { "Alali EN", "alalien" }, { "مكس EN", "mixen" }, { "مكس عربي/EN", "mixaren" }, { "الخدع", "hypno" },
                    { "القوائم", "list" } }, 2, C_PURP));
        } else if (i == 2) {
            ctlBody.addView(grid(new String[][] {
                    { "البوصلة", "compass" }, { "الرادار", "radar" }, { "النتائج", "scores" }, { "السرعة", "speed" },
                    { "شكل البوصلة التالي", "cmp next" }, { "لون البوصلة", "cmp color" },
                    { "شكل السرعة التالي", "spd next" }, { "لون السرعة", "spd color" },
                    { "شكل الرادار التالي", "rdr next" }, { "الدوريات", "sc" } }, 2, C_GOLD));
        } else {
            ctlBody.addView(grid(new String[][] {
                    { "ريست بلوتوث", "rbt" }, { "ريست واي فاي", "rwf" }, { "شغّل الميكس", "mix" }, { "وقّف الميكس", "mix off" },
                    { "حالة الإطار", "status" }, { "تشخيص الشبكة", "net" }, { "الشاشة شغّل/طفي", "screen" } }, 2, C_RED));
        }
    }

    private void selectTab(int i) {
        tabSel = i;
        for (int k = 0; k < 4; k++) paint(tabBtns[k], k == i ? C_BLUE : C_CARD);
        content.removeAllViews();
        content.addView(panels[i]);
        scroll.scrollTo(0, 0);
    }

    // ---------------- تبويب التحكم ----------------
    private LinearLayout buildControl() {
        LinearLayout p = vbox();
        p.addView(grid(new String[][] { { "◀ السابقة", "prev" }, { "⏯ إيقاف مؤقت", "pause" }, { "التالية ▶", "next" },
                { "سطوع −", "bdn" }, { "سطوع +", "bup" }, { "ميكس", "mix" } }, 3, C_GRAY));
        LinearLayout sub = new LinearLayout(this);
        sub.setOrientation(LinearLayout.HORIZONTAL);
        String[] nm = { "SHOW", "NAMES", "TOOLS", "SYS" };
        for (int i = 0; i < 4; i++) {
            final int k = i;
            subBtns[i] = mkBtn(nm[i], C_GRAY, new View.OnClickListener() {
                @Override public void onClick(View v) { selectSub(k); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(dp(3), dp(10), dp(3), dp(6));
            sub.addView(subBtns[i], lp);
        }
        p.addView(sub);
        ctlBody = vbox();
        p.addView(ctlBody);
        selectSub(0);
        return p;
    }

    // ---------------- تبويب الميكس المخصص ----------------
    private boolean mixDefault(String name) { return MIX_DEF.contains("," + name + ","); }

    private LinearLayout buildMix() {
        LinearLayout p = vbox();
        TextView info = new TextView(this);
        info.setText("اختر الأوضاع اللي تدخل بالميكس، والمدة، وبعدها اضغط «طبّق على الإطار». "
                + "البوصلة والسرعة والرادار تطلع بس إذا الموقع واصل، والنتائج لما في مباراة شغالة.");
        info.setTextSize(13);
        info.setTextColor(Color.rgb(170, 170, 180));
        info.setTextDirection(View.TEXT_DIRECTION_RTL);
        p.addView(info);
        p.addView(title("الأوضاع"));
        mixBoxes.clear();
        for (int i = 0; i < MIXI.length; i++) {
            final String name = MIXI[i][0];
            CheckBox cb = new CheckBox(this);
            cb.setText(MIXI[i][1]);
            cb.setTextSize(16);
            cb.setTextColor(Color.WHITE);
            cb.setChecked(cfg.getBoolean("mix_" + name, mixDefault(name)));
            cb.setPadding(dp(6), dp(8), dp(6), dp(8));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    cfg.edit().putBoolean("mix_" + name, on).apply();
                }
            });
            mixBoxes.add(cb);
            p.addView(cb);
        }
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(smallBtn("الكل", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { for (CheckBox c : mixBoxes) c.setChecked(true); }
        }));
        quick.addView(smallBtn("مسح الكل", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { for (CheckBox c : mixBoxes) c.setChecked(false); }
        }));
        quick.addView(smallBtn("الافتراضي", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                for (int i = 0; i < mixBoxes.size(); i++) mixBoxes.get(i).setChecked(mixDefault(MIXI[i][0]));
            }
        }));
        p.addView(quick);

        p.addView(title("مدة كل وضع (ثواني)"));
        mixSec = cfg.getInt("mixSec", 10);
        LinearLayout secs = new LinearLayout(this);
        secs.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MIX_SECS.length; i++) {
            final int sec = MIX_SECS[i];
            secBtns[i] = smallBtn(String.valueOf(sec), sec == mixSec ? C_BLUE : C_GRAY, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    mixSec = sec;
                    cfg.edit().putInt("mixSec", sec).apply();
                    for (int k = 0; k < MIX_SECS.length; k++) paint(secBtns[k], MIX_SECS[k] == sec ? C_BLUE : C_GRAY);
                }
            });
            secs.addView(secBtns[i]);
        }
        p.addView(secs);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(dp(3), dp(18), dp(3), dp(4));
        p.addView(mkBtn("طبّق على الإطار", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) { applyMix(false); }
        }), lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp2.setMargins(dp(3), dp(4), dp(3), dp(4));
        p.addView(mkBtn("طبّق وشغّل الميكس", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) { applyMix(true); }
        }), lp2);
        return p;
    }

    private Button smallBtn(String t, int color, View.OnClickListener l) {
        Button b = mkBtn(t, color, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(3), dp(6), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private void applyMix(boolean start) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < mixBoxes.size(); i++) {
            if (mixBoxes.get(i).isChecked()) {
                if (sb.length() > 0) sb.append(',');
                sb.append(MIXI[i][0]);
            }
        }
        if (sb.length() == 0) {
            Toast.makeText(this, "اختر وضع واحد على الأقل", Toast.LENGTH_SHORT).show();
            return;
        }
        send("mixset " + sb);
        send("mixsec " + mixSec);
        if (start) send("mix");
    }

    // ---------------- تبويب الإعدادات ----------------
    private LinearLayout buildSettings() {
        LinearLayout p = vbox();
        p.addView(title("الدوريات (يجلبها الجوال)"));
        for (int i = 0; i < 6; i++) {
            final int li = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(Feeds.LG_AR[i]);
            cb.setTextSize(16);
            cb.setTextColor(Color.WHITE);
            cb.setChecked((sLgMask & (1 << i)) != 0);
            cb.setPadding(dp(6), dp(6), dp(6), dp(6));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    if (on) sLgMask |= (1 << li); else sLgMask &= ~(1 << li);
                    cfg.edit().putInt("lgMask", sLgMask).apply();
                    send("lg " + (li + 1) + (on ? " on" : " off"));
                }
            });
            p.addView(cb);
        }
        p.addView(title("تنبيه الهدف"));
        p.addView(grid(new String[][] { { "شغّل", "goal on" }, { "طفّي", "goal off" }, { "تجربة", "goal test" } }, 3, C_PURP));
        p.addView(title("مدى الرادار (كم)"));
        LinearLayout rr = new LinearLayout(this);
        rr.setOrientation(LinearLayout.HORIZONTAL);
        int[] ranges = { 20, 40, 80, 150, 250 };
        for (int i = 0; i < ranges.length; i++) {
            final int km = ranges[i];
            rr.addView(smallBtn(String.valueOf(km), C_GOLD, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    sRange = km;
                    cfg.edit().putInt("range", km).apply();
                    send("rdr r " + km);
                }
            }));
        }
        p.addView(rr);
        p.addView(title("شكل الرادار"));
        p.addView(numGrid("rdr", 9, C_GOLD));
        p.addView(grid(new String[][] { { "تلقائي", "rdr auto" } }, 1, C_GRAY));
        p.addView(title("شكل البوصلة (6 إلى 9 عربي)"));
        p.addView(numGrid("cmp", 9, C_BLUE));
        p.addView(grid(new String[][] { { "لون (للعربي 2 و5)", "cmp color" }, { "تلقائي", "cmp auto" } }, 2, C_GRAY));
        p.addView(title("شكل السرعة"));
        p.addView(numGrid("spd", 7, C_RED));
        p.addView(grid(new String[][] { { "لون (للشكل 5)", "spd color" }, { "تلقائي", "spd auto" }, { "صفّر MAX", "spd max" } }, 3, C_GRAY));
        p.addView(title("الساعات والطقس"));
        p.addView(numGrid("ana", 6, C_BLUE));
        p.addView(grid(new String[][] { { "رقمي 1", "dig 1" }, { "رقمي 2", "dig 2" }, { "رقمي 3", "dig 3" } }, 3, C_BLUE));
        p.addView(numGrid("wx", 5, C_BLUE));
        return p;
    }

    // ---------------- تبويب الردود ----------------
    private LinearLayout buildLog() {
        LinearLayout p = vbox();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        cmdEdit = new EditText(this);
        cmdEdit.setHint("أمر مباشر مثل: status");
        cmdEdit.setHintTextColor(Color.GRAY);
        cmdEdit.setTextColor(Color.WHITE);
        cmdEdit.setSingleLine(true);
        cmdEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        row.addView(cmdEdit, new LinearLayout.LayoutParams(0, dp(52), 1f));
        row.addView(smallBtn("إرسال", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String c = cmdEdit.getText().toString().trim();
                if (c.length() > 0) { send(c); cmdEdit.setText(""); }
            }
        }));
        row.addView(smallBtn("مسح", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                synchronized (sLog) { sLog.clear(); }
                sLogVer++;
            }
        }));
        p.addView(row);
        logTv = new TextView(this);
        logTv.setTextSize(13);
        logTv.setTypeface(Typeface.MONOSPACE);
        logTv.setTextColor(Color.rgb(200, 230, 200));
        logTv.setPadding(dp(4), dp(10), dp(4), dp(10));
        p.addView(logTv);
        return p;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = getSharedPreferences("cfg", MODE_PRIVATE);
        sLgMask = cfg.getInt("lgMask", 63);
        sRange = cfg.getInt("range", 40);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(36), dp(12), dp(8));
        root.setBackgroundColor(C_BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView ttl = new TextView(this);
        ttl.setText("جسر الإطار");
        ttl.setTextSize(20);
        ttl.setTypeface(Typeface.DEFAULT_BOLD);
        ttl.setTextColor(Color.WHITE);
        top.addView(ttl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btn = mkBtn("ابدأ", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (sRunning) {
                    stopService(new Intent(MainActivity.this, Bridge.class));
                    sRunning = false;
                } else {
                    askAndStart();
                }
            }
        });
        top.addView(btn, new LinearLayout.LayoutParams(dp(110), dp(48)));
        root.addView(top);

        tv = new TextView(this);
        tv.setTextSize(12);
        tv.setLineSpacing(0, 1.25f);
        tv.setTextColor(Color.rgb(200, 200, 212));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        tv.setPadding(dp(2), dp(6), dp(2), dp(6));
        root.addView(tv);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = { "التحكم", "ميكس مخصص", "إعدادات", "الردود" };
        for (int i = 0; i < 4; i++) {
            final int k = i;
            tabBtns[i] = mkBtn(tn[i], C_CARD, new View.OnClickListener() {
                @Override public void onClick(View v) { selectTab(k); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            tabs.addView(tabBtns[i], lp);
        }
        root.addView(tabs);

        scroll = new ScrollView(this);
        content = vbox();
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        panels[0] = buildControl();
        panels[1] = buildMix();
        panels[2] = buildSettings();
        panels[3] = buildLog();
        selectTab(0);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        lastLogVer = -1;
        h.post(ui);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(ui);
    }

    private void askAndStart() {
        ArrayList<String> need = new ArrayList<>();
        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        ArrayList<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            startBridge();
        } else {
            requestPermissions(missing.toArray(new String[0]), 7);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= 31) {
            ok = ok && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        if (ok) startBridge();
        else sBt = "لازم توافق على الأذونات";
    }

    private void startBridge() {
        Intent i = new Intent(this, Bridge.class);
        startForegroundService(i);
        sRunning = true;
    }

    // ------------------------------------------------------------------
    // الخدمة اللي تشتغل بالخلفية: موقع + اتجاه + بلوتوث + جلب الرادار والنتائج
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    public static class Bridge extends Service {
        static final UUID NUS = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
        static final String CH = "gpsbridge";

        static volatile Bridge sInst = null;

        private final Handler h = new Handler(Looper.getMainLooper());
        private LocationManager lm;
        private SensorManager sm;
        private BluetoothAdapter ad;
        private BluetoothLeScanner scanner;
        private volatile BluetoothGatt gatt;
        private volatile BluetoothGattCharacteristic rx;
        private volatile boolean ready = false;
        private volatile boolean discStarted = false;
        private boolean scanning = false;
        private boolean started = false;
        private boolean dead = false;
        private PowerManager.WakeLock wl;

        private Location loc;
        private long locAt = 0;
        private float compass = -1f;

        // طابور الكتابة: سطر كل 40 مللي ثانية
        private final ArrayDeque<String> queue = new ArrayDeque<>();
        private boolean pumping = false;
        private int writeFails = 0;
        private int payload = 20;                  // أكبر سطر نقدر نرسله (MTU - 3)

        // جلب البيانات من الإنترنت
        private final ExecutorService ex = Executors.newSingleThreadExecutor();
        private volatile boolean fetching = false;
        private long radarAt = 0;
        private final long[] lgAt = new long[6];
        private final boolean[] lgLive = new boolean[6];

        static boolean sendCmd(String c) {
            final Bridge b = sInst;
            if (b == null || !b.ready) return false;
            final String cc = c;
            b.h.post(new Runnable() { @Override public void run() { b.enqueue(cc, false); } });
            return true;
        }

        @Override public IBinder onBind(Intent i) { return null; }

        @Override public int onStartCommand(Intent in, int flags, int id) {
            if (!started) {
                started = true;
                dead = false;
                sInst = this;
                goForeground();
                initAll();
            }
            return START_STICKY;
        }

        private void goForeground() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CH, "جسر الموقع", NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("جسر الإطار شغال")
                    .setContentText("يرسل الموقع والرادار والنتائج للإطار")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else {
                startForeground(1, n);
            }
        }

        private void initAll() {
            SharedPreferences cfg = getSharedPreferences("cfg", MODE_PRIVATE);
            sLgMask = cfg.getInt("lgMask", 63);
            sRange = cfg.getInt("range", 40);

            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gpsbridge:wl");
            wl.acquire();

            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            try {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0,
                            ll, Looper.getMainLooper());
                } else {
                    sLoc = "شغّل الموقع GPS";
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0,
                            ll, Looper.getMainLooper());
                }
            } catch (Exception e) {
                sLoc = "خطأ: " + e.getMessage();
            }

            sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (rv != null) {
                sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
            } else {
                sHdg = "ما في حساس اتجاه";
            }

            BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            ad = bm.getAdapter();
            if (ad == null || !ad.isEnabled()) {
                sBt = "شغّل البلوتوث";
            }
            startScan();
            h.postDelayed(tick, 1000);
        }

        // ---------------- الموقع ----------------
        private final LocationListener ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                // نفضّل GPS على الشبكة إذا كان GPS حديث
                if (loc != null && LocationManager.GPS_PROVIDER.equals(loc.getProvider())
                        && !LocationManager.GPS_PROVIDER.equals(l.getProvider())
                        && System.currentTimeMillis() - locAt < 5000) {
                    return;
                }
                loc = l;
                locAt = System.currentTimeMillis();
                sLoc = String.format(Locale.US, "%.4f , %.4f", l.getLatitude(), l.getLongitude());
            }
            @Override public void onStatusChanged(String p, int s, Bundle e) { }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
        };

        // ---------------- البوصلة ----------------
        private final SensorEventListener sl = new SensorEventListener() {
            final float[] R = new float[9];
            final float[] R2 = new float[9];
            final float[] o = new float[3];
            float sx = 0f, sy = 0f;
            boolean has = false;

            @Override public void onSensorChanged(SensorEvent e) {
                SensorManager.getRotationMatrixFromVector(R, e.values);
                float[] use = R;
                // الجوال واقف (مثبت بالسيارة): نستخدم اتجاه الكاميرا الخلفية
                if (Math.abs(R[8]) < 0.7f) {
                    SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_X,
                            SensorManager.AXIS_Z, R2);
                    use = R2;
                }
                SensorManager.getOrientation(use, o);
                double az = Math.toDegrees(o[0]);
                if (loc != null) {
                    GeomagneticField g = new GeomagneticField((float) loc.getLatitude(),
                            (float) loc.getLongitude(), (float) loc.getAltitude(),
                            System.currentTimeMillis());
                    az += g.getDeclination();
                }
                double r = Math.toRadians(az);
                float cx = (float) Math.cos(r), cy = (float) Math.sin(r);
                if (!has) { sx = cx; sy = cy; has = true; }
                else { sx = sx * 0.85f + cx * 0.15f; sy = sy * 0.85f + cy * 0.15f; }
                compass = (float) ((Math.toDegrees(Math.atan2(sy, sx)) + 360.0) % 360.0);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) { }
        };

        // ---------------- البلوتوث ----------------
        private void startScan() {
            if (dead) return;
            try {
                if (ad == null || !ad.isEnabled()) {
                    sBt = "شغّل البلوتوث";
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                scanner = ad.getBluetoothLeScanner();
                if (scanner == null) {
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                if (scanning) return;
                scanning = true;
                sBt = "يدور على الإطار...";
                scanner.startScan(scb);
            } catch (Exception e) {
                scanning = false;
                sBt = "خطأ بحث: " + e.getMessage();
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        }

        private void stopScan() {
            try {
                if (scanning && scanner != null) scanner.stopScan(scb);
            } catch (Exception ignored) { }
            scanning = false;
        }

        private final ScanCallback scb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult r) {
                if (gatt != null || dead) return;
                String n = null;
                ScanRecord sr = r.getScanRecord();
                if (sr != null) n = sr.getDeviceName();
                if (n == null) n = r.getDevice().getName();
                if (n != null && n.startsWith("Photo")) {
                    stopScan();
                    sBt = "يتصل...";
                    discStarted = false;
                    gatt = r.getDevice().connectGatt(Bridge.this, false, cb,
                            BluetoothDevice.TRANSPORT_LE);
                }
            }
            @Override public void onScanFailed(int err) {
                scanning = false;
                sBt = "فشل البحث (" + err + ")";
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        };

        private void startDiscovery(BluetoothGatt g) {
            if (discStarted) return;
            discStarted = true;
            g.discoverServices();
        }

        private void markReady() {
            if (ready) return;
            ready = true;
            sBt = "متصل";
            radarAt = 0;                                   // أول ما نتصل نجيب البيانات فوراً
            for (int i = 0; i < 6; i++) lgAt[i] = 0;
            log("— اتصل بالإطار —");
        }

        private final BluetoothGattCallback cb = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(final BluetoothGatt g, int status, int ns) {
                if (ns == BluetoothGatt.STATE_CONNECTED) {
                    sBt = "متصل (يجهز)";
                    if (!g.requestMtu(185)) startDiscovery(g);
                    h.postDelayed(new Runnable() {
                        @Override public void run() { startDiscovery(g); }
                    }, 2500);
                } else {
                    ready = false;
                    rx = null;
                    gatt = null;
                    queue.clear();
                    pumping = false;
                    try { g.close(); } catch (Exception ignored) { }
                    sBt = "انقطع، يعيد المحاولة";
                    if (!dead) {
                        h.postDelayed(new Runnable() {
                            @Override public void run() { startScan(); }
                        }, 3000);
                    }
                }
            }

            @Override public void onMtuChanged(BluetoothGatt g, int mtu, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS && mtu > 23) payload = mtu - 3;
                startDiscovery(g);
            }

            @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
                BluetoothGattService s = g.getService(NUS);
                BluetoothGattCharacteristic c = (s == null) ? null : s.getCharacteristic(RX);
                if (c == null) {
                    sBt = "خدمة الإطار مو موجودة";
                    g.disconnect();
                    return;
                }
                c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                rx = c;
                // نشترك بردود الإطار (TX) عشان تطلع بتبويب الردود
                boolean waiting = false;
                try {
                    BluetoothGattCharacteristic t = s.getCharacteristic(TX);
                    if (t != null) {
                        g.setCharacteristicNotification(t, true);
                        BluetoothGattDescriptor d = t.getDescriptor(CCCD);
                        if (d != null) {
                            d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            waiting = g.writeDescriptor(d);
                        }
                    }
                } catch (Exception ignored) { }
                if (waiting) {
                    h.postDelayed(new Runnable() { @Override public void run() { markReady(); } }, 1500);
                } else {
                    markReady();
                }
            }

            @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
                markReady();
            }

            @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
                try {
                    byte[] v = c.getValue();
                    if (v == null) return;
                    String t = new String(v, StandardCharsets.UTF_8).trim();
                    if (t.length() > 0) log("< " + t);
                } catch (Exception ignored) { }
            }
        };

        // ---------------- طابور الكتابة ----------------
        private void enqueue(String line, boolean front) {
            if (!ready) return;
            if (queue.size() > 160) return;
            String l = line;
            if (l.length() > payload) {                    // أطول من الحزمة: ما نرسله مقطوع (يخرب الأمر)
                if (!l.startsWith("rp ") && !l.startsWith("sm ")) log("! الأمر أطول من حجم الحزمة (" + payload + ")");
                return;
            }
            if (front) queue.addFirst(l); else queue.addLast(l);
            if (!pumping) {
                pumping = true;
                h.post(pump);
            }
        }

        private boolean writeLine(BluetoothGatt g, BluetoothGattCharacteristic c, String line) {
            byte[] b = line.getBytes(StandardCharsets.US_ASCII);
            if (Build.VERSION.SDK_INT >= 33) {
                return g.writeCharacteristic(c, b, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == 0;
            }
            c.setValue(b);
            return g.writeCharacteristic(c);
        }

        private final Runnable pump = new Runnable() {
            @Override public void run() {
                BluetoothGatt g = gatt;
                BluetoothGattCharacteristic c = rx;
                if (!ready || g == null || c == null) { queue.clear(); pumping = false; return; }
                String line = queue.pollFirst();
                if (line == null) { pumping = false; return; }
                boolean ok = false;
                try { ok = writeLine(g, c, line); } catch (Exception ignored) { }
                if (!ok && ++writeFails < 20) {
                    queue.addFirst(line);                  // الخط مشغول: نعيد بعد شوي
                    h.postDelayed(this, 80);
                    return;
                }
                writeFails = 0;
                h.postDelayed(this, 40);
            }
        };

        // ---------------- جلب الرادار والنتائج ----------------
        private void startFetch(final boolean radar, final int li, final double lat, final double lon, final int range) {
            fetching = true;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> lines;
                        boolean live = false;
                        if (radar) {
                            lines = Feeds.radar(lat, lon, range);
                            sRdrInfo = (lines.size() == 1 && lines.get(0).equals("rp 0 0") ? 0 : lines.size())
                                    + " طيارة | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        } else {
                            Feeds.Scores sc = Feeds.scores(li);
                            lines = sc.lines;
                            live = sc.live;
                            sScInfo = Feeds.LG_AR[li] + ": " + (lines.size() == 1 && lines.get(0).endsWith(" 0 0") ? 0 : lines.size())
                                    + " مباراة | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        }
                        if (!radar) lgLive[li] = live;
                        h.post(new Runnable() {
                            @Override public void run() {
                                for (String l : lines) enqueue(l, false);
                            }
                        });
                    } catch (Exception e) {
                        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        if (radar) sRdrInfo = "خطأ: " + m; else sScInfo = "خطأ: " + m;
                    } finally {
                        fetching = false;
                    }
                }
            });
        }

        private void feedStep() {
            if (!ready || fetching || payload < 100) return;
            long now = SystemClock.elapsedRealtime();
            Location l = loc;
            if (l != null && System.currentTimeMillis() - locAt < 60000 && (radarAt == 0 || now - radarAt >= 15000)) {
                radarAt = now;
                startFetch(true, 0, l.getLatitude(), l.getLongitude(), sRange);
                return;
            }
            for (int li = 0; li < 6; li++) {
                if ((sLgMask & (1 << li)) == 0) continue;
                long every = lgLive[li] ? 20000 : 120000;
                if (lgAt[li] == 0 || now - lgAt[li] >= every) {
                    lgAt[li] = now;
                    startFetch(false, li, 0, 0, 0);
                    return;
                }
            }
        }

        // ---------------- الإرسال كل ثانية ----------------
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                try {
                    Location l = loc;
                    long age = System.currentTimeMillis() - locAt;
                    if (l != null) {
                        float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                        int hdg = -1;
                        if (kmh >= 7f && l.hasBearing()) hdg = Math.round(l.getBearing()) % 360;
                        else if (compass >= 0f) hdg = Math.round(compass) % 360;
                        sHdg = hdg < 0 ? "-" : hdg + "°";
                        sSpd = Math.round(kmh) + " km/h";
                        if (age > 15000) sLoc = "الموقع قديم، انتظر GPS";
                        if (ready && age < 15000) {
                            String line = String.format(Locale.US, "gps %.4f %.4f %d %d",
                                    l.getLatitude(), l.getLongitude(), hdg, Math.round(kmh));
                            if (queue.size() < 40) enqueue(line, true);
                            sTx = new java.text.SimpleDateFormat("HH:mm:ss", Locale.US)
                                    .format(new java.util.Date());
                        }
                    } else if (!sLoc.startsWith("شغّل") && !sLoc.startsWith("خطأ")) {
                        sLoc = "ينتظر إشارة GPS...";
                    }
                    feedStep();
                } catch (Exception ignored) { }
                if (!dead) h.postDelayed(this, 1000);
            }
        };

        @Override public void onDestroy() {
            dead = true;
            started = false;
            sInst = null;
            h.removeCallbacksAndMessages(null);
            try { ex.shutdownNow(); } catch (Exception ignored) { }
            try { lm.removeUpdates(ll); } catch (Exception ignored) { }
            try { sm.unregisterListener(sl); } catch (Exception ignored) { }
            stopScan();
            try {
                BluetoothGatt g = gatt;
                if (g != null) { g.disconnect(); g.close(); }
            } catch (Exception ignored) { }
            gatt = null;
            ready = false;
            try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
            sRunning = false;
            sBt = "غير متصل";
            super.onDestroy();
        }
    }
}
