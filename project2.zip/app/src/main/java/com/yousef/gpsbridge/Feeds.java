package com.yousef.gpsbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** جلب الرادار والنتائج من الإنترنت (من الجوال) وتحويلها لأسطر مضغوطة يفهمها الإطار. */
final class Feeds {
    private Feeds() { }

    static final String[] SLUG = { "eng.1", "esp.1", "ita.1", "ger.1", "uefa.champions", "uefa.europa" };
    static final String[] LG_AR = { "الدوري الإنجليزي", "الدوري الإسباني", "الدوري الإيطالي",
            "الدوري الألماني", "دوري الأبطال", "الدوري الأوروبي" };

    static String get(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) PhotoFrameBridge");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (bo.size() > 4 * 1024 * 1024) throw new IOException("too big");
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    /** يحوّل الحروف الأوروبية لإنجليزية ويشيل الفواصل اللي تخرب البروتوكول، ويقص الطول. */
    static String clean(String s, int max) {
        if (s == null) return "";
        String t = Normalizer.normalize(s, Normalizer.Form.NFD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length() && sb.length() < max; i++) {
            char ch = t.charAt(i);
            if (ch == '|' || ch == ';' || ch == '\n' || ch == '\r' || ch == '\t') ch = ' ';
            if (ch >= 32 && ch < 127) sb.append(ch);
            else if (ch >= 0x300 && ch < 0x370) continue;   // علامات التشكيل بعد التفكيك
            else if (ch == 0xF8) sb.append('o');
            else if (ch == 0xD8) sb.append('O');
            else if (ch == 0xDF) sb.append("ss");
            else if (ch == 0x141) sb.append('L');
            else if (ch == 0x142) sb.append('l');
            else sb.append('?');
        }
        return sb.toString().trim();
    }

    private static final class Ac {
        double km, brg, trk, alt, gs;
        String fl;
    }

    /** أسطر الرادار: الأقرب أول. إذا ما في طيارات يرجع سطر واحد "rp 0 0". */
    static List<String> radar(double lat0, double lon0, int rangeKm) throws Exception {
        int nm = (int) Math.ceil(rangeKm / 1.852);
        if (nm < 5) nm = 5;
        if (nm > 250) nm = 250;
        String p = String.format(Locale.US, "%.4f/%.4f/%d", lat0, lon0, nm);
        String body;
        try {
            body = get("https://api.adsb.lol/v2/point/" + p);
        } catch (Exception e) {
            body = get("https://api.airplanes.live/v2/point/" + p);
        }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("ac");
        if (arr == null) arr = o.optJSONArray("aircraft");
        ArrayList<Ac> list = new ArrayList<>();
        double cl = Math.cos(Math.toRadians(lat0));
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.optJSONObject(i);
                if (a == null || !a.has("lat") || !a.has("lon")) continue;
                double dx = (a.optDouble("lon") - lon0) * cl * 111.32;
                double dy = (a.optDouble("lat") - lat0) * 110.57;
                double km = Math.sqrt(dx * dx + dy * dy);
                if (km > rangeKm * 1.05) continue;
                Ac x = new Ac();
                x.km = km;
                double b = Math.toDegrees(Math.atan2(dx, dy));
                x.brg = b < 0 ? b + 360 : b;
                x.trk = a.optDouble("track", 0);
                Object ab = a.opt("alt_baro");
                x.alt = (ab instanceof Number) ? ((Number) ab).doubleValue() : 0;
                x.gs = a.optDouble("gs", 0);
                String fl = clean(a.optString("flight", ""), 8).replace(" ", "");
                x.fl = fl.isEmpty() ? "-" : fl;
                list.add(x);
            }
        }
        Collections.sort(list, new Comparator<Ac>() {
            @Override public int compare(Ac a, Ac b) { return Double.compare(a.km, b.km); }
        });
        ArrayList<String> out = new ArrayList<>();
        int n = Math.min(list.size(), 24);
        if (n == 0) {
            out.add("rp 0 0");
            return out;
        }
        for (int i = 0; i < n; i++) {
            Ac x = list.get(i);
            out.add(String.format(Locale.US, "rp %d %d %.1f %.0f %.0f %.0f %.0f %s",
                    i, n, x.km, x.brg, x.trk, x.alt, x.gs, x.fl));
        }
        return out;
    }

    /** نتيجة دوري: الأسطر + هل في مباراة شغالة (عشان نعرف نحدّث كل 20 ثانية). */
    static final class Scores {
        final ArrayList<String> lines = new ArrayList<>();
        boolean live = false;
    }

    private static int rank(int st) { return st == 1 ? 0 : st == 2 ? 1 : 2; }

    private static final class M {
        String id = "", hA = "", aA = "", hN = "", aN = "", hId = "", aId = "", clk = "", gName = "", gClk = "", gTid = "";
        int hs, as, state;
    }

    static Scores scores(int li) throws Exception {
        String body = get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + SLUG[li] + "/scoreboard");
        JSONObject o = new JSONObject(body);
        JSONArray ev = o.optJSONArray("events");
        ArrayList<M> ms = new ArrayList<>();
        if (ev != null) {
            for (int i = 0; i < ev.length() && ms.size() < 14; i++) {
                JSONObject e = ev.optJSONObject(i);
                if (e == null) continue;
                M m = new M();
                m.id = clean(e.optString("id", ""), 11);
                JSONObject st = e.optJSONObject("status");
                if (st != null) {
                    m.clk = clean(st.optString("displayClock", ""), 9);
                    JSONObject ty = st.optJSONObject("type");
                    String s = ty == null ? "" : ty.optString("state", "");
                    m.state = "in".equals(s) ? 1 : "post".equals(s) ? 2 : 0;
                }
                JSONArray comps = e.optJSONArray("competitions");
                JSONObject comp = comps == null ? null : comps.optJSONObject(0);
                if (comp == null) continue;
                JSONArray cs = comp.optJSONArray("competitors");
                if (cs == null || cs.length() < 2) continue;
                JSONObject home = null, away = null;
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject c = cs.optJSONObject(k);
                    if (c == null) continue;
                    String ha = c.optString("homeAway", "");
                    if ("home".equals(ha)) home = c;
                    else if ("away".equals(ha)) away = c;
                }
                if (home == null) home = cs.optJSONObject(0);
                if (away == null) away = cs.optJSONObject(1);
                if (home == null || away == null) continue;
                JSONObject ht = home.optJSONObject("team"), at = away.optJSONObject("team");
                if (ht != null) {
                    m.hA = clean(ht.optString("abbreviation", ""), 5);
                    m.hN = clean(ht.optString("displayName", ""), 23);
                    m.hId = clean(ht.optString("id", ""), 7);
                }
                if (at != null) {
                    m.aA = clean(at.optString("abbreviation", ""), 5);
                    m.aN = clean(at.optString("displayName", ""), 23);
                    m.aId = clean(at.optString("id", ""), 7);
                }
                m.hs = parseInt(home.optString("score", "0"));
                m.as = parseInt(away.optString("score", "0"));
                JSONArray det = comp.optJSONArray("details");
                if (det != null) {
                    for (int k = 0; k < det.length(); k++) {
                        JSONObject d = det.optJSONObject(k);
                        if (d == null || !d.optBoolean("scoringPlay", false)) continue;
                        JSONArray ai = d.optJSONArray("athletesInvolved");
                        JSONObject a0 = ai == null ? null : ai.optJSONObject(0);
                        JSONObject ck = d.optJSONObject("clock");
                        JSONObject tm = d.optJSONObject("team");
                        m.gName = a0 == null ? "" : clean(a0.optString("displayName", ""), 21);
                        m.gClk = ck == null ? "" : clean(ck.optString("displayValue", ""), 7);
                        m.gTid = tm == null ? "" : clean(tm.optString("id", ""), 7);
                    }
                }
                ms.add(m);
            }
        }
        Collections.sort(ms, new Comparator<M>() {                         // ثابت: شغالة، منتهية، قادمة
            @Override public int compare(M a, M b) { return rank(a.state) - rank(b.state); }
        });
        Scores r = new Scores();
        int n = ms.size();
        if (n == 0) {
            r.lines.add("sm " + li + " 0 0");
            return r;
        }
        for (int i = 0; i < n; i++) {
            M m = ms.get(i);
            if (m.state == 1) r.live = true;
            r.lines.add("sm " + li + " " + i + " " + n + " " + m.id + "|" + m.hA + "|" + m.aA + "|" + m.hN + "|" + m.aN + "|"
                    + m.hId + "|" + m.aId + "|" + m.hs + "|" + m.as + "|" + m.state + "|" + m.clk + "|"
                    + m.gName + "|" + m.gClk + "|" + m.gTid);
        }
        return r;
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
}
