package com.yousef.gpsbridge;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {

    // ---------------- الحالة اللي تتشارك بين الخدمة والشاشة ----------------
    static volatile String sBt = "غير متصل";
    static volatile String sLoc = "-";
    static volatile String sHdg = "-";
    static volatile String sSpd = "-";
    static volatile String sTx = "-";
    static volatile String sRdrInfo = "-";
    static volatile String sScInfo = "-";
    static volatile String sEmInfo = "-";
    static volatile int sEmKm = 250;      // مدى فحص الطوارئ (كم)، 0 = متوقف
    static volatile String sCamInfo = "-";
    static volatile boolean sCamForce = false;    // اضغط فحص/تحديث: يجلب كاميرات OSM الحين
    static volatile boolean sWantList = false;
    static volatile String sCamList = null;
    static volatile int sFlash = -1, sCamAdd = -1, sMapNames = -1, sMapLm = -1, sMapCams = -1;   // حالة الشهاب والتأكيد والخريطة (-1 = مجهول)
    static volatile boolean sMapWanted = false, sMapForce = false;     // الإطار فاتح الخريطة الحين / نبي نرسل من جديد
    static volatile String sMapInfo = "", sMapDl = "";
    static final AtomicBoolean mapStop = new AtomicBoolean(false);
    static volatile boolean mapDlBusy = false;
    static volatile int sMa = -1, sCamOn = -1, sCamSnd = -1;            // حالة الجهاز الفعلية (-1 = ما نعرف بعد)
    static volatile int sRdrN = 0, sScN = 0, sCamN = 0, sScErrN = 0;   // عدّادات انتهاء الجلب (لأزرار التحديث)
    static volatile boolean sRdrForce = false, sLgForce = false;
    static volatile boolean sRunning = false;
    static volatile int sLgMask = 255;     // أي دوريات يجلبها الجوال
    static volatile int sRange = 40;      // مدى الرادار (كم)
    static volatile int sLogVer = 0;
    static final ArrayList<String> sLog = new ArrayList<>();

    static void log(String s) {
        synchronized (sLog) {
            sLog.add(s);
            while (sLog.size() > 80) sLog.remove(0);
        }
        sLogVer++;
    }

    // الأوضاع اللي تدخل بالميكس المخصص: اسم الأمر + الوصف
    static final String[][] MIXI = {
            { "photos", "الصور" }, { "analog", "ساعة عقارب" }, { "digital", "ساعة رقمية" }, { "weather", "الطقس" },
            { "pendulum", "البندول" }, { "gforce", "قوة الحركة" }, { "alali", "العلي (عربي)" }, { "yousef", "يوسف (عربي)" },
            { "names", "الأسماء" }, { "yousefen", "Yousef إنجليزي" }, { "alalien", "Alali إنجليزي" }, { "mixen", "مكس إنجليزي" },
            { "mixaren", "مكس عربي/إنجليزي" }, { "ymix", "يوسف عربي/إنجليزي" }, { "amix", "Alali إنجليزي/عربي" }, { "hypno", "الخدع البصرية" }, { "compass", "البوصلة (يحتاج موقع)" },
            { "radar", "الرادار" }, { "scores", "النتائج (إذا في مباراة شغالة)" }, { "speed", "السرعة (يحتاج موقع)" }, { "camrad", "رادار الكاميرات (يحتاج موقع)" }, { "map", "الخريطة (يحتاج موقع)" } };
    static final String MIX_DEF = ",analog,weather,pendulum,gforce,compass,radar,scores,";
    static final int[] MIX_SECS = { 5, 10, 15, 20, 30, 60 };

    private static final int C_BG = Color.rgb(12, 12, 16);
    private static final int C_CARD = Color.rgb(32, 32, 40);
    private static final int C_BLUE = Color.rgb(48, 110, 210);
    private static final int C_PURP = Color.rgb(120, 80, 190);
    private static final int C_ORG = Color.rgb(200, 110, 20);
    private static final int C_GOLD = Color.rgb(180, 130, 20);
    private static final int C_GRN = Color.rgb(30, 140, 80);
    private static final int C_RED = Color.rgb(190, 55, 55);
    private static final int C_GRAY = Color.rgb(70, 70, 82);

    private TextView tv, logTv;
    private Button btn;
    private LinearLayout content;
    private ScrollView scroll;
    private LinearLayout[] panels = new LinearLayout[4];
    private Button[] tabBtns = new Button[4];
    private TextView[] dots = new TextView[6];
    private TextView stLine;
    private LinearLayout miniPanel;
    private String curScreen = "-";
    private Button[] subBtns = new Button[4];
    private LinearLayout ctlBody;
    private int tabSel = 0, subSel = 0, lastLogVer = -1;
    private SharedPreferences cfg;
    private final ArrayList<CheckBox> mixBoxes = new ArrayList<>();
    private int mixSec = 10;
    private final Button[] secBtns = new Button[MIX_SECS.length];
    private EditText cmdEdit;

    // اسم الشبكة اللي شابك عليها الجوال (واي فاي: الاسم، أو بيانات الجوال)
    @SuppressLint({"MissingPermission", "deprecation"})
    private String netName() {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.Network n = cm == null ? null : cm.getActiveNetwork();
            android.net.NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc == null) return "ما في إنترنت";
            if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) {
                android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                String ssid = wm == null || wm.getConnectionInfo() == null ? null : wm.getConnectionInfo().getSSID();
                if (ssid != null) ssid = ssid.replace("\"", "");
                if (ssid == null || ssid.length() == 0 || ssid.contains("unknown ssid")) return "واي فاي (الاسم مخفي: فعّل الموقع)";
                return "واي فاي: " + ssid;
            }
            if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)) return "بيانات الجوال";
            if (nc.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)) return "كيبل";
            return "متصل";
        } catch (Exception e) { return "-"; }
    }

    static volatile String sBatt = "-";
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ui = new Runnable() {
        @Override public void run() {
            tv.setText("الخدمة: " + (sRunning ? "شغالة" : "واقفة") + "   |   البلوتوث: " + sBt
                    + "\nالإنترنت: " + netName()
                    + "\nالموقع: " + sLoc + "   |   الاتجاه: " + sHdg + "   |   السرعة: " + sSpd
                    + "\nرادار: " + sRdrInfo + "\nنتائج: " + sScInfo + "\nطوارئ: " + sEmInfo + "\nكاميرات: " + sCamInfo + "\nالبطارية: " + sBatt + "\nآخر إرسال: " + sTx);
            btn.setText(sRunning ? "إيقاف" : "ابدأ");
            statusTick();
            if (lastLogVer != sLogVer) {
                lastLogVer = sLogVer;
                StringBuilder sb = new StringBuilder();
                synchronized (sLog) {
                    for (int i = sLog.size() - 1; i >= 0; i--) sb.append(sLog.get(i)).append('\n');
                }
                logTv.setText(sb.length() == 0 ? "(ما في ردود لين الحين)" : sb.toString());
            }
            if (sWantList && sCamList != null) { sWantList = false; showCamList(sCamList); }
            refTick();
            swSync();
            h.postDelayed(this, 500);
        }
    };

    // ---------------- أدوات بناء الواجهة ----------------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Button mkBtn(String label, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(4), dp(6), dp(4));
        paint(b, color);
        b.setOnClickListener(l);
        return b;
    }

    private void paint(Button b, int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(12));
        b.setBackground(gd);
    }

    private Button cmdBtn(String label, final String cmd, int color) {
        return mkBtn(label, color, new View.OnClickListener() {
            @Override public void onClick(View v) { send(cmd); }
        });
    }

    private void send(String cmd) {
        if (cmd.startsWith("@mapdl")) { startMapDl(Integer.parseInt(cmd.substring(6))); return; }     // أزرار تنزيل الخرائط (محلية بالتطبيق)
        if (cmd.equals("@mapimp")) {
            if (mapDlBusy) { Toast.makeText(this, "في تنزيل شغّال، أوقفه أول", Toast.LENGTH_SHORT).show(); return; }
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("*/*");
            startActivityForResult(pick, 77); return;
        }
        if (cmd.equals("@bkp")) { backupSettings(); return; }
        if (cmd.equals("@rst")) { restoreSettings(); return; }
        if (cmd.equals("@mapstop")) { mapStop.set(true); Toast.makeText(this, "جاري الإيقاف...", Toast.LENGTH_SHORT).show(); return; }
        if (Bridge.sendCmd(cmd)) log("> " + cmd);
        else Toast.makeText(this, "الإطار مو متصل (شغّل الخدمة وانتظر 'متصل')", Toast.LENGTH_SHORT).show();
    }

    private TextView title(String t) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(15);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setTextColor(Color.rgb(255, 205, 90));
        x.setTextDirection(View.TEXT_DIRECTION_RTL);
        x.setPadding(dp(4), dp(14), dp(4), dp(4));
        return x;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    /** شبكة أزرار: كل عنصر {نص، أمر} */
    private LinearLayout grid(String[][] items, int cols, int color) {
        LinearLayout col = vbox();
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(cmdBtn(items[i][0], items[i][1], color), lp);
        }
        int rem = items.length % cols;
        if (rem != 0 && row != null) {
            for (int k = rem; k < cols; k++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
                row.addView(new View(this), lp);
            }
        }
        return col;
    }

    /** صف أزرار أرقام 1..n لأمر مثل "cmp 3" */
    private LinearLayout numGrid(String prefix, int n, int color) {
        String[][] it = new String[n][2];
        for (int i = 0; i < n; i++) { it[i][0] = String.valueOf(i + 1); it[i][1] = prefix + " " + (i + 1); }
        return grid(it, 5, color);
    }



    // ---------------- مفاتيح تشغيل/إيقاف (أخضر = شغّال، أحمر = متوقف) ----------------
    private static class SwRow { LinearLayout track; View thumb; TextView st; int kind; }
    private final ArrayList<SwRow> swRows = new ArrayList<>();

    private int swState(int kind) {                        // 1 شغّال، 0 متوقف، -1 مجهول
        if (kind == 0) return sMa;
        if (kind == 1) return sCamOn;
        if (kind == 3) return sCamSnd;
        if (kind == 4) return sFlash;
        if (kind == 5) return sCamAdd;
        if (kind == 6) return sMapNames;
        if (kind == 7) return sMapLm;
        if (kind == 8) return sMapCams;
        if (kind == 9) return cfg.getBoolean("mapSync", true) ? 1 : 0;
        if (kind == 10) return cfg.getBoolean("carOn", true) ? 1 : 0;
        if (kind == 12) return cfg.getBoolean("goalSide", true) ? 1 : 0;
        if (kind == 14) return cfg.getBoolean("rdrRed", true) ? 1 : 0;
        if (kind == 13) return cfg.getBoolean("ftOn", true) ? 1 : 0;
        if (kind == 15) return cfg.getBoolean("battScr", false) ? 1 : 0;
        if (kind == 16) return cfg.getBoolean("rdrUp", true) ? 1 : 0;
        if (kind == 11) return cfg.getBoolean("keepNext", true) ? 1 : 0;
        return sEmKm > 0 ? 1 : 0;
    }

    private void swApply(SwRow r) {
        int st = swState(r.kind);
        int col = st == 1 ? Color.rgb(34, 197, 94) : st == 0 ? Color.rgb(239, 68, 68) : Color.rgb(120, 120, 130);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(col);
        gd.setCornerRadius(dp(14));
        r.track.setBackground(gd);
        r.track.setGravity(st == 1 ? Gravity.RIGHT | Gravity.CENTER_VERTICAL : Gravity.LEFT | Gravity.CENTER_VERTICAL);
        r.st.setText(st == 1 ? "شغّال" : st == 0 ? "متوقف" : "...");
    }

    private void swToggle(SwRow r, String name) {
        int cur = swState(r.kind);
        boolean on = cur != 1;                              // نقلب الحالة (المجهول يعتبر شغّال فنوقفه)
        if (cur == -1) on = false;
        if (r.kind == 0) { sMa = on ? 1 : 0; send("malert " + (on ? "on" : "off")); }
        else if (r.kind == 1) { sCamOn = on ? 1 : 0; send("cam " + (on ? "on" : "off")); }
        else if (r.kind == 3) { sCamSnd = on ? 1 : 0; send("camsnd " + (on ? "on" : "off")); }
        else if (r.kind == 4) { sFlash = on ? 1 : 0; send("flash " + (on ? "on" : "off")); }
        else if (r.kind == 5) { sCamAdd = on ? 1 : 0; send("camadd " + (on ? "on" : "off")); }
        else if (r.kind == 6) { sMapNames = on ? 1 : 0; send("map names " + (on ? "on" : "off")); }
        else if (r.kind == 7) { sMapLm = on ? 1 : 0; send("map lm " + (on ? "on" : "off")); }
        else if (r.kind == 8) { sMapCams = on ? 1 : 0; send("map cams " + (on ? "on" : "off")); }
        else if (r.kind == 10) { cfg.edit().putBoolean("carOn", on).apply(); send("car " + (on ? "on" : "off")); }
        else if (r.kind == 12) { cfg.edit().putBoolean("goalSide", on).apply(); send("goalside " + (on ? "on" : "off")); }
        else if (r.kind == 14) { cfg.edit().putBoolean("rdrRed", on).apply(); }
        else if (r.kind == 13) { cfg.edit().putBoolean("ftOn", on).apply(); send("ft " + (on ? "on" : "off")); }
        else if (r.kind == 15) { cfg.edit().putBoolean("battScr", on).apply(); send("battscr " + (on ? "on" : "off")); }
        else if (r.kind == 16) { cfg.edit().putBoolean("rdrUp", on).apply(); send("rdrhdg " + (on ? "on" : "off")); }
        else if (r.kind == 11) { cfg.edit().putBoolean("keepNext", on).apply(); send("keepnext " + (on ? "on" : "off")); }
        else if (r.kind == 9) { cfg.edit().putBoolean("mapSync", on).apply(); sMapForce = on; }
        else {
            if (on) sEmKm = cfg.getInt("emKmPrev", 250) > 0 ? cfg.getInt("emKmPrev", 250) : 250;
            else { if (sEmKm > 0) cfg.edit().putInt("emKmPrev", sEmKm).apply(); sEmKm = 0; }
            cfg.edit().putInt("emKm", sEmKm).apply();
        }
        for (SwRow x : swRows) swApply(x);
        Toast.makeText(this, (on ? "✓ تم تشغيل " : "✕ تم إيقاف ") + name, Toast.LENGTH_SHORT).show();
        final boolean ask = r.kind != 2 && r.kind != 9;
        if (ask) h.postDelayed(new Runnable() { @Override public void run() { Bridge.sendCmd("alstate"); } }, 700);   // نتأكد من الجهاز
    }

    private TextView mapTv;
    private void mapStatusRefresh() {
        if (mapTv == null) return;
        java.io.File base = getFilesDir();
        int lm = MapData.loadLandmarks(base).size();
        mapTv.setText((sMapDl.length() > 0 ? sMapDl + "\n" : "") + "المحفوظ: " + MapData.cachedCells(base) + " خلية (" + (MapData.cacheBytes(base) / 1048576) + " MB) | معالم: " + lm + "/" + MapData.LMS.length
                + (sMapInfo.length() > 0 ? "\n" + sMapInfo : "") + "\nنزّلها على الواي فاي. التنزيل يكمل لو سكرت الشاشة وتقدر توقفه وتكمله بعدين.");
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 78 && res == RESULT_OK && data != null && data.getData() != null) { doBackup(data.getData()); return; }
        if (req == 79 && res == RESULT_OK && data != null && data.getData() != null) { doRestore(data.getData()); return; }
        if (req != 77 || res != RESULT_OK || data == null || data.getData() == null) return;
        final android.net.Uri uri = data.getData();
        if (mapDlBusy) return;
        mapDlBusy = true; mapStop.set(false);
        final java.io.File base = getFilesDir();
        new Thread(new Runnable() {
            @Override public void run() {
                int n = 0;
                try {
                    java.io.File dir = MapData.dir(base);
                    java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.BufferedInputStream(getContentResolver().openInputStream(uri), 65536));
                    try {
                        java.util.zip.ZipEntry e;
                        byte[] buf = new byte[65536];
                        while ((e = zin.getNextEntry()) != null) {
                            String nm = e.getName();
                            if (nm.indexOf('/') >= 0) nm = nm.substring(nm.lastIndexOf('/') + 1);
                            boolean isLm = nm.equals("landmarks.csv");
                            if (!isLm && !nm.matches("(c_-?\\d+_-?\\d+\\.gz|d_-?\\d+_-?\\d+)")) continue;
                            java.io.File f = isLm ? MapData.landmarkFile(base) : new java.io.File(dir, nm), t = new java.io.File(f.getPath() + ".tmp");
                            java.io.FileOutputStream fo = new java.io.FileOutputStream(t);
                            try { int r; while ((r = zin.read(buf)) > 0) fo.write(buf, 0, r); } finally { fo.close(); }
                            if (f.exists()) f.delete();
                            t.renameTo(f);
                            if (nm.startsWith("c_")) { n++; if (n % 40 == 0) { sMapDl = "استيراد: " + n + " خلية..."; h.post(new Runnable() { @Override public void run() { mapStatusRefresh(); } }); } }
                        }
                    } finally { zin.close(); }
                    sMapDl = n > 0 ? "✓ تم استيراد " + n + " خلية + المعالم" : "✕ الملف ما فيه خلايا خريطة";
                } catch (Exception ex) {
                    sMapDl = "✕ فشل الاستيراد: " + (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage());
                } finally {
                    mapDlBusy = false; sMapForce = true;
                    h.post(new Runnable() { @Override public void run() { mapStatusRefresh(); } });
                }
            }
        }).start();
    }

    private void startMapDl(final int type) {
        if (mapDlBusy) { Toast.makeText(this, "في تنزيل شغّال، انتظر أو أوقفه", Toast.LENGTH_SHORT).show(); return; }
        mapDlBusy = true; mapStop.set(false);
        final String label = type == 0 ? "الكويت" : type == 1 ? "الشرقية" : type == 2 ? "البحرين" : type == 3 ? "شوارع الأحياء" : "المعالم";
        final java.io.File base = getFilesDir();
        final MapData.Prog pg = new MapData.Prog() {
            @Override public void p(String s) { sMapDl = label + ": " + s; h.post(new Runnable() { @Override public void run() { mapStatusRefresh(); } }); }
        };
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (type == 9) MapData.locateLandmarks(base, pg, mapStop);
                    else if (type == 3) MapData.downloadCells(base, MapData.regionCells(0), pg, mapStop, true);
                    else MapData.downloadCells(base, MapData.regionCells(type), pg, mapStop, false);
                } catch (Exception e) {
                    sMapDl = label + ": ✕ " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                } finally {
                    mapDlBusy = false; sMapForce = true;
                    h.post(new Runnable() { @Override public void run() { mapStatusRefresh(); } });
                }
            }
        }).start();
    }

    private LinearLayout makeSwitch(final String name, final int kind) {
        final SwRow r = new SwRow();
        r.kind = kind;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(4), dp(14), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(51, 65, 85));
        bg.setCornerRadius(dp(12));
        row.setBackground(bg);
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        TextView nm = new TextView(this);
        nm.setText(name);
        nm.setTextSize(15);
        nm.setTypeface(Typeface.DEFAULT_BOLD);
        nm.setTextColor(Color.WHITE);
        nm.setTextDirection(View.TEXT_DIRECTION_RTL);
        r.st = new TextView(this);
        r.st.setTextSize(12);
        r.st.setTextColor(Color.rgb(226, 232, 240));
        r.st.setTextDirection(View.TEXT_DIRECTION_RTL);
        names.addView(nm);
        names.addView(r.st);
        row.addView(names, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.track = new LinearLayout(this);
        r.track.setOrientation(LinearLayout.HORIZONTAL);
        r.track.setPadding(dp(3), dp(3), dp(3), dp(3));
        r.thumb = new View(this);
        GradientDrawable td = new GradientDrawable();
        td.setColor(Color.WHITE);
        td.setCornerRadius(dp(10));
        r.thumb.setBackground(td);
        r.track.addView(r.thumb, new LinearLayout.LayoutParams(dp(22), dp(22)));
        row.addView(r.track, new LinearLayout.LayoutParams(dp(54), dp(28)));
        row.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { swToggle(r, name); } });
        swRows.add(r);
        swApply(r);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60));
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        wrap.addView(row, lp);
        return wrap;
    }

    // ---------------- أزرار التحديث مع تأكيد بالزر نفسه ----------------
    private static class RefBtn { Button b; String label; int kind, n0, expect, e0; long t0, t1; int state; }
    private final ArrayList<RefBtn> refBtns = new ArrayList<>();

    private Button refreshBtn(final String label, final int kind) {   // 0 رادار الطيارات، 1 المباريات، 2 كاميرات
        final RefBtn r = new RefBtn();
        r.label = label; r.kind = kind;
        r.b = mkBtn(label, C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (r.state == 1) return;
                r.state = 1; r.t0 = SystemClock.elapsedRealtime();
                if (kind == 0) { r.n0 = sRdrN; sRdrInfo = "جاري إعادة المحاولة..."; sRdrForce = true; }
                else if (kind == 1) {
                    r.n0 = sScN; r.e0 = sScErrN; r.expect = Math.max(1, Integer.bitCount(sLgMask & ((1 << Feeds.SLUG.length) - 1)));
                    sLgForce = true;
                } else { r.n0 = sCamN; sCamInfo = "جاري التحديث..."; sCamForce = true; }
                r.b.setText("⏳ جاري...");
                paint(r.b, C_GOLD);
            }
        });
        refBtns.add(r);
        return r.b;
    }

    private void refTick() {
        long now = SystemClock.elapsedRealtime();
        for (RefBtn r : refBtns) {
            if (r.state == 1) {
                boolean done = r.kind == 0 ? sRdrN > r.n0 : r.kind == 1 ? (sScN - r.n0 >= r.expect) : sCamN > r.n0;
                if (done) {
                    String info = r.kind == 0 ? sRdrInfo : r.kind == 1 ? sScInfo : sCamInfo;
                    boolean err = info.startsWith("خطأ") || (r.kind == 1 && sScErrN != r.e0);
                    String txt;
                    if (err) txt = "✕ " + info;
                    else if (r.kind == 1) txt = "✓ تم · " + r.expect + " دوريات";
                    else if (r.kind == 2) { int k = info.indexOf(" ("); txt = "✓ " + (k > 0 ? info.substring(0, k) : info); }
                    else txt = "✓ " + info;
                    r.b.setText(txt);
                    paint(r.b, err ? C_RED : C_GRN);
                    r.state = 2; r.t1 = now;
                } else if (now - r.t0 > 20000) {
                    sRdrForce = false; sLgForce = false;
                    r.b.setText("✕ انتهت المهلة" + (r.kind == 1 ? "" : " (ما في موقع؟)"));
                    paint(r.b, C_RED);
                    r.state = 2; r.t1 = now;
                }
            } else if (r.state == 2 && now - r.t1 > 6000) {
                r.b.setText(r.label); paint(r.b, C_BLUE); r.state = 0;
            }
        }
    }

    private long lastStAsk = 0;
    private void swSync() {
        for (SwRow x : swRows) swApply(x);
        long now = SystemClock.elapsedRealtime();
        if ((sMa < 0 || sCamOn < 0 || sCamSnd < 0 || sFlash < 0 || sMapNames < 0) && now - lastStAsk > 5000) { lastStAsk = now; Bridge.sendCmd("alstate"); }
    }

    private void selectSub(int i) {
        subSel = i;
        for (int k = 0; k < 4; k++) paint(subBtns[k], k == i ? C_BLUE : C_GRAY);
        ctlBody.removeAllViews();
        if (i == 0) {
            ctlBody.addView(grid(new String[][] {
                    { "الصور", "photos" }, { "ساعة عقارب", "analog" }, { "ساعة رقمية", "digital" }, { "الطقس", "weather" } }, 2, C_BLUE));
        } else if (i == 1) {
            ctlBody.addView(grid(new String[][] {
                    { "العلي", "alali" }, { "يوسف", "yousef" }, { "الأسماء", "names" }, { "Yousef EN", "yousefen" },
                    { "Alali EN", "alalien" }, { "مكس EN", "mixen" }, { "مكس عربي/EN", "mixaren" }, { "يوسف عربي/EN", "ymix" }, { "Alali EN/عربي", "amix" }, { "الخدع", "hypno" },
                    { "القوائم", "list" } }, 2, C_PURP));
        } else if (i == 2) {
            ctlBody.addView(grid(new String[][] {
                    { "البوصلة", "compass" }, { "الرادار", "radar" }, { "النتائج", "scores" }, { "السرعة", "speed" },
                    { "رادار الكاميرات", "camrad" }, { "شكل الكاميرات التالي", "camrad next" },
                    { "لون الكاميرات", "camrad color" }, { "دوران الكاميرات شغّل/وقف", "camrad sweep" },
                    { "شكل البوصلة التالي", "cmp next" }, { "لون البوصلة", "cmp color" },
                    { "شكل السرعة التالي", "spd next" }, { "لون السرعة", "spd color" },
                    { "شكل الرادار التالي", "rdr next" }, { "لف الرادار شغّل/وقف", "rdr sweep" }, { "الدوريات", "sc" } }, 2, C_GOLD));
        } else {
            ctlBody.addView(grid(new String[][] {
                    { "ريست بلوتوث", "rbt" }, { "ريست واي فاي", "rwf" }, { "شغّل الميكس", "mix" }, { "وقّف الميكس", "mix off" },
                    { "حالة الإطار", "status" }, { "تشخيص الشبكة", "net" }, { "الشاشة شغّل/طفي", "screen" } }, 2, C_RED));
        }
    }

    private void selectTab(int i) {
        tabSel = i;
        for (int k = 0; k < 4; k++) paint(tabBtns[k], k == i ? C_BLUE : C_CARD);
        content.removeAllViews();
        content.addView(panels[i]);
        scroll.scrollTo(0, 0);
        if (i == 1) refreshMatches();
    }


    // ---------------- ألوان الميزات ----------------
    private static final int F_PHOTO = Color.rgb(0, 150, 170), F_CLOCK = Color.rgb(120, 80, 190), F_NAMES = Color.rgb(200, 70, 140),
            F_WX = Color.rgb(60, 150, 220), F_ILL = Color.rgb(160, 100, 50), F_SPD = Color.rgb(190, 55, 55), F_AIR = Color.rgb(30, 140, 80),
            F_CAM = Color.rgb(120, 120, 135), F_MATCH = Color.rgb(48, 110, 210), F_CMP = Color.rgb(200, 170, 0), F_MAP = Color.rgb(200, 110, 20);

    private TextView secTitle(String t, int col) {
        TextView x = title(t);
        x.setTextColor(col == F_CAM ? Color.rgb(230, 230, 235) : col);
        x.setBackgroundColor(Color.argb(40, Color.red(col), Color.green(col), Color.blue(col)));
        x.setPadding(dp(8), dp(10), dp(8), dp(10));
        return x;
    }

    // ---------------- تبويب التحكم الجديد: أوامر مباشرة فقط ----------------
    private void modeSend(String cmd, String name) { curScreen = name; send(cmd); }

    private View modeTile(String label, final String cmd, int col) {
        final String lb = label;
        return mkBtn(label, col, new View.OnClickListener() { @Override public void onClick(View v) { modeSend(cmd, lb); } });
    }

    private LinearLayout tileGrid(String[][] items, int cols, int[] colors) {
        LinearLayout col = vbox(); LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) { row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); col.addView(row); }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(modeTile(items[i][0], items[i][1], colors[i]), lp);
        }
        return col;
    }

    private LinearLayout buildControl() {
        LinearLayout p = vbox();
        p.addView(secTitle("الأوضاع", F_MATCH));
        String[][] t = { { "الصور", "photos" }, { "ساعة عقارب", "analog" }, { "ساعة رقمية", "digital" }, { "الطقس", "weather" },
                { "الأسماء", "names" }, { "الخدع", "hypno" }, { "البوصلة", "compass" }, { "السرعة", "speed" },
                { "رادار الطيران", "radar" }, { "رادار الكاميرات", "camrad" }, { "المباريات", "scores" }, { "الخريطة", "map" },
                { "ميكس", "mix" }, { "القوائم", "list" } };
        int[] c = { F_PHOTO, F_CLOCK, F_CLOCK, F_WX, F_NAMES, F_ILL, F_CMP, F_SPD, F_AIR, F_CAM, F_MATCH, F_MAP, C_GRAY, C_GRAY };
        p.addView(tileGrid(t, 3, c));
        p.addView(secTitle("دخول / رجوع", C_GOLD));
        LinearLayout er = new LinearLayout(this); er.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, dp(56), 1f); l1.setMargins(dp(3), dp(3), dp(3), dp(3));
        er.addView(cmdBtn("↩ رجوع", "back", C_GRAY), l1);
        er.addView(mkBtn("⏎ دخول", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) { send("enter"); miniPanel.setVisibility(View.VISIBLE); }
        }), l1);
        p.addView(er);
        miniPanel = vbox();
        miniPanel.setVisibility(View.GONE);
        miniPanel.addView(secTitle("داخل الوضع الحالي", F_CMP));
        miniPanel.addView(grid(new String[][] { { "◀ شكل سابق", "sprev" }, { "شكل تالي ▶", "snext" },
                { "◀ لون سابق", "colstep prev" }, { "لون تالي ▶", "colstep next" } }, 2, F_CMP));
        p.addView(miniPanel);
        p.addView(secTitle("عام", C_GRAY));
        p.addView(grid(new String[][] { { "◀ السابقة", "sprev" }, { "التالية ▶", "snext" }, { "⏸ تثبيت", "pin" }, { "▶ استمرار", "unpin" },
                { "سطوع −", "bdn" }, { "سطوع +", "bup" }, { "الشاشة شغّل/طفي", "screen" }, { "وقّف الميكس", "mix off" } }, 2, C_GRAY));
        return p;
    }

    // ---------------- الإعدادات: كل شي مجمّع بالألوان ----------------
    private LinearLayout buildSettingsAll() {
        LinearLayout p = vbox();
        p.addView(secTitle("الصور", F_PHOTO));
        p.addView(grid(new String[][] { { "الصور", "photos" } }, 1, F_PHOTO));
        p.addView(secTitle("الساعات والطقس", F_CLOCK));
        p.addView(grid(new String[][] { { "ساعة عقارب", "analog" }, { "ساعة رقمية", "digital" }, { "الطقس", "weather" } }, 3, F_CLOCK));
        p.addView(secTitle("الأسماء", F_NAMES));
        p.addView(grid(new String[][] { { "العلي", "alali" }, { "يوسف", "yousef" }, { "الأسماء", "names" }, { "Yousef EN", "yousefen" },
                { "Alali EN", "alalien" }, { "مكس EN", "mixen" }, { "مكس عربي/EN", "mixaren" }, { "يوسف عربي/EN", "ymix" }, { "Alali EN/عربي", "amix" } }, 2, F_NAMES));
        p.addView(secTitle("الخدع البصرية", F_ILL));
        p.addView(grid(new String[][] { { "الخدع", "hypno" } }, 1, F_ILL));
        p.addView(secTitle("السرعة", F_SPD));
        p.addView(grid(new String[][] { { "السرعة", "speed" }, { "شكل تالي", "spd next" }, { "لون", "spd color" } }, 3, F_SPD));
        p.addView(secTitle("رادار الطيران", F_AIR));
        p.addView(grid(new String[][] { { "الرادار", "radar" }, { "شكل تالي", "rdr next" }, { "لف شغّل/وقف", "rdr sweep" } }, 3, F_AIR));
        p.addView(makeSwitch("تنبيه أحمر على شريط الحالة عند خطأ الرادار", 14));
        p.addView(makeSwitch("رادار يتوجه حسب اتجاهي (بوصلة تدور، الأشكال 5 و8 و11-17)", 16));
        p.addView(secTitle("رادار الكاميرات", F_CAM));
        p.addView(grid(new String[][] { { "الرادار", "camrad" }, { "شكل تالي", "camrad next" }, { "لون", "camrad color" }, { "دوران", "camrad sweep" } }, 2, F_CAM));
        p.addView(secTitle("البوصلة", F_CMP));
        p.addView(grid(new String[][] { { "البوصلة", "compass" }, { "شكل تالي", "cmp next" }, { "لون", "cmp color" } }, 3, F_CMP));
        p.addView(secTitle("الخريطة", F_MAP));
        p.addView(grid(new String[][] { { "الخريطة", "map" }, { "زوم", "map zoom" } }, 2, F_MAP));
        p.addView(makeSwitch("Next يغيّر الشكل داخل الوضع حتى مع MIX", 11));
        p.addView(makeSwitch("سيارتك برادو أبيض (إيقاف = السهم القديم)", 10));
        p.addView(secTitle("الميكس", C_GRAY));
        p.addView(buildMix());
        p.addView(secTitle("المباريات", F_MATCH));
        p.addView(buildMatches());
        p.addView(secTitle("إعدادات أخرى", C_GOLD));
        p.addView(buildSettings());
        p.addView(secTitle("النظام", C_RED));
        p.addView(grid(new String[][] { { "ريست بلوتوث", "rbt" }, { "ريست واي فاي", "rwf" }, { "حالة الإطار", "status" }, { "تشخيص الشبكة", "net" } }, 2, C_RED));
        p.addView(secTitle("نسخة احتياطية للإعدادات", C_GOLD));
        p.addView(grid(new String[][] { { "💾 حفظ كل الإعدادات (مع مفتاح API) لملف", "@bkp" }, { "📂 استرجاع الإعدادات من ملف", "@rst" } }, 1, C_GOLD));
        return p;
    }

    private void backupSettings() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "frame_settings.txt");
        startActivityForResult(i, 78);
    }

    private void restoreSettings() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        startActivityForResult(i, 79);
    }

    private void doBackup(android.net.Uri uri) {
        try {
            StringBuilder sb = new StringBuilder("FRAMECFG1\n");
            for (java.util.Map.Entry<String, ?> e : cfg.getAll().entrySet()) {
                Object v = e.getValue(); String t = v instanceof Boolean ? "b" : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Float ? "f" : "s";
                sb.append(t).append('\t').append(e.getKey()).append('\t').append(String.valueOf(v).replace("\n", "\\n")).append('\n');
            }
            java.io.OutputStream o = getContentResolver().openOutputStream(uri);
            o.write(sb.toString().getBytes("UTF-8")); o.close();
            Toast.makeText(this, "انحفظت الإعدادات", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "فشل الحفظ: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void doRestore(android.net.Uri uri) {
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(getContentResolver().openInputStream(uri), "UTF-8"));
            String ln = r.readLine();
            if (ln == null || !ln.equals("FRAMECFG1")) { r.close(); Toast.makeText(this, "الملف مو نسخة إعدادات", Toast.LENGTH_LONG).show(); return; }
            SharedPreferences.Editor ed = cfg.edit(); int n = 0;
            while ((ln = r.readLine()) != null) {
                String[] a = ln.split("\t", 3); if (a.length < 3) continue;
                String v = a[2].replace("\\n", "\n");
                if (a[0].equals("b")) ed.putBoolean(a[1], v.equals("true")); else if (a[0].equals("i")) ed.putInt(a[1], Integer.parseInt(v));
                else if (a[0].equals("l")) ed.putLong(a[1], Long.parseLong(v)); else if (a[0].equals("f")) ed.putFloat(a[1], Float.parseFloat(v)); else ed.putString(a[1], v);
                n++;
            }
            r.close(); ed.apply();
            Toast.makeText(this, "اسـترجعت " + n + " إعداد. اقفل التطبيق وافتحه", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "فشل الاسترجاع: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    // ---------------- شريط الحالة ----------------
    private void dot(int i, boolean ok) { dots[i].setTextColor(ok ? Color.rgb(60, 220, 110) : Color.rgb(240, 70, 70)); }

    private void statusTick() {
        if (dots[0] == null) return;
        boolean bt = sBt.startsWith("متصل");
        boolean gps = sLoc.contains(",") && !sLoc.contains("قديم");
        String net = netName(); boolean nt = !net.startsWith("ما في");
        boolean rdrBad = sRdrInfo.startsWith("خطأ") || sRdrInfo.startsWith("0 ") || sRdrInfo.equals("0");
        boolean scBad = sScInfo.startsWith("خطأ");
        boolean camBad = sCamInfo.startsWith("خطأ");
        dot(0, bt); dot(1, gps); dot(2, nt);
        boolean redOn = cfg.getBoolean("rdrRed", true);
        dot(3, !(redOn && rdrBad)); dot(4, !scBad); dot(5, !camBad);
        String why = "";
        if (redOn && rdrBad) why = "رادار: " + (sRdrInfo.startsWith("خطأ") ? sRdrInfo : "ما في طيارات ضمن المدى (" + Feeds.radarNote + ")");
        else if (scBad) why = "نتائج: " + sScInfo;
        else if (camBad) why = "كاميرات: " + sCamInfo;
        stLine.setText(net.replace("واي فاي: ", "📶 ") + "  |  " + curScreen + "  |  🔋 " + sBatt + (why.length() > 0 ? "\n⚠ " + why : ""));
        stLine.setTextColor(why.length() > 0 ? Color.rgb(255, 120, 120) : Color.rgb(200, 200, 212));
    }

    // ---------------- تبويب التحكم القديم ----------------
    private LinearLayout buildControlOld() {
        LinearLayout p = vbox();
        p.addView(grid(new String[][] { { "◀ السابقة", "sprev" }, { "التالية ▶", "snext" },
                { "↩ رجوع (Back)", "back" }, { "⏎ دخول (Enter)", "enter" },
                { "⏸ إيقاف (تثبيت)", "pin" }, { "▶ استمرار", "unpin" } }, 2, C_GRAY));
        p.addView(grid(new String[][] { { "سطوع −", "bdn" }, { "سطوع +", "bup" }, { "ميكس", "mix" } }, 3, C_GRAY));
        LinearLayout sub = new LinearLayout(this);
        sub.setOrientation(LinearLayout.HORIZONTAL);
        String[] nm = { "SHOW", "NAMES", "TOOLS", "SYS" };
        for (int i = 0; i < 4; i++) {
            final int k = i;
            subBtns[i] = mkBtn(nm[i], C_GRAY, new View.OnClickListener() {
                @Override public void onClick(View v) { selectSub(k); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(dp(3), dp(10), dp(3), dp(6));
            sub.addView(subBtns[i], lp);
        }
        p.addView(sub);
        ctlBody = vbox();
        p.addView(ctlBody);
        selectSub(0);
        return p;
    }

    // ---------------- تبويب الميكس المخصص ----------------
    private boolean mixDefault(String name) { return MIX_DEF.contains("," + name + ","); }

    private LinearLayout buildMix() {
        LinearLayout p = vbox();
        TextView info = new TextView(this);
        info.setText("اختر الأوضاع اللي تدخل بالميكس، والمدة، وبعدها اضغط «طبّق على الإطار». "
                + "البوصلة والسرعة والرادار تطلع بس إذا الموقع واصل، والنتائج لما في مباراة شغالة.");
        info.setTextSize(13);
        info.setTextColor(Color.rgb(170, 170, 180));
        info.setTextDirection(View.TEXT_DIRECTION_RTL);
        p.addView(info);
        p.addView(title("الأوضاع"));
        mixBoxes.clear();
        for (int i = 0; i < MIXI.length; i++) {
            final String name = MIXI[i][0];
            CheckBox cb = new CheckBox(this);
            cb.setText(MIXI[i][1]);
            cb.setTextSize(16);
            cb.setTextColor(Color.WHITE);
            cb.setChecked(cfg.getBoolean("mix_" + name, mixDefault(name)));
            cb.setPadding(dp(6), dp(8), dp(6), dp(8));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    cfg.edit().putBoolean("mix_" + name, on).apply();
                }
            });
            mixBoxes.add(cb);
            p.addView(cb);
        }
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(smallBtn("الكل", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { for (CheckBox c : mixBoxes) c.setChecked(true); }
        }));
        quick.addView(smallBtn("مسح الكل", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { for (CheckBox c : mixBoxes) c.setChecked(false); }
        }));
        quick.addView(smallBtn("الافتراضي", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                for (int i = 0; i < mixBoxes.size(); i++) mixBoxes.get(i).setChecked(mixDefault(MIXI[i][0]));
            }
        }));
        p.addView(quick);

        p.addView(title("مدة كل وضع (ثواني)"));
        mixSec = cfg.getInt("mixSec", 10);
        LinearLayout secs = new LinearLayout(this);
        secs.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MIX_SECS.length; i++) {
            final int sec = MIX_SECS[i];
            secBtns[i] = smallBtn(String.valueOf(sec), sec == mixSec ? C_BLUE : C_GRAY, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    mixSec = sec;
                    cfg.edit().putInt("mixSec", sec).apply();
                    for (int k = 0; k < MIX_SECS.length; k++) paint(secBtns[k], MIX_SECS[k] == sec ? C_BLUE : C_GRAY);
                }
            });
            secs.addView(secBtns[i]);
        }
        p.addView(secs);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(dp(3), dp(18), dp(3), dp(4));
        p.addView(mkBtn("طبّق على الإطار", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) { applyMix(false); }
        }), lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp2.setMargins(dp(3), dp(4), dp(3), dp(4));
        p.addView(mkBtn("طبّق وشغّل الميكس", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) { applyMix(true); }
        }), lp2);
        return p;
    }

    private Button smallBtn(String t, int color, View.OnClickListener l) {
        Button b = mkBtn(t, color, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(3), dp(6), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private void applyMix(boolean start) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < mixBoxes.size(); i++) {
            if (mixBoxes.get(i).isChecked()) {
                if (sb.length() > 0) sb.append(',');
                sb.append(MIXI[i][0]);
            }
        }
        if (sb.length() == 0) {
            Toast.makeText(this, "اختر وضع واحد على الأقل", Toast.LENGTH_SHORT).show();
            return;
        }
        send("mixset " + sb);
        send("mixsec " + mixSec);
        if (start) send("mix");
    }

    // ---------------- تبويب الإعدادات ----------------
    static int lgMaskLoad(SharedPreferences cfg) { return cfg.contains("lgMask2") ? cfg.getInt("lgMask2", 255) : (cfg.getInt("lgMask", 63) | 192); }

    private LinearLayout buildSettings() {
        LinearLayout p = vbox();
        p.addView(title("الدوريات (يجلبها الجوال)"));
        for (int i = 0; i < Feeds.SLUG.length; i++) {
            final int li = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(Feeds.LG_AR[i]);
            cb.setTextSize(16);
            cb.setTextColor(Color.WHITE);
            cb.setChecked((sLgMask & (1 << i)) != 0);
            cb.setPadding(dp(6), dp(6), dp(6), dp(6));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    if (on) sLgMask |= (1 << li); else sLgMask &= ~(1 << li);
                    cfg.edit().putInt("lgMask2", sLgMask).apply();
                    send("lg " + (li + 1) + (on ? " on" : " off"));
                }
            });
            p.addView(cb);
        }
        p.addView(title("تنبيه طوارئ الطيران (يطلع لحاله على الإطار)"));
        p.addView(makeSwitch("تنبيهات الطيارات (طوارئ)", 2));
        LinearLayout emRow = new LinearLayout(this);
        emRow.setOrientation(LinearLayout.HORIZONTAL);
        final int[] emV = { 100, 250, 0 };
        String[] emT = { "100 كم", "250 كم", "إيقاف" };
        for (int i = 0; i < 3; i++) {
            final int v = emV[i];
            Button eb = mkBtn(emT[i], v == 0 ? C_GRAY : C_RED, new View.OnClickListener() {
                @Override public void onClick(View x) {
                    sEmKm = v;
                    cfg.edit().putInt("emKm", v).apply();
                    Toast.makeText(MainActivity.this, v == 0 ? "تنبيه الطوارئ متوقف" : "مدى الطوارئ " + v + " كم", Toast.LENGTH_SHORT).show();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            emRow.addView(eb, lp);
        }
        p.addView(emRow);
        p.addView(grid(new String[][] { { "طوارئ: طبي", "emtest 1" }, { "طوارئ: خطف", "emtest 2" }, { "طوارئ: عطل اتصال", "emtest 3" }, { "طوارئ: عامة", "emtest 4" }, { "تجربة بطاقة طيارة", "actest" } }, 2, C_GRAY));
        p.addView(title("تنبيه الهدف"));
        p.addView(grid(new String[][] { { "شغّل", "goal on" }, { "طفّي", "goal off" }, { "تجربة", "goal test" } }, 3, C_PURP));
        p.addView(title("بداية المباريات"));
        p.addView(grid(new String[][] { { "تجربة بداية مباراة", "kotest" }, { "تجربة 3 مباريات", "kotest 3" } }, 2, C_PURP));
        p.addView(title("ليفربول ❤"));
        p.addView(grid(new String[][] { { "تنبيهات ليفربول تتجاوز الكتم", "lfc on" }, { "إيقاف التجاوز", "lfc off" },
                { "تجربة هدف ليفربول", "lfctest 1" }, { "تجربة هدف على ليفربول", "lfctest 2" }, { "تجربة بداية ليفربول", "lfctest 3" } }, 2, C_PURP));
        p.addView(title("رادار الطيارات"));
        p.addView(refreshBtn("🔄 إعادة تشغيل الرادار", 0), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(title("مدى الرادار (كم)"));
        LinearLayout rr = new LinearLayout(this);
        rr.setOrientation(LinearLayout.HORIZONTAL);
        int[] ranges = { 20, 40, 80, 150, 250 };
        for (int i = 0; i < ranges.length; i++) {
            final int km = ranges[i];
            rr.addView(smallBtn(String.valueOf(km), C_GOLD, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    sRange = km;
                    cfg.edit().putInt("range", km).apply();
                    send("rdr r " + km);
                }
            }));
        }
        p.addView(rr);
        p.addView(title("شكل الرادار (1-9 كلاسيك | 10-18 نقاط، مثلثات، طيارات)"));
        p.addView(numGrid("rdr", 18, C_GOLD));
        p.addView(grid(new String[][] { { "تلقائي", "rdr auto" }, { "لف شغّال", "rdr sweep on" }, { "لف متوقف", "rdr sweep off" } }, 3, C_GRAY));
        p.addView(title("شكل البوصلة (6 إلى 9 عربي)"));
        p.addView(numGrid("cmp", 9, C_BLUE));
        p.addView(grid(new String[][] { { "لون (للعربي 2 و5)", "cmp color" }, { "تلقائي", "cmp auto" } }, 2, C_GRAY));
        p.addView(title("شكل السرعة (8 = عداد السيارة مع دورات تقديرية)"));
        p.addView(numGrid("spd", 8, C_RED));
        p.addView(grid(new String[][] { { "لون (للشكل 5 و8)", "spd color" }, { "تلقائي", "spd auto" }, { "صفّر MAX", "spd max" } }, 3, C_GRAY));
        p.addView(title("لون عداد السيارة (شكل 8)"));
        p.addView(grid(new String[][] { { "أزرق", "spd color 1" }, { "أخضر", "spd color 2" }, { "أحمر", "spd color 3" }, { "برتقالي", "spd color 4" },
                { "بنفسجي", "spd color 5" }, { "تركواز", "spd color 6" }, { "ذهبي", "spd color 7" }, { "رمادي", "spd color 8" } }, 4, C_BLUE));
        p.addView(title("دوران الشاشة كلها"));
        p.addView(grid(new String[][] { { "عادي", "rot 0" }, { "90 يمين", "rot 90" }, { "مقلوب 180", "rot 180" }, { "90 يسار", "rot 270" }, { "التالي", "rot next" } }, 3, C_ORG));
        p.addView(title("الأسماء: كل شكل ثابت إله نسخة متحركة بنفس الخط"));
        p.addView(grid(new String[][] {
                { "العلي: التالي", "al next" }, { "العلي: متحرك", "al anim" }, { "العلي: ثابت", "al static" },
                { "يوسف: التالي", "ys next" }, { "يوسف: متحرك", "ys anim" }, { "يوسف: ثابت", "ys static" },
                { "Yousef: التالي", "ye next" }, { "Yousef: متحرك", "ye anim" }, { "Yousef: ثابت", "ye static" },
                { "Alali: التالي", "ae next" }, { "Alali: متحرك", "ae anim" }, { "Alali: ثابت", "ae static" } }, 3, C_PURP));
        p.addView(title("رادار الكاميرات: الشكل (1 خريطة، 2 أمامك، 3 الطريق، 4 رادار مسح، 5 كاميرا كبيرة، 6 شريط جانبي)"));
        p.addView(numGrid("camrad", 6, C_GOLD));
        p.addView(title("رادار الكاميرات: اللون"));
        p.addView(grid(new String[][] { { "أخضر", "camrad color 1" }, { "أزرق", "camrad color 2" }, { "بنفسجي", "camrad color 3" }, { "أبيض", "camrad color 4" } }, 4, C_GOLD));
        p.addView(title("رادار الكاميرات: الدوران والمدى"));
        p.addView(grid(new String[][] { { "دوران شغّال", "camrad sweep on" }, { "دوران متوقف", "camrad sweep off" },
                { "مدى 5 كم", "camrad range 5" }, { "مدى 10 كم", "camrad range 10" }, { "مدى 20 كم", "camrad range 20" } }, 3, C_GOLD));
        p.addView(title("الساعات والطقس"));
        p.addView(numGrid("ana", 6, C_BLUE));
        p.addView(grid(new String[][] { { "رقمي 1", "dig 1" }, { "رقمي 2", "dig 2" }, { "رقمي 3", "dig 3" } }, 3, C_BLUE));
        p.addView(numGrid("wx", 5, C_BLUE));
        return p;
    }

    // ---------------- تبويب المباريات (تنبيهات + تجاهل) ----------------
    private LinearLayout mtBox;
    static final java.util.concurrent.ConcurrentHashMap<Integer, ArrayList<String[]>> sMl = new java.util.concurrent.ConcurrentHashMap<>();

    private java.util.Set<String> mutedSet() {
        java.util.HashSet<String> r = new java.util.HashSet<>();
        String v = cfg.getString("muted", "");
        for (String t : v.split(",")) if (!t.isEmpty()) r.add(t);
        return r;
    }

    private LinearLayout buildMatches() {
        LinearLayout p = vbox();
        p.addView(title("تنبيهات المباريات (هدف، بداية، VAR، كرت أحمر)"));
        p.addView(makeSwitch("تنبيهات المباريات", 0));
        final TextView srcTv = new TextView(this);
        srcTv.setTextSize(12);
        srcTv.setTextColor(Color.rgb(200, 205, 215));
        srcTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        srcTv.setPadding(dp(6), dp(4), dp(6), dp(4));
        Feeds.afKey = cfg.getString("afKey", "");
        final EditText keyEd = new EditText(this);
        keyEd.setHint("مفتاح API-Football (يتحفظ بالجوال بس)");
        keyEd.setSingleLine(true);
        keyEd.setTextSize(12);
        keyEd.setTextColor(Color.WHITE);
        keyEd.setHintTextColor(Color.rgb(120, 120, 135));
        keyEd.setText(Feeds.afKey);
        p.addView(keyEd, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final Button keyBtn = mkBtn("💾 حفظ المفتاح", C_GRAY, null);
        keyBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String k = keyEd.getText().toString().trim();
                Feeds.afKey = k;
                cfg.edit().putString("afKey", k).apply();
                keyBtn.setText("✓ انحفظ");
                h.postDelayed(new Runnable() { @Override public void run() { keyBtn.setText("💾 حفظ المفتاح"); } }, 1500);
            }
        });
        p.addView(keyBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        final Button srcBtn = mkBtn("🧪 اختبار مصادر النتائج (من جوالك)", C_PURP, null);
        srcBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                srcBtn.setText("⏳ جاري الاختبار...");
                srcTv.setText("");
                new Thread(new Runnable() {
                    @Override public void run() {
                        final String res = Feeds.testSources();
                        h.post(new Runnable() {
                            @Override public void run() { srcTv.setText(res); srcBtn.setText("🧪 اختبار مصادر النتائج (من جوالك)"); }
                        });
                    }
                }).start();
            }
        });
        p.addView(srcBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(srcTv);
        p.addView(refreshBtn("🔄 تحديث المباريات", 1), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(grid(new String[][] { { "تجربة VAR", "vartest" }, { "تجربة كرت أحمر", "redtest" }, { "تجربة بداية", "kotest" }, { "تجربة هدف", "goal test" } }, 2, C_GRAY));
        p.addView(title("تجاهل دوري كامل"));
        for (int i = 0; i < Feeds.SLUG.length; i++) {
            final int li = i;
            CheckBox cb = new CheckBox(this);
            cb.setText("تجاهل " + Feeds.LG_AR[i]);
            cb.setTextSize(15);
            cb.setTextColor(Color.WHITE);
            cb.setChecked((cfg.getInt("lgMuteMask", 0) & (1 << i)) != 0);
            cb.setPadding(dp(6), dp(5), dp(6), dp(5));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    int m = cfg.getInt("lgMuteMask", 0);
                    m = on ? (m | (1 << li)) : (m & ~(1 << li));
                    cfg.edit().putInt("lgMuteMask", m).apply();
                    send("lgmute " + (li + 1) + (on ? " on" : " off"));
                }
            });
            p.addView(cb);
        }
        p.addView(title("تجاهل مباراة معينة"));
        p.addView(mkBtn("تحديث القائمة", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) { refreshMatches(); }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        mtBox = vbox();
        p.addView(mtBox);
        return p;
    }

    private void refreshMatches() {
        if (mtBox == null) return;
        mtBox.removeAllViews();
        final java.util.Set<String> mu = mutedSet();
        boolean any = false;
        for (int li = 0; li < Feeds.SLUG.length; li++) {
            ArrayList<String[]> l = sMl.get(li);
            if (l == null || l.isEmpty() || (sLgMask & (1 << li)) == 0) continue;
            any = true;
            mtBox.addView(title(Feeds.LG_AR[li]));
            for (final String[] m : l) {
                String st = "1".equals(m[7]) ? "🔴 " : "2".equals(m[7]) ? "✔ " : "";
                String sc = "0".equals(m[7]) ? m[8] : m[5] + "-" + m[6];
                CheckBox cb = new CheckBox(this);
                cb.setText("تجاهل  " + st + m[3] + " " + sc + " " + m[4]);
                cb.setTextSize(14);
                cb.setTextColor(Color.WHITE);
                cb.setChecked(mu.contains(m[0]));
                cb.setPadding(dp(6), dp(5), dp(6), dp(5));
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                        java.util.Set<String> cur = mutedSet();
                        if (on) cur.add(m[0]); else cur.remove(m[0]);
                        StringBuilder sb = new StringBuilder();
                        for (String t : cur) { if (sb.length() > 0) sb.append(','); sb.append(t); }
                        cfg.edit().putString("muted", sb.toString()).apply();
                        send((on ? "muteid " : "unmuteid ") + m[0]);
                    }
                });
                mtBox.addView(cb);
            }
        }
        if (!any) {
            TextView t = new TextView(this);
            t.setText("ما في مباريات محمّلة بعد. فعّل الدوريات من الإعدادات وانتظر الاتصال بالإطار.");
            t.setTextSize(13); t.setTextColor(Color.rgb(170, 170, 180));
            t.setTextDirection(View.TEXT_DIRECTION_RTL);
            mtBox.addView(t);
        }
    }

    // ---------------- تبويب الكاميرات ----------------
    private TextView camTv;

    private LinearLayout buildCams() {
        LinearLayout p = vbox();
        camTv = new TextView(this);
        camTv.setText("التنبيه يطلع على الإطار تلقائياً لما تقرب من كاميرا قدامك، مع جرس خفيف مرة وحدة عند 10 ثواني. "
                + "اضغط على الشاشة أو زر «تجاهل» وتروح هذي الكاميرا بس.");
        camTv.setTextSize(13);
        camTv.setTextColor(Color.rgb(170, 170, 180));
        camTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        p.addView(camTv);
        p.addView(makeSwitch("تنبيهات الكاميرات", 1));
        p.addView(makeSwitch("صوت التنبيه (جرس عند 10 ثواني)", 3));
        p.addView(grid(new String[][] { { "🔔 جرّب الصوت", "camsnd test" } }, 1, C_GRAY));
        p.addView(makeSwitch("الشهاب الأحمر حول الإطار مع الجرس", 4));
        p.addView(grid(new String[][] { { "⚡ جرّب الشهاب والجرس", "flash test" } }, 1, C_GRAY));
        p.addView(makeSwitch("تأكيد إضافة الكاميرا (صوت وشاشة)", 5));
        p.addView(refreshBtn("🔄 تحديث رادارات الكاميرات", 2), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(title("علامات أنت حطيتها"));
        p.addView(grid(new String[][] { { "📍 علّم كاميرا هنا", "cmark" }, { "📱 علّم كاميرا جوال", "cmark phone" }, { "📡 علّم رادار متنقل", "cmark radar" }, { "↩ إلغاء آخر علامة", "cundo" },
                { "تجاهل هذي الكاميرا", "camskip" },
                { "رقم الثواني: صغير جداً (1)", "camnum 1" }, { "رقم الثواني: متوسط (2)", "camnum 2" } }, 2, C_RED));
        p.addView(grid(new String[][] { { "تجربة التنبيه", "camtest sim" } }, 1, C_GRAY));
        p.addView(mkBtn("كاميراتي (اختر واحدة للحذف)", C_PURP, new View.OnClickListener() {
            @Override public void onClick(View v) { sCamList = null; sWantList = true; send("clist"); }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(title("كاميرات الطريق (الكويت - الدمام - البحرين)"));
        final TextView roadTv = new TextView(this);
        roadTv.setTextSize(12);
        roadTv.setTextColor(Color.rgb(200, 205, 215));
        roadTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        roadTv.setPadding(dp(6), dp(4), dp(6), dp(4));
        final java.io.File roadF = new java.io.File(getFilesDir(), "road_cams.csv");
        if (roadF.exists()) roadTv.setText("محفوظ: " + Feeds.loadRoad(roadF).size() + " كاميرا | " + new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date(roadF.lastModified())));
        else roadTv.setText("ما نزّلت بعد. نزّلها وأنت على الواي فاي قبل السفر.");
        final Button roadBtn = mkBtn("⬇️ تنزيل كاميرات الطريق (أوفلاين)", C_BLUE, null);
        roadBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                roadBtn.setText("⏳ جاري التنزيل (قد ياخذ دقيقة)...");
                new Thread(new Runnable() {
                    @Override public void run() {
                        String r;
                        try { int n = Feeds.downloadRoad(roadF); r = "✓ نزلت " + n + " كاميرا. تنضاف للإطار تلقائياً." + (Feeds.roadWarn.length() > 0 ? "\n⚠️" + Feeds.roadWarn + " (أعد المحاولة لاحقاً)" : ""); sCamForce = true; }
                        catch (Exception e) { r = "✕ فشل: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()); }
                        final String res = r;
                        h.post(new Runnable() { @Override public void run() { roadTv.setText(res); roadBtn.setText("⬇️ تنزيل كاميرات الطريق (أوفلاين)"); } });
                    }
                }).start();
            }
        });
        p.addView(roadBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(roadTv);
        p.addView(title("الخريطة على الإطار"));
        p.addView(makeSwitch("أسماء الشوارع والمناطق", 6));
        p.addView(makeSwitch("المعالم (مجسمات)", 7));
        p.addView(makeSwitch("الكاميرات على الخريطة", 8));
        p.addView(makeSwitch("مزامنة الخريطة مع الإطار", 9));
        p.addView(makeSwitch("سيارتك برادو أبيض (إيقاف = السهم القديم)", 10));
        p.addView(makeSwitch("Next يغيّر الشكل داخل الوضع حتى مع MIX", 11));
        p.addView(makeSwitch("شاشة الجول: الفريقين يمين/يسار (غير ليفربول)", 12));
        p.addView(makeSwitch("تنبيه نهاية المباراة (النتيجة والفايز)", 13));
        p.addView(makeSwitch("نسبة البطارية على شاشة الإطار (مطفية، تشوفها من الردود)", 15));
        p.addView(grid(new String[][] { { "🏁 جرّب نهاية المباراة", "ft test" } }, 1, C_GRAY));
        p.addView(grid(new String[][] { { "🗺️ افتح الخريطة", "map" }, { "زوم تلقائي", "map zoom auto" }, { "زوم 1 (قريب)", "map zoom 1" }, { "زوم 2", "map zoom 2" },
                { "زوم 3", "map zoom 3" }, { "زوم 4 (بعيد)", "map zoom 4" } }, 2, C_BLUE));
        p.addView(title("تنزيل الخرائط (أوفلاين)"));
        mapTv = new TextView(this);
        mapTv.setTextSize(12);
        mapTv.setTextColor(Color.rgb(200, 205, 215));
        mapTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        mapTv.setPadding(dp(6), dp(4), dp(6), dp(4));
        mapStatusRefresh();
        p.addView(grid(new String[][] { { "⬇️ الكويت", "@mapdl0" }, { "⬇️ الشرقية (الخفجي - الدمام)", "@mapdl1" }, { "⬇️ البحرين", "@mapdl2" },
                { "🏘 شوارع الأحياء (الكويت)", "@mapdl3" }, { "📥 استيراد خريطة من ملف", "@mapimp" }, { "📍 مواقع المعالم", "@mapdl9" }, { "⏹ إيقاف التنزيل", "@mapstop" } }, 2, C_BLUE));
        p.addView(mapTv);
        p.addView(title("كاميرات OpenStreetMap"));
        p.addView(mkBtn("فحص: كم كاميرا حولي؟", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) {
                sCamInfo = "جاري الفحص...";
                sCamForce = true;
                Toast.makeText(MainActivity.this, "ينتظر الموقع ويجلب الكاميرات", Toast.LENGTH_SHORT).show();
            }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        TextView n2 = new TextView(this);
        n2.setText("التطبيق يجلب كاميرات OSM ضمن 25 كم ويرسلها للجهاز تلقائياً (وتتحدث لما تتحرك أو كل نص ساعة). "
                + "إذا الرقم قليل، التغطية ضعيفة، وعلّم كاميراتك بنفسك.");
        n2.setTextSize(12);
        n2.setTextColor(Color.rgb(150, 150, 160));
        n2.setTextDirection(View.TEXT_DIRECTION_RTL);
        n2.setPadding(dp(2), dp(6), dp(2), dp(6));
        p.addView(n2);
        return p;
    }

    private void showCamList(String reply) {
        // الرد: "cu 3 osm 120: 1:29.37590,47.97740 2:..."
        int c = reply.indexOf(':');
        String rest = c >= 0 ? reply.substring(c + 1).trim() : "";
        final ArrayList<String> ids = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        if (rest.length() > 0) {
            for (String t : rest.split(" ")) {
                int k = t.indexOf(':');
                if (k < 1) continue;
                ids.add(t.substring(0, k));
                labels.add("كاميرا " + t.substring(0, k) + "   " + t.substring(k + 1));
            }
        }
        if (ids.isEmpty()) { Toast.makeText(this, "ما عندك كاميرات معلّمة", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle("اختر كاميرا للحذف (آخر 6)")
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { send("cdel " + ids.get(which)); }
                }).setNegativeButton("إلغاء", null).show();
    }

    // ---------------- تبويب الردود ----------------
    private LinearLayout buildLog() {
        LinearLayout p = vbox();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        cmdEdit = new EditText(this);
        cmdEdit.setHint("أمر مباشر مثل: status");
        cmdEdit.setHintTextColor(Color.GRAY);
        cmdEdit.setTextColor(Color.WHITE);
        cmdEdit.setSingleLine(true);
        cmdEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        row.addView(cmdEdit, new LinearLayout.LayoutParams(0, dp(52), 1f));
        row.addView(smallBtn("إرسال", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String c = cmdEdit.getText().toString().trim();
                if (c.length() > 0) { send(c); cmdEdit.setText(""); }
            }
        }));
        row.addView(smallBtn("مسح", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                synchronized (sLog) { sLog.clear(); }
                sLogVer++;
            }
        }));
        p.addView(row);
        logTv = new TextView(this);
        logTv.setTextSize(13);
        logTv.setTypeface(Typeface.MONOSPACE);
        logTv.setTextColor(Color.rgb(200, 230, 200));
        logTv.setPadding(dp(4), dp(10), dp(4), dp(10));
        p.addView(logTv);
        return p;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = getSharedPreferences("cfg", MODE_PRIVATE);
        sLgMask = lgMaskLoad(cfg);
        sEmKm = cfg.getInt("emKm", 250);
        sRange = cfg.getInt("range", 40);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(36), dp(12), dp(8));
        root.setBackgroundColor(C_BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView ttl = new TextView(this);
        ttl.setText("جسر الإطار");
        ttl.setTextSize(20);
        ttl.setTypeface(Typeface.DEFAULT_BOLD);
        ttl.setTextColor(Color.WHITE);
        top.addView(ttl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btn = mkBtn("ابدأ", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (sRunning) {
                    stopService(new Intent(MainActivity.this, Bridge.class));
                    sRunning = false;
                } else {
                    askAndStart();
                }
            }
        });
        Button battBtn = mkBtn("🔋", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) { sBatt = Bridge.sendCmd("batt") ? "..." : "الإطار غير متصل"; }
        });
        battBtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { sBatt = Bridge.sendCmd("i2cscan") ? "فحص I2C..." : "الإطار غير متصل"; return true; }
        });
        top.addView(battBtn, new LinearLayout.LayoutParams(dp(60), dp(48)));
        top.addView(btn, new LinearLayout.LayoutParams(dp(110), dp(48)));
        root.addView(top);

        tv = new TextView(this);
        tv.setTextSize(12);
        tv.setLineSpacing(0, 1.25f);
        tv.setTextColor(Color.rgb(200, 200, 212));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        tv.setPadding(dp(2), dp(6), dp(2), dp(6));

        LinearLayout dr = new LinearLayout(this);
        dr.setOrientation(LinearLayout.HORIZONTAL);
        String[] dn = { "بلوتوث", "GPS", "نت", "رادار", "نتائج", "كاميرات" };
        for (int i = 0; i < 6; i++) {
            dots[i] = new TextView(this);
            dots[i].setText("● " + dn[i]);
            dots[i].setTextSize(12);
            dots[i].setTextColor(Color.rgb(240, 70, 70));
            dots[i].setGravity(Gravity.CENTER);
            dr.addView(dots[i], new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(dr);
        stLine = new TextView(this);
        stLine.setTextSize(12);
        stLine.setTextColor(Color.rgb(200, 200, 212));
        stLine.setTextDirection(View.TEXT_DIRECTION_RTL);
        stLine.setPadding(dp(4), dp(2), dp(4), dp(4));
        root.addView(stLine);

        scroll = new ScrollView(this);
        content = vbox();
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = { "التحكم", "الإعدادات", "الخرائط", "الردود" };
        for (int i = 0; i < 4; i++) {
            final int k = i;
            tabBtns[i] = mkBtn(tn[i], C_CARD, new View.OnClickListener() {
                @Override public void onClick(View v) { selectTab(k); }
            });
            tabBtns[i].setTextSize(14);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
            lp.setMargins(dp(2), dp(4), dp(2), dp(2));
            tabs.addView(tabBtns[i], lp);
        }
        root.addView(tabs);

        panels[0] = buildControl();
        panels[1] = buildSettingsAll();
        panels[2] = buildCams();
        LinearLayout lg = vbox();
        lg.addView(tv);
        lg.addView(buildLog());
        panels[3] = lg;
        selectTab(0);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        lastLogVer = -1;
        h.post(ui);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(ui);
    }

    private void askAndStart() {
        ArrayList<String> need = new ArrayList<>();
        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        ArrayList<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            startBridge();
        } else {
            requestPermissions(missing.toArray(new String[0]), 7);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= 31) {
            ok = ok && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        if (ok) startBridge();
        else sBt = "لازم توافق على الأذونات";
    }

    private void startBridge() {
        Intent i = new Intent(this, Bridge.class);
        startForegroundService(i);
        sRunning = true;
    }

    // ------------------------------------------------------------------
    // الخدمة اللي تشتغل بالخلفية: موقع + اتجاه + بلوتوث + جلب الرادار والنتائج
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    public static class Bridge extends Service {
        static final UUID NUS = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
        static final String CH = "gpsbridge";

        static volatile Bridge sInst = null;

        private final Handler h = new Handler(Looper.getMainLooper());
        private LocationManager lm;
        private SensorManager sm;
        private BluetoothAdapter ad;
        private BluetoothLeScanner scanner;
        private volatile BluetoothGatt gatt;
        private volatile BluetoothGattCharacteristic rx;
        private volatile boolean ready = false;
        private volatile boolean discStarted = false;
        private boolean scanning = false;
        private boolean started = false;
        private boolean dead = false;
        private PowerManager.WakeLock wl;

        private Location loc;
        private long locAt = 0;
        private float compass = -1f;

        // طابور الكتابة: سطر كل 40 مللي ثانية
        private final ArrayDeque<String> queue = new ArrayDeque<>();
        private boolean pumping = false;
        private int writeFails = 0;
        private int payload = 20;                  // أكبر سطر نقدر نرسله (MTU - 3)

        // جلب البيانات من الإنترنت
        private final ExecutorService ex = Executors.newSingleThreadExecutor();
        private volatile boolean fetching = false;
        private long radarAt = 0;
        private long camAt = 0;
        private double camLat = 0, camLon = 0;
        private volatile boolean camBusy = false;
        private String lastCamHash = "";
        private final ArrayDeque<String> camLines = new ArrayDeque<>();
        private final long[] lgAt = new long[8];
        private final int[] lgLive = new int[8];   // 0 عادي، 1 قرّب يبدأ، 2 شغّالة

        static boolean sendCmd(String c) {
            final Bridge b = sInst;
            if (b == null || !b.ready) return false;
            final String cc = c;
            b.h.post(new Runnable() { @Override public void run() { b.enqueue(cc, false); } });
            return true;
        }

        @Override public IBinder onBind(Intent i) { return null; }

        @Override public int onStartCommand(Intent in, int flags, int id) {
            if (!started) {
                started = true;
                dead = false;
                sInst = this;
                goForeground();
                initAll();
            }
            return START_STICKY;
        }

        private void goForeground() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CH, "جسر الموقع", NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("جسر الإطار شغال")
                    .setContentText("يرسل الموقع والرادار والنتائج للإطار")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else {
                startForeground(1, n);
            }
        }

        private void initAll() {
            SharedPreferences cfg = getSharedPreferences("cfg", MODE_PRIVATE);
            sLgMask = lgMaskLoad(cfg);
            sRange = cfg.getInt("range", 40);

            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gpsbridge:wl");
            wl.acquire();

            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            try {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0,
                            ll, Looper.getMainLooper());
                } else {
                    sLoc = "شغّل الموقع GPS";
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0,
                            ll, Looper.getMainLooper());
                }
            } catch (Exception e) {
                sLoc = "خطأ: " + e.getMessage();
            }

            sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (rv != null) {
                sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
            } else {
                sHdg = "ما في حساس اتجاه";
            }

            BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            ad = bm.getAdapter();
            if (ad == null || !ad.isEnabled()) {
                sBt = "شغّل البلوتوث";
            }
            startScan();
            h.postDelayed(tick, 1000);
        }

        // ---------------- الموقع ----------------
        private final LocationListener ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                // نفضّل GPS على الشبكة إذا كان GPS حديث
                if (loc != null && LocationManager.GPS_PROVIDER.equals(loc.getProvider())
                        && !LocationManager.GPS_PROVIDER.equals(l.getProvider())
                        && System.currentTimeMillis() - locAt < 5000) {
                    return;
                }
                loc = l;
                locAt = System.currentTimeMillis();
                sLoc = String.format(Locale.US, "%.4f , %.4f", l.getLatitude(), l.getLongitude());
                pushGps(l);                                  // نرسل فور وصول القراءة (بدون ما ننتظر مؤقت الثانية)
            }
            @Override public void onStatusChanged(String p, int s, Bundle e) { }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
        };

        // ---------------- البوصلة ----------------
        private final SensorEventListener sl = new SensorEventListener() {
            final float[] R = new float[9];
            final float[] R2 = new float[9];
            final float[] o = new float[3];
            float sx = 0f, sy = 0f;
            boolean has = false;

            @Override public void onSensorChanged(SensorEvent e) {
                SensorManager.getRotationMatrixFromVector(R, e.values);
                float[] use = R;
                // الجوال واقف (مثبت بالسيارة): نستخدم اتجاه الكاميرا الخلفية
                if (Math.abs(R[8]) < 0.7f) {
                    SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_X,
                            SensorManager.AXIS_Z, R2);
                    use = R2;
                }
                SensorManager.getOrientation(use, o);
                double az = Math.toDegrees(o[0]);
                if (loc != null) {
                    GeomagneticField g = new GeomagneticField((float) loc.getLatitude(),
                            (float) loc.getLongitude(), (float) loc.getAltitude(),
                            System.currentTimeMillis());
                    az += g.getDeclination();
                }
                double r = Math.toRadians(az);
                float cx = (float) Math.cos(r), cy = (float) Math.sin(r);
                if (!has) { sx = cx; sy = cy; has = true; }
                else { sx = sx * 0.85f + cx * 0.15f; sy = sy * 0.85f + cy * 0.15f; }
                compass = (float) ((Math.toDegrees(Math.atan2(sy, sx)) + 360.0) % 360.0);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) { }
        };

        // ---------------- البلوتوث ----------------
        private void startScan() {
            if (dead) return;
            try {
                if (ad == null || !ad.isEnabled()) {
                    sBt = "شغّل البلوتوث";
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                scanner = ad.getBluetoothLeScanner();
                if (scanner == null) {
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                if (scanning) return;
                scanning = true;
                sBt = "يدور على الإطار...";
                scanner.startScan(scb);
            } catch (Exception e) {
                scanning = false;
                sBt = "خطأ بحث: " + e.getMessage();
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        }

        private void stopScan() {
            try {
                if (scanning && scanner != null) scanner.stopScan(scb);
            } catch (Exception ignored) { }
            scanning = false;
        }

        private final ScanCallback scb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult r) {
                if (gatt != null || dead) return;
                String n = null;
                ScanRecord sr = r.getScanRecord();
                if (sr != null) n = sr.getDeviceName();
                if (n == null) n = r.getDevice().getName();
                if (n != null && n.startsWith("Photo")) {
                    stopScan();
                    sBt = "يتصل...";
                    discStarted = false;
                    gatt = r.getDevice().connectGatt(Bridge.this, false, cb,
                            BluetoothDevice.TRANSPORT_LE);
                }
            }
            @Override public void onScanFailed(int err) {
                scanning = false;
                sBt = "فشل البحث (" + err + ")";
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        };

        private void startDiscovery(BluetoothGatt g) {
            if (discStarted) return;
            discStarted = true;
            g.discoverServices();
        }

        private void markReady() {
            if (ready) return;
            ready = true;
            sBt = "متصل";
            radarAt = 0;                                   // أول ما نتصل نجيب البيانات فوراً
            for (int i = 0; i < lgAt.length; i++) lgAt[i] = 0;
            mapSent = false; mapLines.clear(); sMapWanted = false;
            enqueue("mapq", false);                        // نسأل الإطار: الخريطة مفتوحة؟
            log("— اتصل بالإطار —");
        }

        private final BluetoothGattCallback cb = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(final BluetoothGatt g, int status, int ns) {
                if (ns == BluetoothGatt.STATE_CONNECTED) {
                    sBt = "متصل (يجهز)";
                    if (!g.requestMtu(185)) startDiscovery(g);
                    h.postDelayed(new Runnable() {
                        @Override public void run() { startDiscovery(g); }
                    }, 2500);
                } else {
                    ready = false;
                    rx = null;
                    gatt = null;
                    queue.clear();
                    pumping = false;
                    try { g.close(); } catch (Exception ignored) { }
                    sBt = "انقطع، يعيد المحاولة";
                    if (!dead) {
                        h.postDelayed(new Runnable() {
                            @Override public void run() { startScan(); }
                        }, 3000);
                    }
                }
            }

            @Override public void onMtuChanged(BluetoothGatt g, int mtu, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS && mtu > 23) payload = mtu - 3;
                startDiscovery(g);
            }

            @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
                BluetoothGattService s = g.getService(NUS);
                BluetoothGattCharacteristic c = (s == null) ? null : s.getCharacteristic(RX);
                if (c == null) {
                    sBt = "خدمة الإطار مو موجودة";
                    g.disconnect();
                    return;
                }
                c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                rx = c;
                // نشترك بردود الإطار (TX) عشان تطلع بتبويب الردود
                boolean waiting = false;
                try {
                    BluetoothGattCharacteristic t = s.getCharacteristic(TX);
                    if (t != null) {
                        g.setCharacteristicNotification(t, true);
                        BluetoothGattDescriptor d = t.getDescriptor(CCCD);
                        if (d != null) {
                            d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            waiting = g.writeDescriptor(d);
                        }
                    }
                } catch (Exception ignored) { }
                if (waiting) {
                    h.postDelayed(new Runnable() { @Override public void run() { markReady(); } }, 1500);
                } else {
                    markReady();
                }
            }

            @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
                markReady();
            }

            @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
                try {
                    byte[] v = c.getValue();
                    if (v == null) return;
                    String t = new String(v, StandardCharsets.UTF_8).trim();
                    if (t.startsWith("cu ")) sCamList = t;
                    if (t.startsWith("OK batt ")) sBatt = t.substring(8);
                    if (t.startsWith("I2C ")) sBatt = t;
                    if (t.startsWith("OK match alerts ")) sMa = t.endsWith("on") ? 1 : 0;
                    if (t.startsWith("OK cam alerts ")) sCamOn = t.endsWith("on") ? 1 : 0;
                    if (t.startsWith("OK cam sound ")) sCamSnd = t.endsWith("on") ? 1 : 0;
                    if (t.startsWith("ST ")) {
                        if (t.contains("ma=1")) sMa = 1; else if (t.contains("ma=0")) sMa = 0;
                        if (t.contains("cam=1")) sCamOn = 1; else if (t.contains("cam=0")) sCamOn = 0;
                        if (t.contains("snd=1")) sCamSnd = 1; else if (t.contains("snd=0")) sCamSnd = 0;
                        if (t.contains(" fl=1")) sFlash = 1; else if (t.contains(" fl=0")) sFlash = 0;
                        if (t.contains(" ad=1")) sCamAdd = 1; else if (t.contains(" ad=0")) sCamAdd = 0;
                        java.util.regex.Matcher mm = java.util.regex.Pattern.compile("mp=([01])([01])([01])\\.(\\d)").matcher(t);
                        if (mm.find()) { sMapNames = mm.group(1).equals("1") ? 1 : 0; sMapLm = mm.group(2).equals("1") ? 1 : 0; sMapCams = mm.group(3).equals("1") ? 1 : 0; }
                    }
                    if (t.startsWith("MAPREQ ")) { boolean w = t.endsWith("1"); if (w) sMapForce = true; sMapWanted = w; }
                    if (t.startsWith("OK flash ")) sFlash = t.endsWith("on") ? 1 : 0;
                    if (t.startsWith("OK camadd ")) sCamAdd = t.endsWith("on") ? 1 : 0;
                    if (t.startsWith("OK map names=")) { sMapNames = t.contains("names=1") ? 1 : 0; sMapLm = t.contains("lm=1") ? 1 : 0; sMapCams = t.contains("cams=1") ? 1 : 0; }
                    if (t.startsWith("mreq ")) sendDetails(t);
                    if (t.length() > 0) log("< " + t);
                } catch (Exception ignored) { }
            }
        };

        // ---------------- طابور الكتابة ----------------
        private void enqueue(String line, boolean front) {
            if (!ready) return;
            if (queue.size() > 160) return;
            String l = line;
            if (l.length() > payload) {                    // أطول من الحزمة: ما نرسله مقطوع (يخرب الأمر)
                if (!l.startsWith("rp ") && !l.startsWith("sm ")) log("! الأمر أطول من حجم الحزمة (" + payload + ")");
                return;
            }
            if (front) queue.addFirst(l); else queue.addLast(l);
            if (!pumping) {
                pumping = true;
                h.post(pump);
            }
        }

        private boolean writeLine(BluetoothGatt g, BluetoothGattCharacteristic c, String line) {
            byte[] b = line.getBytes(StandardCharsets.US_ASCII);
            if (Build.VERSION.SDK_INT >= 33) {
                return g.writeCharacteristic(c, b, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == 0;
            }
            c.setValue(b);
            return g.writeCharacteristic(c);
        }

        private final Runnable pump = new Runnable() {
            @Override public void run() {
                BluetoothGatt g = gatt;
                BluetoothGattCharacteristic c = rx;
                if (!ready || g == null || c == null) { queue.clear(); pumping = false; return; }
                String line = queue.pollFirst();
                if (line == null) { pumping = false; return; }
                boolean ok = false;
                try { ok = writeLine(g, c, line); } catch (Exception ignored) { }
                if (!ok && ++writeFails < 20) {
                    queue.addFirst(line);                  // الخط مشغول: نعيد بعد شوي
                    h.postDelayed(this, 80);
                    return;
                }
                writeFails = 0;
                h.postDelayed(this, 40);
            }
        };

        // ---------------- جلب الرادار والنتائج ----------------
        private void startFetch(final boolean radar, final int li, final double lat, final double lon, final int range) {
            fetching = true;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> lines;
                        int live = 0;
                        if (radar) {
                            List<String> rl = Feeds.radar(lat, lon, range);
                            ArrayList<String> all = new ArrayList<>(rl);
                            all.addAll(Feeds.routes());                       // من وين لوين (بدون ما نوقف الرادار إذا فشل)
                            lines = all;
                            sRdrInfo = (lines.size() == 1 && lines.get(0).equals("rp 0 0") ? 0 : countRp(lines))
                                    + " طيارة | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) + " | " + Feeds.radarNote;
                        } else {
                            Feeds.Scores sc = Feeds.scores(li);
                            lines = sc.lines;
                            live = sc.live ? 2 : sc.soon ? 1 : 0;
                            sMl.put(li, sc.ms);
                            sScInfo = Feeds.LG_AR[li] + ": " + (lines.size() == 1 && lines.get(0).endsWith(" 0 0") ? 0 : lines.size())
                                    + " مباراة | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        }
                        if (!radar) lgLive[li] = live;
                        h.post(new Runnable() {
                            @Override public void run() {
                                for (String l : lines) enqueue(l, false);
                            }
                        });
                    } catch (Exception e) {
                        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        if (radar) sRdrInfo = "خطأ: " + m; else { sScInfo = "خطأ: " + m; sScErrN++; }
                    } finally {
                        if (radar) sRdrN++; else sScN++;
                        fetching = false;
                    }
                }
            });
        }

        // الإطار طلب تفاصيل مباراة: mreq <li> <id>
        private volatile boolean detBusy = false;
        private void sendDetails(String t) {
            if (detBusy) return;
            String[] p = t.split(" ");
            if (p.length < 3) return;
            final int li; try { li = Integer.parseInt(p[1]); } catch (Exception e) { return; }
            if (li < 0 || li >= Feeds.SLUG.length) return;
            final String id = Feeds.clean(p[2], 11);
            detBusy = true;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> ls = Feeds.details(li, id, payload);
                        h.post(new Runnable() { @Override public void run() { for (String l : ls) enqueue(l, true); } });
                    } catch (Exception e) {
                        log("! تفاصيل المباراة: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
                    } finally { detBusy = false; }
                }
            });
        }

        private int countRp(List<String> l) { int c = 0; for (String x : l) if (x.startsWith("rp ")) c++; return c; }

        private volatile boolean emBusy = false;
        private long emAt = 0;

        // فحص الطوارئ بمدى واسع (كل 30 ثانية) ويرسل للإطار فقط إذا في طيارة بحالة طوارئ
        private void emStep() {
            if (!ready || emBusy || sEmKm <= 0 || queue.size() > 20) return;
            long now = SystemClock.elapsedRealtime();
            Location l = loc;
            if (l == null || System.currentTimeMillis() - locAt > 60000 || (emAt != 0 && now - emAt < 30000)) return;
            emAt = now;
            emBusy = true;
            final double la = l.getLatitude(), lo = l.getLongitude();
            final int km = sEmKm;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> lines = Feeds.emergencies(la, lo, km);
                        if (!lines.isEmpty()) sEmInfo = lines.size() + " طوارئ | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        h.post(new Runnable() { @Override public void run() { for (String x : lines) enqueue(x, true); } });
                    } catch (Exception ignored) {
                    } finally { emBusy = false; }
                }
            });
        }

        private void feedStep() {
            if (!ready || fetching || payload < 100 || queue.size() > 30) return;
            long now = SystemClock.elapsedRealtime();
            Location l = loc;
            if (sLgForce) { sLgForce = false; for (int i = 0; i < lgAt.length; i++) lgAt[i] = 0; }      // زر «تحديث المباريات»
            if (sRdrForce && l != null && System.currentTimeMillis() - locAt < 60000) {                // زر «إعادة تشغيل الرادار»
                sRdrForce = false; radarAt = now;
                startFetch(true, 0, l.getLatitude(), l.getLongitude(), sRange);
                return;
            }
            boolean radarDue = l != null && System.currentTimeMillis() - locAt < 60000 && (radarAt == 0 || now - radarAt >= 15000);
            // النتائج أهم من الرادار (التنبيهات): الرادار أول بس إذا تأخر أكثر من 40 ثانية، وما يسد على النتائج
            if (radarDue && radarAt != 0 && now - radarAt >= 40000) {
                radarAt = now;
                startFetch(true, 0, l.getLatitude(), l.getLongitude(), sRange);
                return;
            }
            for (int li = 0; li < Feeds.SLUG.length; li++) {
                if ((sLgMask & (1 << li)) == 0) continue;
                long every = lgLive[li] == 2 ? 5000 : lgLive[li] == 1 ? 20000 : 60000;   // شغّالة 5 ثواني، قرّبت 20، غيرها دقيقة
                if (lgAt[li] == 0 || now - lgAt[li] >= every) {
                    lgAt[li] = now;
                    startFetch(false, li, 0, 0, 0);
                    return;
                }
            }
            if (radarDue) {
                radarAt = now;
                startFetch(true, 0, l.getLatitude(), l.getLongitude(), sRange);
                return;
            }
        }

        // ---------------- الخريطة على الإطار ----------------
        private volatile boolean mapBusy = false, mapSent = false;
        private long mapAt = 0, lastCurAt = 0; private double mapLat, mapLon;
        private String lastCurName = "";
        private final ArrayDeque<String> mapLines = new ArrayDeque<>();

        private void mapStep() {
            if (ready && !mapLines.isEmpty() && queue.size() < 8) {
                for (int i = 0; i < 20 && !mapLines.isEmpty(); i++) enqueue(mapLines.pollFirst(), false);
            }
            if (!ready) return;
            if (!getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("mapSync", true)) return;
            Location l = loc;
            if (l == null || System.currentTimeMillis() - locAt > 60000) return;
            long now = SystemClock.elapsedRealtime();
            if (sMapWanted && now - lastCurAt > 2500 && MapData.last != null) {        // اسم الشارع الحالي
                lastCurAt = now;
                String nm = MapData.streetAt(MapData.last, l.getLatitude(), l.getLongitude());
                if (!nm.equals(lastCurName)) { lastCurName = nm; enqueue("mcur " + nm, false); }
            }
            if (mapBusy || payload < 100 || !mapLines.isEmpty()) return;
            boolean force = sMapForce;
            boolean need = !mapSent || force;
            if (!need && sMapWanted) {
                float[] r = new float[1];
                Location.distanceBetween(mapLat, mapLon, l.getLatitude(), l.getLongitude(), r);
                need = r[0] > 600;
            }
            if (!need && !sMapWanted && now - mapAt < 60000) return;
            if (!need) return;
            if (!force && now - mapAt < 8000) return;
            sMapForce = false;
            mapBusy = true;
            mapAt = now;
            final double la = l.getLatitude(), lo = l.getLongitude();
            final int pl = payload;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        java.io.File base = getFilesDir();
                        List<int[]> lms = MapData.loadLandmarks(base);
                        MapData.Built b = MapData.build(base, la, lo, lms, pl - 8, 3500);
                        if (!b.missing.isEmpty()) {                        // خلايا ناقصة: نجرب ننزلها الحين لو في نت
                            boolean got = false;
                            for (int i = 0; i < Math.min(4, b.missing.size()); i++) {
                                try { MapData.fetchCell(base, b.missing.get(i)[0], b.missing.get(i)[1], false); got = true; } catch (Exception ignored) { }
                            }
                            if (got) b = MapData.build(base, la, lo, lms, pl - 8, 3500);
                        }
                        final MapData.Built fb = b;
                        if (fb.ways == 0) {
                            sMapInfo = "الخريطة: ما في بيانات طرق هنا (نزّل خرائط المنطقة)";
                            mapAt = SystemClock.elapsedRealtime() - 45000;
                            return;
                        }
                        MapData.last = fb;
                        sMapInfo = "الخريطة: " + fb.ways + " طريق، " + fb.pts + " نقطة | " + new java.text.SimpleDateFormat("HH:mm", Locale.US).format(new java.util.Date());
                        mapLat = la; mapLon = lo; mapSent = true;
                        h.post(new Runnable() { @Override public void run() { mapLines.clear(); mapLines.addAll(fb.lines); lastCurName = ""; } });
                    } catch (Exception e) {
                        sMapInfo = "خطأ الخريطة: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                        mapAt = SystemClock.elapsedRealtime() - 45000;
                    } finally {
                        mapBusy = false;
                    }
                }
            });
        }

        // ---------------- كاميرات OSM ----------------
        private void camStep() {
            // نفرّغ أسطر الكاميرات للطابور بالتدريج (ما نزحم الأوامر الثانية)
            if (ready && !camLines.isEmpty() && queue.size() < 12) {
                for (int i = 0; i < 6 && !camLines.isEmpty(); i++) enqueue(camLines.pollFirst(), false);
            }
            if (camBusy) return;
            Location l = loc;
            if (l == null || System.currentTimeMillis() - locAt > 60000) return;
            long now = SystemClock.elapsedRealtime();
            boolean force = sCamForce;
            boolean moved = false;
            if (camAt != 0) {
                float[] r = new float[1];
                Location.distanceBetween(camLat, camLon, l.getLatitude(), l.getLongitude(), r);
                moved = r[0] > 6000;
            }
            if (!force && !(ready && (camAt == 0 || moved || now - camAt >= 30 * 60 * 1000L))) return;
            if (!force && payload < 100) return;
            sCamForce = false;
            camBusy = true;
            camAt = now;
            camLat = l.getLatitude(); camLon = l.getLongitude();
            final double la = camLat, lo = camLon;
            final boolean fc = force;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        List<int[]> base;
                        try { base = Feeds.bundled(getAssets().open("kw_cams.csv")); } catch (Exception e) { base = new ArrayList<>(); }
                        base = Feeds.addDedup(base, Feeds.loadRoad(new java.io.File(getFilesDir(), "road_cams.csv")));
                        List<int[]> osm;
                        String osmErr = "";
                        try { osm = Feeds.cameras(la, lo, 25000); }
                        catch (Exception e) { osm = new ArrayList<>(); osmErr = " | OSM ما رد"; }
                        List<int[]> cams = Feeds.mergeCams(base, osm, la, lo, 2900);
                        int near5 = 0;
                        for (int[] c : cams) if (c[2] <= 5000) near5++;
                        String stamp = new java.text.SimpleDateFormat("HH:mm", Locale.US).format(new java.util.Date());
                        sCamInfo = cams.size() + " كاميرا (" + base.size() + " جاهزة + " + osm.size() + " OSM، " + near5 + " ضمن 5 كم) | " + stamp
                                + osmErr + (cams.isEmpty() ? " | علّم كاميراتك" : "");
                        StringBuilder hs = new StringBuilder();
                        for (int[] c : cams) hs.append(c[0]).append(',').append(c[1]).append(',').append(c[3]).append(',').append(c[4]).append(' ');
                        final String hash = cams.size() + ":" + hs.toString().hashCode();
                        if (!fc && hash.equals(lastCamHash)) return;           // نفس القائمة: ما نكتب بذاكرة الجهاز
                        final ArrayList<String> lines = new ArrayList<>();
                        lines.add("cclr");
                        int max = Math.max(40, payload - 6);
                        StringBuilder cur = new StringBuilder();
                        for (int[] c : cams) {
                            String t = c[0] + "," + c[1] + (c[3] != 0 || c[4] != 0 ? "," + c[3] + "," + c[4] : "");   // نوع الكاميرا وحد السرعة (÷10)
                            if (cur.length() + t.length() + 1 > max) { lines.add("cadd " + cur.toString().trim()); cur.setLength(0); }
                            cur.append(t).append(' ');
                        }
                        if (cur.length() > 0) lines.add("cadd " + cur.toString().trim());
                        lines.add("csave");
                        lastCamHash = hash;
                        h.post(new Runnable() {
                            @Override public void run() { camLines.clear(); camLines.addAll(lines); }
                        });
                    } catch (Exception e) {
                        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        sCamInfo = "خطأ: " + m;
                        camAt = SystemClock.elapsedRealtime() - (30 * 60 * 1000L - 60000);   // نعيد بعد دقيقة
                    } finally {
                        sCamN++;
                        camBusy = false;
                    }
                }
            });
        }

        private long lastGpsTx = 0;
        /** يرسل قراءة GPS للإطار: سرعة واتجاه من نفس القراءة */
        private void pushGps(Location l) {
            try {
                if (!ready || l == null) return;
                float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                int hdg = -1;
                if (kmh >= 7f && l.hasBearing()) hdg = Math.round(l.getBearing()) % 360;
                else if (compass >= 0f) hdg = Math.round(compass) % 360;
                String line = String.format(Locale.US, "gps %.5f %.5f %d %d",
                        l.getLatitude(), l.getLongitude(), hdg, Math.round(kmh));
                if (queue.size() < 40) enqueue(line, true);
                lastGpsTx = SystemClock.elapsedRealtime();
                sTx = new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
            } catch (Exception ignored) { }
        }

        // ---------------- الإرسال كل ثانية ----------------
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                try {
                    Location l = loc;
                    long age = System.currentTimeMillis() - locAt;
                    if (l != null) {
                        float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                        int hdg = -1;
                        if (kmh >= 7f && l.hasBearing()) hdg = Math.round(l.getBearing()) % 360;
                        else if (compass >= 0f) hdg = Math.round(compass) % 360;
                        sHdg = hdg < 0 ? "-" : hdg + "°";
                        sSpd = Math.round(kmh) + " km/h";
                        if (age > 15000) sLoc = "الموقع قديم، انتظر GPS";
                        if (ready && age < 15000 && SystemClock.elapsedRealtime() - lastGpsTx > 1500) pushGps(l);   // احتياط إذا ما وصلت قراءة جديدة
                    } else if (!sLoc.startsWith("شغّل") && !sLoc.startsWith("خطأ")) {
                        sLoc = "ينتظر إشارة GPS...";
                    }
                    camStep();
                    mapStep();
                    feedStep();
                    emStep();
                } catch (Exception ignored) { }
                if (!dead) h.postDelayed(this, 1000);
            }
        };

        @Override public void onDestroy() {
            dead = true;
            started = false;
            sInst = null;
            h.removeCallbacksAndMessages(null);
            try { ex.shutdownNow(); } catch (Exception ignored) { }
            try { lm.removeUpdates(ll); } catch (Exception ignored) { }
            try { sm.unregisterListener(sl); } catch (Exception ignored) { }
            stopScan();
            try {
                BluetoothGatt g = gatt;
                if (g != null) { g.disconnect(); g.close(); }
            } catch (Exception ignored) { }
            gatt = null;
            ready = false;
            try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
            sRunning = false;
            sBt = "غير متصل";
            super.onDestroy();
        }
    }
}
