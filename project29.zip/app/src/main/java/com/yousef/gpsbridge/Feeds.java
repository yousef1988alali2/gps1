package com.yousef.gpsbridge;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** جلب الرادار والنتائج من الإنترنت (من الجوال) وتحويلها لأسطر مضغوطة يفهمها الإطار. */
final class Feeds {
    private Feeds() { }

    static final String[] SLUG = { "eng.1", "esp.1", "ita.1", "ger.1", "uefa.champions", "uefa.europa", "eng.fa", "eng.league_cup" };
    static final String[] LG_AR = { "الدوري الإنجليزي", "الدوري الإسباني", "الدوري الإيطالي",
            "الدوري الألماني", "دوري الأبطال", "الدوري الأوروبي", "كأس الاتحاد (ليفربول)", "كأس الرابطة (ليفربول)" };
    static final String LFC = "364";

    static String get(String url) throws IOException { return get(url, 12000); }

    static String get(String url, int readMs) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(readMs);
            c.setRequestProperty("User-Agent", CHROME);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (bo.size() > 4 * 1024 * 1024) throw new IOException("too big");
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    /** يحوّل الحروف الأوروبية لإنجليزية ويشيل الفواصل اللي تخرب البروتوكول، ويقص الطول. */
    static String clean(String s, int max) {
        if (s == null) return "";
        String t = Normalizer.normalize(s, Normalizer.Form.NFD);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length() && sb.length() < max; i++) {
            char ch = t.charAt(i);
            if (ch == '|' || ch == ';' || ch == '\n' || ch == '\r' || ch == '\t') ch = ' ';
            if (ch >= 32 && ch < 127) sb.append(ch);
            else if (ch >= 0x300 && ch < 0x370) continue;   // علامات التشكيل بعد التفكيك
            else if (ch == 0xF8) sb.append('o');
            else if (ch == 0xD8) sb.append('O');
            else if (ch == 0xDF) sb.append("ss");
            else if (ch == 0x141) sb.append('L');
            else if (ch == 0x142) sb.append('l');
            else sb.append('?');
        }
        return sb.toString().trim();
    }

    /** كاميرات السرعة من OpenStreetMap حول نقطة (نصف القطر بالمتر). يرجع {lat×1e5, lon×1e5} الأقرب أول. */
    static List<int[]> cameras(double lat0, double lon0, int radiusM) throws Exception {
        String q = String.format(Locale.US,
                "[out:json][timeout:25];(node[\"highway\"=\"speed_camera\"](around:%d,%.5f,%.5f);"
                        + "node[\"enforcement\"~\"maxspeed|traffic_signals|average_speed\"](around:%d,%.5f,%.5f););out 4000;",
                radiusM, lat0, lon0, radiusM, lat0, lon0);
        String enc = java.net.URLEncoder.encode(q, "UTF-8");
        String body;
        try {
            body = get("https://overpass-api.de/api/interpreter?data=" + enc, 30000);
        } catch (Exception e) {
            body = get("https://overpass.kumi.systems/api/interpreter?data=" + enc, 30000);
        }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("elements");
        final double cl = Math.cos(Math.toRadians(lat0));
        final ArrayList<double[]> tmp = new ArrayList<>();   // {dist, la, lo, type, limit/10}
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject a = arr.optJSONObject(i);
                if (a == null || !a.has("lat") || !a.has("lon")) continue;
                long la = Math.round(a.optDouble("lat") * 100000.0), lo = Math.round(a.optDouble("lon") * 100000.0);
                if (!seen.add(la * 100000000L + lo)) continue;
                double dx = (lo / 100000.0 - lon0) * cl * 111320.0, dy = (la / 100000.0 - lat0) * 111320.0;
                JSONObject tg = a.optJSONObject("tags");
                String enf = tg == null ? "" : tg.optString("enforcement", "");
                int ty = enf.contains("traffic_signals") ? 1 : enf.contains("average_speed") ? 2 : 0;   // 0 سرعة، 1 إشارة، 2 متوسطة
                int lim = 0;
                if (tg != null) { try { lim = Integer.parseInt(tg.optString("maxspeed", "0").replaceAll("[^0-9]", "")) / 10; } catch (Exception ignored) { } }
                if (ty != 0 || lim < 3 || lim > 25) lim = ty == 0 && lim >= 3 && lim <= 25 ? lim : 0;
                tmp.add(new double[] { Math.sqrt(dx * dx + dy * dy), la, lo, ty, lim });
            }
        }
        Collections.sort(tmp, new Comparator<double[]>() {
            @Override public int compare(double[] x, double[] y) { return Double.compare(x[0], y[0]); }
        });
        ArrayList<int[]> out = new ArrayList<>();
        for (int i = 0; i < tmp.size() && i < 2900; i++) out.add(new int[] { (int) tmp.get(i)[1], (int) tmp.get(i)[2], (int) tmp.get(i)[0], (int) tmp.get(i)[3], (int) tmp.get(i)[4] });
        return out;
    }

    /** كاميرات الكويت الجاهزة (MapAtlas، CC BY 4.0) من ملف داخل التطبيق. يرجع {lat×1e5, lon×1e5} */
    static List<int[]> bundled(java.io.InputStream in) {
        ArrayList<int[]> out = new ArrayList<>();
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(in, StandardCharsets.UTF_8));
            String ln = br.readLine();                                  // العنوان
            while ((ln = br.readLine()) != null) {
                String[] f = ln.split(",");
                if (f.length < 3) continue;
                try {
                    double lo = Double.parseDouble(f[1].trim()), la = Double.parseDouble(f[2].trim());
                    String cl = f.length > 3 ? f[3].trim() : "spot";
                    int ty = "signal".equals(cl) ? 1 : "corridor".equals(cl) ? 2 : 0;
                    int lim = 0;
                    if (f.length > 4) { try { lim = Integer.parseInt(f[4].trim()) / 10; } catch (NumberFormatException ignored) { } }
                    out.add(new int[] { (int) Math.round(la * 100000.0), (int) Math.round(lo * 100000.0), 0, ty, lim });
                } catch (NumberFormatException ignored) { }
            }
            br.close();
        } catch (Exception ignored) { }
        return out;
    }

    /** يدمج الكاميرات الجاهزة مع OSM: نشيل المكرر (أقل من 40 متر)، نرتب بالأقرب، ونقص عند الحد. */
    // ---------------- كاميرات الطريق (الكويت ← الدمام ← البحرين) تنحفظ بالجوال للأوفلاين ----------------
    static final double[] ROAD_BOX = { 25.7, 47.2, 29.6, 51.0 };   // جنوب، غرب، شمال، شرق

    /** ينزّل كاميرات OSM لمنطقة الطريق ويحفظها بملف: كل سطر la,lo,نوع,حد÷10. يرجع العدد */
    static int downloadRoad(java.io.File f) throws Exception {
        String q = String.format(Locale.US, "[out:json][timeout:90][bbox:%.2f,%.2f,%.2f,%.2f];(node[\"highway\"=\"speed_camera\"];"
                + "node[\"enforcement\"~\"maxspeed|traffic_signals|average_speed\"];);out 8000;", ROAD_BOX[0], ROAD_BOX[1], ROAD_BOX[2], ROAD_BOX[3]);
        String enc = java.net.URLEncoder.encode(q, "UTF-8");
        String body;
        try { body = get("https://overpass-api.de/api/interpreter?data=" + enc, 100000); }
        catch (Exception e) { body = get("https://overpass.kumi.systems/api/interpreter?data=" + enc, 100000); }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("elements");
        StringBuilder sb = new StringBuilder();
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        int n = 0;
        if (arr != null) for (int i = 0; i < arr.length(); i++) {
            JSONObject a = arr.optJSONObject(i);
            if (a == null || !a.has("lat") || !a.has("lon")) continue;
            long la = Math.round(a.optDouble("lat") * 100000.0), lo = Math.round(a.optDouble("lon") * 100000.0);
            if (!seen.add(la * 100000000L + lo)) continue;
            JSONObject tg = a.optJSONObject("tags");
            String enf = tg == null ? "" : tg.optString("enforcement", "");
            int ty = enf.contains("traffic_signals") ? 1 : enf.contains("average_speed") ? 2 : 0;
            int lim = 0;
            if (tg != null) { try { lim = Integer.parseInt(tg.optString("maxspeed", "0").replaceAll("[^0-9]", "")) / 10; } catch (Exception ignored) { } }
            if (ty != 0 || lim < 3 || lim > 25) lim = ty == 0 && lim >= 3 && lim <= 25 ? lim : 0;
            sb.append(la).append(',').append(lo).append(',').append(ty).append(',').append(lim).append('\n');
            n++;
        }
        if (n == 0) throw new IOException("ما رجعت كاميرات");
        java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
        try { fo.write(sb.toString().getBytes(StandardCharsets.UTF_8)); } finally { fo.close(); }
        return n;
    }

    /** يقرا الملف المحفوظ بنفس شكل bundled: {la, lo, 0, نوع, حد÷10} */
    static List<int[]> loadRoad(java.io.File f) {
        ArrayList<int[]> out = new ArrayList<>();
        if (f == null || !f.exists()) return out;
        try {
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(f), StandardCharsets.UTF_8));
            String ln;
            while ((ln = br.readLine()) != null) {
                String[] t = ln.split(",");
                if (t.length < 4) continue;
                try { out.add(new int[] { Integer.parseInt(t[0]), Integer.parseInt(t[1]), 0, Integer.parseInt(t[2]), Integer.parseInt(t[3]) }); } catch (NumberFormatException ignored) { }
            }
            br.close();
        } catch (Exception ignored) { }
        return out;
    }

    /** يضيف extra لـbase ويتجاهل اللي قريب (أقل من 40م) من كاميرا موجودة */
    static List<int[]> addDedup(List<int[]> base, List<int[]> extra) {
        ArrayList<int[]> out = new ArrayList<>(base);
        for (int[] e : extra) {
            boolean dup = false;
            double cl = Math.cos(Math.toRadians(e[0] / 100000.0));
            for (int[] b : base) {
                double dx = (e[1] - b[1]) / 100000.0 * cl * 111320.0, dy = (e[0] - b[0]) / 100000.0 * 111320.0;
                if (dx * dx + dy * dy < 1600) { dup = true; break; }
            }
            if (!dup) out.add(e);
        }
        return out;
    }

    static List<int[]> mergeCams(List<int[]> base, List<int[]> osm, double lat0, double lon0, int cap) {
        final double cl = Math.cos(Math.toRadians(lat0));
        ArrayList<int[]> all = new ArrayList<>();
        for (int[] b : base) all.add(b);
        for (int[] o : osm) {
            boolean dup = false;
            for (int[] b : base) {
                double dx = (o[1] - b[1]) / 100000.0 * cl * 111320.0, dy = (o[0] - b[0]) / 100000.0 * 111320.0;
                if (dx * dx + dy * dy < 1600) { dup = true; break; }
            }
            if (!dup) all.add(o);
        }
        for (int[] c : all) {
            double dx = (c[1] / 100000.0 - lon0) * cl * 111320.0, dy = (c[0] / 100000.0 - lat0) * 111320.0;
            c[2] = (int) Math.sqrt(dx * dx + dy * dy);
        }
        Collections.sort(all, new Comparator<int[]>() {
            @Override public int compare(int[] x, int[] y) { return Integer.compare(x[2], y[2]); }
        });
        return all.size() > cap ? new ArrayList<>(all.subList(0, cap)) : all;
    }

    private static final class Ac {
        double km, brg, trk, alt, gs, lat, lon;
        String fl, ty = "-", air = "-", emerg = "";
        int vr, sq;
    }

    /** شركات الطيران الشائعة حسب أول 3 حروف من رمز الرحلة */
    private static final java.util.HashMap<String, String> AIRL = new java.util.HashMap<>();
    static {
        String[] a = { "KAC", "Kuwait Airways", "JZR", "Jazeera", "UAE", "Emirates", "QTR", "Qatar Airways", "ETD", "Etihad", "SVA", "Saudia",
                "FDB", "flydubai", "ABY", "Air Arabia", "GFA", "Gulf Air", "OMA", "Oman Air", "MEA", "MEA", "RJA", "Royal Jordanian",
                "THY", "Turkish", "PGT", "Pegasus", "IRA", "Iran Air", "MAH", "Mahan Air", "IAW", "Iraqi Airways", "MSR", "EgyptAir",
                "BAW", "British Airways", "DLH", "Lufthansa", "AFR", "Air France", "KLM", "KLM", "SIA", "Singapore", "THA", "Thai",
                "AIC", "Air India", "IGO", "IndiGo", "PIA", "PIA", "SEP", "Fly Sepahan", "FIN", "Finnair", "SWR", "Swiss", "UPS", "UPS",
                "FDX", "FedEx", "DHL", "DHL", "GEC", "Lufthansa Cargo", "RYR", "Ryanair", "AAL", "American", "UAL", "United", "DAL", "Delta",
                "QFA", "Qantas", "CPA", "Cathay", "ANA", "ANA", "JAL", "Japan Air", "EVA", "EVA Air", "SAS", "SAS", "VIR", "Virgin Atl",
                "PAK", "Pakistan Intl", "SKY", "Sky Air", "RBG", "Royal Brunei", "AXB", "Air India Exp", "SDM", "Rossiya", "AFL", "Aeroflot" };
        for (int i = 0; i + 1 < a.length; i += 2) AIRL.put(a[i], a[i + 1]);
    }
    private static String airline(String fl) { return fl.length() >= 4 && fl.matches("[A-Z]{3}[0-9].*") ? AIRL.get(fl.substring(0, 3)) : null; }

    /** آخر طيارات الرادار (لجلب مساراتها) */
    static volatile List<Ac> lastAcs = new ArrayList<>();

    private static Ac parseAc(JSONObject a, double lat0, double lon0, double cl) {
        if (a == null || !a.has("lat") || !a.has("lon")) return null;
        Ac x = new Ac();
        x.lat = a.optDouble("lat"); x.lon = a.optDouble("lon");
        double dx = (x.lon - lon0) * cl * 111.32, dy = (x.lat - lat0) * 110.57;
        x.km = Math.sqrt(dx * dx + dy * dy);
        double b = Math.toDegrees(Math.atan2(dx, dy));
        x.brg = b < 0 ? b + 360 : b;
        x.trk = a.optDouble("track", 0);
        Object ab = a.opt("alt_baro");
        x.alt = (ab instanceof Number) ? ((Number) ab).doubleValue() : 0;
        x.gs = a.optDouble("gs", 0);
        String fl = clean(a.optString("flight", ""), 8).replace(" ", "");
        x.fl = fl.isEmpty() ? "-" : fl;
        String t = clean(a.optString("t", ""), 4).replace(" ", "");
        x.ty = t.isEmpty() ? "-" : t;
        String al = airline(x.fl);
        x.air = al == null ? "-" : clean(al, 14).replace(' ', '_');
        Object br = a.opt("baro_rate");
        x.vr = (br instanceof Number) ? ((Number) br).intValue() : 0;
        try { x.sq = Integer.parseInt(a.optString("squawk", "0").trim()); } catch (Exception e) { x.sq = 0; }
        String em = a.optString("emergency", "none");
        x.emerg = "none".equals(em) || em.isEmpty() ? "" : em;
        return x;
    }

    private static String emReason(Ac x) {
        switch (x.emerg) {
            case "lifeguard": return "MEDICAL";
            case "minfuel": return "LOW FUEL";
            case "nordo": return "NO RADIO";
            case "unlawful": return "HIJACK";
            case "downed": return "DOWNED";
            case "general": return "GENERAL";
            default: break;
        }
        return x.sq == 7700 ? "GENERAL" : x.sq == 7600 ? "NO RADIO" : x.sq == 7500 ? "HIJACK" : "";
    }

    /** الطيارات اللي بحالة طوارئ ضمن نصف قطر واسع. أسطر em للإطار */
    static List<String> emergencies(double lat0, double lon0, int radiusKm) throws Exception {
        int nm = (int) Math.ceil(radiusKm / 1.852);
        if (nm < 20) nm = 20;
        if (nm > 250) nm = 250;
        String body;
        String p = String.format(Locale.US, "%.4f/%.4f/%d", lat0, lon0, nm);
        try { body = get("https://api.adsb.lol/v2/point/" + p); }
        catch (Exception e) { body = get("https://api.airplanes.live/v2/point/" + p); }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("ac");
        if (arr == null) arr = o.optJSONArray("aircraft");
        ArrayList<String> out = new ArrayList<>();
        if (arr == null) return out;
        double cl = Math.cos(Math.toRadians(lat0));
        for (int i = 0; i < arr.length() && out.size() < 3; i++) {
            JSONObject a = arr.optJSONObject(i);
            Ac x = parseAc(a, lat0, lon0, cl);
            if (x == null || x.km > radiusKm) continue;
            String why = emReason(x);
            if (why.isEmpty()) continue;
            String hex = clean(a.optString("hex", x.fl), 8);
            String code = x.sq > 0 ? String.valueOf(x.sq) : "----";
            String ta = ("-".equals(x.ty) ? "" : x.ty) + ("-".equals(x.air) ? "" : (x.ty.equals("-") ? "" : " ") + x.air.replace('_', ' '));
            String[] rt = ROUTES.get(x.fl);
            String route = rt != null && rt.length >= 2 ? rt[0] + " > " + rt[1] : "";
            String info = String.format(Locale.US, "%.0f km  %,d ft", x.km, (int) x.alt);
            out.add("em " + hex + "|" + x.fl + "|" + code + "|" + why + "|" + clean(ta, 23) + "|" + route + "|" + info);
        }
        return out;
    }

    // ---- مسارات الرحلات (من وين ولوين) ----
    private static final java.util.HashMap<String, String[]> ROUTES = new java.util.HashMap<>();      // callsign → {o, d, oCity, dCity, dLat, dLon, oLat, oLon}
    private static final java.util.HashMap<String, Long> ROUTE_TRY = new java.util.HashMap<>();       // وقت آخر محاولة (لا نكرر الفاشلة)

    private static double hav(double la1, double lo1, double la2, double lo2) {
        double dla = Math.toRadians(la2 - la1), dlo = Math.toRadians(lo2 - lo1);
        double h = Math.sin(dla / 2) * Math.sin(dla / 2) + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dlo / 2) * Math.sin(dlo / 2);
        return 12742.0 * Math.asin(Math.min(1, Math.sqrt(h)));
    }

    private static String post(String url, String json) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("User-Agent", CHROME);
            c.getOutputStream().write(json.getBytes(StandardCharsets.UTF_8));
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 512 * 1024) break; }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    /** أسطر rt لأقرب 8 طيارات (يجلب المسارات الناقصة بطلب واحد، ويحسب المسافة المتبقية للوجهة). */
    static List<String> routes() {
        ArrayList<String> out = new ArrayList<>();
        List<Ac> acs = lastAcs;
        long now = System.currentTimeMillis();
        try {
            JSONArray req = new JSONArray();
            int cnt = 0;
            for (int i = 0; i < acs.size() && i < 8; i++) {
                Ac x = acs.get(i);
                if (!x.fl.matches("[A-Z]{3}[0-9].*") || ROUTES.containsKey(x.fl)) continue;
                Long t = ROUTE_TRY.get(x.fl);
                if (t != null && now - t < 10 * 60 * 1000L) continue;
                ROUTE_TRY.put(x.fl, now);
                JSONObject j = new JSONObject();
                j.put("callsign", x.fl); j.put("lat", x.lat); j.put("lng", x.lon);
                req.put(j); cnt++;
            }
            if (cnt > 0) {
                JSONObject body = new JSONObject();
                body.put("planes", req);
                String r = post("https://api.adsb.lol/api/0/routeset", body.toString());
                JSONArray ra = r.trim().startsWith("[") ? new JSONArray(r) : new JSONArray();
                for (int i = 0; i < ra.length(); i++) {
                    JSONObject e = ra.optJSONObject(i);
                    if (e == null) continue;
                    String cs = clean(e.optString("callsign", ""), 8);
                    JSONArray ap = e.optJSONArray("_airports");
                    if (cs.isEmpty() || ap == null || ap.length() < 2) continue;
                    JSONObject o0 = ap.optJSONObject(0), d0 = ap.optJSONObject(ap.length() - 1);
                    if (o0 == null || d0 == null) continue;
                    String oc = clean(o0.optString("iata", ""), 4), dc = clean(d0.optString("iata", ""), 4);
                    if (oc.isEmpty()) oc = clean(o0.optString("icao", ""), 4);
                    if (dc.isEmpty()) dc = clean(d0.optString("icao", ""), 4);
                    ROUTES.put(cs, new String[] { oc, dc, clean(o0.optString("location", ""), 13), clean(d0.optString("location", ""), 13),
                            String.valueOf(d0.optDouble("lat", 0)), String.valueOf(d0.optDouble("lon", 0)),
                            String.valueOf(o0.optDouble("lat", 0)), String.valueOf(o0.optDouble("lon", 0)) });
                }
            }
        } catch (Exception ignored) { }
        for (int i = 0; i < acs.size() && i < 8; i++) {
            Ac x = acs.get(i);
            String[] r = ROUTES.get(x.fl);
            if (r == null) continue;
            double dl = Double.parseDouble(r[4]), dn = Double.parseDouble(r[5]), ol = Double.parseDouble(r[6]), on = Double.parseDouble(r[7]);
            double rem = (dl == 0 && dn == 0) ? 0 : hav(x.lat, x.lon, dl, dn), tot = (dl == 0 && ol == 0) ? 0 : hav(ol, on, dl, dn);
            out.add(String.format(Locale.US, "rt %s %s|%s|%s|%s|%.0f|%.0f", x.fl, r[0], r[1], r[2], r[3], rem, tot));
        }
        return out;
    }

    /** أسطر الرادار: الأقرب أول. إذا ما في طيارات يرجع سطر واحد "rp 0 0". */
    static List<String> radar(double lat0, double lon0, int rangeKm) throws Exception {
        int nm = (int) Math.ceil(rangeKm / 1.852);
        if (nm < 5) nm = 5;
        if (nm > 250) nm = 250;
        String p = String.format(Locale.US, "%.4f/%.4f/%d", lat0, lon0, nm);
        String body;
        try {
            body = get("https://api.adsb.lol/v2/point/" + p, 6000);
        } catch (Exception e) {
            body = get("https://api.airplanes.live/v2/point/" + p, 6000);
        }
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("ac");
        if (arr == null) arr = o.optJSONArray("aircraft");
        ArrayList<Ac> list = new ArrayList<>();
        double cl = Math.cos(Math.toRadians(lat0));
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                Ac x = parseAc(arr.optJSONObject(i), lat0, lon0, cl);
                if (x == null || x.km > rangeKm * 1.05) continue;
                list.add(x);
            }
        }
        Collections.sort(list, new Comparator<Ac>() {
            @Override public int compare(Ac a, Ac b) { return Double.compare(a.km, b.km); }
        });
        ArrayList<String> out = new ArrayList<>();
        int n = Math.min(list.size(), 24);
        lastAcs = new ArrayList<>(list.subList(0, n));
        if (n == 0) {
            out.add("rp 0 0");
            return out;
        }
        for (int i = 0; i < n; i++) {
            Ac x = list.get(i);
            out.add(String.format(Locale.US, "rp %d %d %.1f %.0f %.0f %.0f %.0f %s %s %s %d %d",
                    i, n, x.km, x.brg, x.trk, x.alt, x.gs, x.fl, x.ty, x.air, x.vr, x.sq));
        }
        return out;
    }

    /** نتيجة دوري: الأسطر + هل في مباراة شغالة (عشان نعرف نحدّث كل 20 ثانية). */
    static final class Scores {
        final ArrayList<String> lines = new ArrayList<>();
        boolean live = false;     // في مباراة شغالة (كل 5 ثواني)
        boolean soon = false;     // مباراة تبدأ خلال 5 دقايق (كل 20 ثانية)
        final ArrayList<String[]> ms = new ArrayList<>();   // {id, hAr, aAr, hN, aN, hs, as, state, clk}
    }

    private static int rank(int st) { return st == 1 ? 0 : st == 2 ? 1 : 2; }

    private static final class M {
        String id = "", hA = "", aA = "", hN = "", aN = "", hId = "", aId = "", clk = "", gName = "", gClk = "", gTid = "";
        int hs, as, state;
        long ko;
        int nRed;
        String rName = "", rClk = "", rTid = "";
        final ArrayList<String[]> goals = new ArrayList<>();   // {name, clk, tid}
    }

    private static String shortNm(String n, int cap) {
        if (n.length() < cap) return n;
        int sp = n.lastIndexOf(' ');
        String r = sp >= 0 ? n.substring(sp + 1) : n;
        return r.length() > cap - 1 ? r.substring(0, cap - 1) : r;
    }


    // ---------------- تفاصيل مباراة (ESPN summary) ----------------
    // أسماء الحقول من ESPN غير مؤكدة 100%؛ الكود حذر وإذا ناقص شي ما يرسله.
    private static String lastNm(String n, int cap) {
        String t = clean(n, 40).trim();
        int sp = t.lastIndexOf(' ');
        String r = sp >= 0 && t.length() > cap ? t.substring(sp + 1) : t;
        return r.length() > cap ? r.substring(0, cap) : r;
    }
    private static int statInt(JSONObject team, String name) {
        JSONArray st = team == null ? null : team.optJSONArray("statistics");
        if (st == null) return -1;
        for (int i = 0; i < st.length(); i++) {
            JSONObject x = st.optJSONObject(i);
            if (x != null && name.equals(x.optString("name", ""))) {
                String v = x.optString("displayValue", x.optString("value", ""));
                try { return (int) Math.round(Double.parseDouble(v.replace("%", "").trim())); } catch (Exception e) { return -1; }
            }
        }
        return -1;
    }
    static List<String> details(int li, String id, int payload) throws Exception {
        ArrayList<String> out = new ArrayList<>();
        String body = get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + SLUG[li] + "/summary?event=" + id);
        JSONObject o = new JSONObject(body);
        String homeId = "";
        JSONObject hd = o.optJSONObject("header");
        JSONArray hc = hd == null ? null : hd.optJSONArray("competitions");
        JSONObject c0 = hc == null ? null : hc.optJSONObject(0);
        JSONArray cps = c0 == null ? null : c0.optJSONArray("competitors");
        if (cps != null) for (int i = 0; i < cps.length(); i++) {
            JSONObject c = cps.optJSONObject(i);
            if (c != null && "home".equals(c.optString("homeAway", ""))) { JSONObject t = c.optJSONObject("team"); if (t != null) homeId = t.optString("id", ""); else homeId = c.optString("id", ""); }
        }
        // الأحداث
        JSONArray ke = o.optJSONArray("keyEvents");
        ArrayList<String[]> evs = new ArrayList<>();
        if (ke != null) for (int i = 0; i < ke.length(); i++) {
            JSONObject e = ke.optJSONObject(i);
            if (e == null) continue;
            JSONObject ty = e.optJSONObject("type");
            String tt = ty == null ? "" : (ty.optString("text", "") + " " + ty.optString("type", "")).toLowerCase(Locale.US);
            String code;
            if (tt.contains("own goal")) code = "o";
            else if (tt.contains("yellow")) code = "y";
            else if (tt.contains("red")) code = "r";
            else if (tt.contains("substitution")) code = "s";
            else if (tt.contains("goal") && !tt.contains("kick") && !tt.contains("saved") && !tt.contains("missed") && !tt.contains("disallowed")) code = "g";
            else if (tt.contains("penalty") && tt.contains("scored")) code = "g";
            else continue;
            JSONObject ck = e.optJSONObject("clock"); JSONObject tm = e.optJSONObject("team");
            String min = ck == null ? "" : clean(ck.optString("displayValue", ""), 6);
            String txt = e.optString("text", e.optString("shortText", ""));
            JSONArray pa = e.optJSONArray("participants");
            String p0 = "", p1 = "";
            if (pa != null) {
                JSONObject a0 = pa.optJSONObject(0), a1 = pa.optJSONObject(1);
                JSONObject at0 = a0 == null ? null : a0.optJSONObject("athlete"), at1 = a1 == null ? null : a1.optJSONObject("athlete");
                if (at0 != null) p0 = at0.optString("displayName", "");
                if (at1 != null) p1 = at1.optString("displayName", "");
            }
            String who = p0, ast = "";
            if ("s".equals(code)) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("([^.]+?) replaces ([^.]+?)(?:\\.| due|$)").matcher(txt);
                if (m.find()) { who = m.group(1); ast = m.group(2); }
                else { who = p0; ast = p1; }
            } else if ("g".equals(code)) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("Assisted by ([^.]+?)(?: with|\\.|$)").matcher(txt);
                if (m.find()) ast = m.group(1); else ast = p1;
            }
            String tid = tm == null ? "" : tm.optString("id", "");
            evs.add(new String[] { code, min, lastNm(who, 20), lastNm(ast, 20), tid.equals(homeId) ? "0" : "1" });
        }
        int from = Math.max(0, evs.size() - 18), n = evs.size() - from;
        for (int i = 0; i < n; i++) {
            String[] e = evs.get(from + i);
            out.add("mde " + li + " " + id + "|" + i + "|" + n + "|" + e[0] + "|" + e[1] + "|" + e[2] + "|" + e[3] + "|" + e[4]);
        }
        if (n == 0) out.add("mde " + li + " " + id + "|0|0|x|||| 0");
        // الإحصائيات
        JSONObject bx = o.optJSONObject("boxscore");
        JSONArray bt = bx == null ? null : bx.optJSONArray("teams");
        if (bt != null && bt.length() >= 2) {
            JSONObject h = null, a = null;
            for (int i = 0; i < bt.length(); i++) {
                JSONObject t = bt.optJSONObject(i); if (t == null) continue;
                JSONObject tm = t.optJSONObject("team");
                String tid = tm == null ? "" : tm.optString("id", "");
                if (tid.equals(homeId) && h == null) h = t; else if (a == null) a = t;
            }
            if (h == null || a == null) { h = bt.optJSONObject(0); a = bt.optJSONObject(1); }
            int pos = statInt(h, "possessionPct");
            String[] keys = { "totalShots", "shotsOnTarget", "wonCorners", "foulsCommitted" };
            StringBuilder sb = new StringBuilder("mdh " + li + " " + id + "|" + (pos >= 0 ? String.valueOf(pos) : ""));
            for (String k : keys) { sb.append("|").append(Math.max(0, statInt(h, k))).append("|").append(Math.max(0, statInt(a, k))); }
            out.add(sb.toString());
        }
        // التشكيلة
        JSONArray ro = o.optJSONArray("rosters");
        if (ro != null) for (int i = 0; i < ro.length(); i++) {
            JSONObject r = ro.optJSONObject(i); if (r == null) continue;
            JSONObject tm = r.optJSONObject("team");
            String tid = tm == null ? "" : tm.optString("id", "");
            boolean home = "home".equals(r.optString("homeAway", "")) || (tid.length() > 0 && tid.equals(homeId));
            JSONArray rr = r.optJSONArray("roster");
            if (rr == null) continue;
            StringBuilder sb = new StringBuilder();
            int cnt = 0;
            for (int k = 0; k < rr.length() && cnt < 12; k++) {
                JSONObject pl = rr.optJSONObject(k);
                if (pl == null || !pl.optBoolean("starter", false)) continue;
                JSONObject at = pl.optJSONObject("athlete");
                String nm = at == null ? "" : lastNm(at.optString("displayName", at.optString("shortName", "")), 11);
                if (nm.isEmpty()) continue;
                String pre = "mdl " + li + " " + id + "|" + (home ? 0 : 1) + "|";
                if (pre.length() + sb.length() + nm.length() + 1 > payload - 4) break;
                if (cnt > 0) sb.append('/');
                sb.append(nm); cnt++;
            }
            if (cnt > 0) out.add("mdl " + li + " " + id + "|" + (home ? 0 : 1) + "|" + sb);
        }
        return out;
    }

    // اليوم والوقت بتوقيت الكويت: Today 21:00 / Tomorrow 18:30 / Fri 28 Nov 20:30
    static String dayLabel(long ko) {
        java.util.TimeZone tz = java.util.TimeZone.getTimeZone("Asia/Kuwait");
        java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("HH:mm", Locale.US); tf.setTimeZone(tz);
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("EEE d MMM", Locale.US); df.setTimeZone(tz);
        java.text.SimpleDateFormat kd = new java.text.SimpleDateFormat("yyyyMMdd", Locale.US); kd.setTimeZone(tz);
        long now = System.currentTimeMillis();
        String d0 = kd.format(new java.util.Date(ko)), dn = kd.format(new java.util.Date(now)), dt = kd.format(new java.util.Date(now + 86400000L));
        String t = tf.format(new java.util.Date(ko));
        if (d0.equals(dn)) return "Today " + t;
        if (d0.equals(dt)) return "Tomorrow " + t;
        return df.format(new java.util.Date(ko)) + " " + t;
    }

    static Scores scores(int li) throws Exception {
        String body = get("https://site.api.espn.com/apis/site/v2/sports/soccer/" + SLUG[li] + "/scoreboard");
        JSONObject o = new JSONObject(body);
        JSONArray ev = o.optJSONArray("events");
        ArrayList<M> ms = new ArrayList<>();
        if (ev != null) {
            for (int i = 0; i < ev.length() && ms.size() < 14; i++) {
                JSONObject e = ev.optJSONObject(i);
                if (e == null) continue;
                M m = new M();
                m.id = clean(e.optString("id", ""), 11);
                JSONObject st = e.optJSONObject("status");
                if (st != null) {
                    m.clk = clean(st.optString("displayClock", ""), 9);
                    JSONObject ty = st.optJSONObject("type");
                    String s = ty == null ? "" : ty.optString("state", "");
                    m.state = "in".equals(s) ? 1 : "post".equals(s) ? 2 : 0;
                }
                m.ko = parseDate(e.optString("date", ""));
                if (m.state == 0 && m.ko > 0) {                                  // وقت البداية بتوقيت الكويت (HH:mm)
                    m.clk = dayLabel(m.ko);
                }
                JSONArray comps = e.optJSONArray("competitions");
                JSONObject comp = comps == null ? null : comps.optJSONObject(0);
                if (comp == null) continue;
                JSONArray cs = comp.optJSONArray("competitors");
                if (cs == null || cs.length() < 2) continue;
                JSONObject home = null, away = null;
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject c = cs.optJSONObject(k);
                    if (c == null) continue;
                    String ha = c.optString("homeAway", "");
                    if ("home".equals(ha)) home = c;
                    else if ("away".equals(ha)) away = c;
                }
                if (home == null) home = cs.optJSONObject(0);
                if (away == null) away = cs.optJSONObject(1);
                if (home == null || away == null) continue;
                JSONObject ht = home.optJSONObject("team"), at = away.optJSONObject("team");
                if (ht != null) {
                    m.hA = clean(ht.optString("abbreviation", ""), 5);
                    m.hN = clean(ht.optString("displayName", ""), 23);
                    m.hId = clean(ht.optString("id", ""), 7);
                }
                if (at != null) {
                    m.aA = clean(at.optString("abbreviation", ""), 5);
                    m.aN = clean(at.optString("displayName", ""), 23);
                    m.aId = clean(at.optString("id", ""), 7);
                }
                m.hs = parseInt(home.optString("score", "0"));
                m.as = parseInt(away.optString("score", "0"));
                JSONArray det = comp.optJSONArray("details");
                if (det != null) {
                    for (int k = 0; k < det.length(); k++) {
                        JSONObject d = det.optJSONObject(k);
                        if (d == null) continue;
                        if (d.optBoolean("redCard", false)) {
                            JSONArray ra = d.optJSONArray("athletesInvolved");
                            JSONObject r0 = ra == null ? null : ra.optJSONObject(0);
                            JSONObject rc = d.optJSONObject("clock"), rt = d.optJSONObject("team");
                            m.nRed++;
                            m.rName = r0 == null ? "" : clean(r0.optString("displayName", ""), 21);
                            m.rClk = rc == null ? "" : clean(rc.optString("displayValue", ""), 7);
                            m.rTid = rt == null ? "" : clean(rt.optString("id", ""), 7);
                            continue;
                        }
                        if (!d.optBoolean("scoringPlay", false)) continue;
                        JSONArray ai = d.optJSONArray("athletesInvolved");
                        JSONObject a0 = ai == null ? null : ai.optJSONObject(0);
                        JSONObject ck = d.optJSONObject("clock");
                        JSONObject tm = d.optJSONObject("team");
                        m.gName = a0 == null ? "" : clean(a0.optString("displayName", ""), 21);
                        m.gClk = ck == null ? "" : clean(ck.optString("displayValue", ""), 7);
                        m.gTid = tm == null ? "" : clean(tm.optString("id", ""), 7);
                        m.goals.add(new String[] { shortNm(m.gName, 16), m.gClk, m.gTid });
                    }
                }
                if (li >= 6 && !LFC.equals(m.hId) && !LFC.equals(m.aId)) continue;   // الكؤوس: ليفربول بس
                ms.add(m);
            }
        }
        Collections.sort(ms, new Comparator<M>() {                         // ثابت: شغالة، منتهية، قادمة
            @Override public int compare(M a, M b) {
                int d = rank(a.state) - rank(b.state);
                if (d == 0 && a.state == 0 && a.ko > 0 && b.ko > 0) return Long.compare(a.ko, b.ko);
                return d;
            }
        });
        Scores r = new Scores();
        int n = ms.size();
        if (n == 0) {
            r.lines.add("sm " + li + " 0 0");
            return r;
        }
        for (int i = 0; i < n; i++) {
            M m = ms.get(i);
            if (m.state == 1) r.live = true;
            long dt = m.ko - System.currentTimeMillis();
            if (m.state == 0 && m.ko > 0 && dt < 5 * 60 * 1000L && dt > -30 * 60 * 1000L) r.soon = true;   // قرّبت البداية: نجلب كل 20 ثانية
            r.ms.add(new String[] { m.id, m.hA, m.aA, m.hN, m.aN, String.valueOf(m.hs), String.valueOf(m.as), String.valueOf(m.state), m.clk });
            r.lines.add("sm " + li + " " + i + " " + n + " " + m.id + "|" + m.hA + "|" + m.aA + "|" + m.hN + "|" + m.aN + "|"
                    + m.hId + "|" + m.aId + "|" + m.hs + "|" + m.as + "|" + m.state + "|" + m.clk + "|"
                    + m.gName + "|" + m.gClk + "|" + m.gTid + "|" + m.nRed + "|"
                    + (m.state == 0 && m.ko > 0 ? String.valueOf(Math.max(0L, (m.ko - System.currentTimeMillis()) / 60000L)) : ""));
            int ng = Math.min(m.goals.size(), 7);
            for (int k = 0; k < ng; k++) {
                String[] g = m.goals.get(k);
                r.lines.add("sg " + li + " " + m.id + "|" + ng + "|" + k + "|" + g[0] + "|" + g[1] + "|" + g[2]);
            }
            if (m.nRed > 0) r.lines.add("sr " + li + " " + m.id + "|" + shortNm(m.rName, 16) + "|" + m.rClk + "|" + m.rTid);
        }
        return r;
    }

    /** تاريخ ESPN مثل 2026-11-23T20:00Z → مللي ثانية (UTC)، أو 0 إذا ما فهمه */
    private static long parseDate(String d) {
        if (d == null || d.length() < 16) return 0;
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return f.parse(d.substring(0, 16)).getTime();
        } catch (Exception e) { return 0; }
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    // ---------------- اختبار مصادر النتائج من الجوال (زر بتبويب المباريات) ----------------
    static volatile String afKey = "";
    private static String xHdrK = null, xHdrV = null;
    private static String getUa(String url, int readMs, String ua) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(readMs);
            c.setRequestProperty("User-Agent", ua);
            c.setRequestProperty("Accept", "application/json, text/plain, */*");
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            if (xHdrK != null) c.setRequestProperty(xHdrK, xHdrV);
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                if (bo.size() > 6 * 1024 * 1024) throw new IOException("too big");
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    private static final String CHROME = "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private static String testOne(String name, String url, int kind) {
        long t0 = System.currentTimeMillis();
        try {
            String body = getUa(url, 10000, CHROME);
            long ms = System.currentTimeMillis() - t0;
            int n = 0; String sample = "";
            if (kind == 4) {                                   // Flashscore (نص)
                int p = 0;
                while ((p = body.indexOf("AA\u00f7", p)) >= 0) { n++; p += 3; }
                int h = body.indexOf("AE\u00f7");
                if (h >= 0) { int e = body.indexOf('\u00ac', h); if (e > h) sample = body.substring(h + 3, e); }
                return "✓ " + name + ": " + n + " مباراة · " + ms + "ms" + (sample.isEmpty() ? "" : "\n   مثال: " + sample + " ...");
            }
            JSONObject o = new JSONObject(body);
            if (kind == 6) {                                   // API-Football (مفتاح)
                JSONArray rs = o.optJSONArray("response");
                int cnt = rs == null ? 0 : rs.length();
                if (cnt > 0) {
                    JSONObject f = rs.optJSONObject(0);
                    JSONObject tm = f == null ? null : f.optJSONObject("teams"), gl = f == null ? null : f.optJSONObject("goals");
                    JSONObject hh = tm == null ? null : tm.optJSONObject("home"), aa = tm == null ? null : tm.optJSONObject("away");
                    sample = (hh == null ? "?" : hh.optString("name", "?")) + " " + (gl == null ? "-" : gl.optString("home", "-")) + "-" + (gl == null ? "-" : gl.optString("away", "-")) + " " + (aa == null ? "?" : aa.optString("name", "?"));
                }
                Object er = o.opt("errors");
                String es = er == null ? "" : er.toString();
                if (es.length() > 2 && !es.equals("[]")) return "✕ " + name + ": " + es + " · " + ms + "ms";
                JSONObject pg = o.optJSONObject("paging");
                return "✓ " + name + ": " + cnt + " شغّالة · " + ms + "ms" + (sample.isEmpty() ? "" : "\n   مثال: " + sample);
            }
            if (kind == 7) {                                   // 365Scores
                JSONArray gm = o.optJSONArray("games");
                int live = 0;
                if (gm != null) for (int i = 0; i < gm.length(); i++) {
                    JSONObject g = gm.optJSONObject(i); if (g == null) continue;
                    if (g.optInt("statusGroup", 0) == 3) {
                        live++;
                        if (sample.isEmpty()) {
                            JSONObject hc = g.optJSONObject("homeCompetitor"), ac = g.optJSONObject("awayCompetitor");
                            sample = (hc == null ? "?" : hc.optString("name", "?")) + " " + (hc == null ? "-" : hc.optString("score", "-")) + "-" + (ac == null ? "-" : ac.optString("score", "-")) + " " + (ac == null ? "?" : ac.optString("name", "?"));
                        }
                    }
                }
                if (sample.isEmpty()) sample = (gm == null ? 0 : gm.length()) + " مباراة اليوم";
                return "✓ " + name + ": " + live + " شغّالة · " + ms + "ms" + "\n   مثال: " + sample;
            }
            if (kind == 3) {                                   // FotMob
                JSONArray lg = o.optJSONArray("leagues");
                int live = 0, tot = 0;
                if (lg != null) for (int i = 0; i < lg.length(); i++) {
                    JSONObject l = lg.optJSONObject(i); if (l == null) continue;
                    JSONArray ms2 = l.optJSONArray("matches"); if (ms2 == null) continue;
                    for (int j = 0; j < ms2.length(); j++) {
                        JSONObject m = ms2.optJSONObject(j); if (m == null) continue;
                        tot++;
                        JSONObject st = m.optJSONObject("status");
                        boolean on = st != null && st.optBoolean("started", false) && !st.optBoolean("finished", false);
                        if (on) {
                            live++;
                            if (sample.isEmpty()) {
                                JSONObject hh = m.optJSONObject("home"), aa = m.optJSONObject("away");
                                sample = (hh == null ? "?" : hh.optString("name", "?")) + " " + st.optString("scoreStr", "-") + " " + (aa == null ? "?" : aa.optString("name", "?"));
                            }
                        }
                    }
                }
                if (sample.isEmpty()) sample = tot + " مباراة اليوم";
                return "✓ " + name + ": " + live + " شغّالة · " + ms + "ms" + "\n   مثال: " + sample;
            }
            if (kind == 0) {                                   // ESPN (الدوري الإنجليزي)
                JSONArray ev = o.optJSONArray("events");
                int live = 0;
                if (ev != null) for (int i = 0; i < ev.length(); i++) {
                    JSONObject e = ev.optJSONObject(i); if (e == null) continue;
                    JSONObject st = e.optJSONObject("status"); JSONObject ty = st == null ? null : st.optJSONObject("type");
                    if (ty != null && "in".equals(ty.optString("state", ""))) live++;
                }
                n = live; sample = (ev == null ? 0 : ev.length()) + " مباراة اليوم";
            } else if (kind == 1) {                            // SofaScore
                JSONArray ev = o.optJSONArray("events");
                n = ev == null ? 0 : ev.length();
                if (n > 0) {
                    JSONObject e = ev.optJSONObject(0);
                    JSONObject h = e.optJSONObject("homeTeam"), a = e.optJSONObject("awayTeam"), hs = e.optJSONObject("homeScore"), as = e.optJSONObject("awayScore");
                    sample = (h == null ? "?" : h.optString("name", "?")) + " " + (hs == null ? "-" : hs.optString("current", "-")) + "-" + (as == null ? "-" : as.optString("current", "-")) + " " + (a == null ? "?" : a.optString("name", "?"));
                }
            } else {                                           // LiveScore
                JSONArray st = o.optJSONArray("Stages");
                if (st != null) for (int i = 0; i < st.length(); i++) {
                    JSONObject g = st.optJSONObject(i); if (g == null) continue;
                    JSONArray ev = g.optJSONArray("Events");
                    if (ev != null) {
                        n += ev.length();
                        if (sample.isEmpty() && ev.length() > 0) {
                            JSONObject e = ev.optJSONObject(0);
                            JSONArray t1 = e.optJSONArray("T1"), t2 = e.optJSONArray("T2");
                            sample = (t1 == null || t1.optJSONObject(0) == null ? "?" : t1.optJSONObject(0).optString("Nm", "?")) + " " + e.optString("Tr1", "-") + "-" + e.optString("Tr2", "-") + " "
                                    + (t2 == null || t2.optJSONObject(0) == null ? "?" : t2.optJSONObject(0).optString("Nm", "?"));
                        }
                    }
                }
            }
            return "✓ " + name + ": " + n + (kind == 0 ? " شغّالة" : " مباراة") + " · " + ms + "ms" + (sample.isEmpty() ? "" : "\n   مثال: " + sample);
        } catch (Exception e) {
            long ms = System.currentTimeMillis() - t0;
            String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            return "✕ " + name + ": " + m + " · " + ms + "ms";
        }
    }

    static String testSources() {
        StringBuilder sb = new StringBuilder();
        sb.append(testOne("ESPN", "https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard", 0)).append('\n');
        sb.append(testOne("SofaScore", "https://api.sofascore.com/api/v1/sport/football/events/live", 1)).append('\n');
        sb.append(testOne("SofaScore (موقع ثاني)", "https://www.sofascore.com/api/v1/sport/football/events/live", 1)).append('\n');
        sb.append(testOne("SofaScore (app)", "https://api.sofascore.app/api/v1/sport/football/events/live", 1)).append('\n');
        sb.append(testOne("LiveScore", "https://prod-public-api.livescore.com/v1/api/app/live/soccer/0?locale=en", 2)).append('\n');
        String day = new java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(new java.util.Date());
        sb.append(testOne("FotMob", "https://www.fotmob.com/api/matches?date=" + day, 3)).append('\n');
        sb.append(testOne("FotMob (data)", "https://www.fotmob.com/api/data/matches?date=" + day + "&timezone=Asia%2FKuwait&ccode3=KWT", 3)).append('\n');
        sb.append(testOne("365Scores", "https://webws.365scores.com/web/games/current/?appTypeId=5&langId=1&timezoneName=Asia/Kuwait&userCountryId=-1&sports=1", 7)).append('\n');
        if (afKey != null && afKey.length() > 10) {
            xHdrK = "x-apisports-key"; xHdrV = afKey;
            try { sb.append(testOne("API-Football", "https://v3.football.api-sports.io/fixtures?live=all", 6)).append('\n'); }
            finally { xHdrK = null; xHdrV = null; }
        } else sb.append("• API-Football: ما فيه مفتاح محفوظ\n");
        xHdrK = "x-fsign"; xHdrV = "SW9D1eZo";
        try { sb.append(testOne("Flashscore", "https://d.flashscore.com/x/feed/f_1_0_3_en_1", 4)); }
        finally { xHdrK = null; xHdrV = null; }
        return sb.toString();
    }
}
