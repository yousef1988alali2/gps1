package com.yousef.gpsbridge;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.media.projection.MediaProjectionManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // ---------------- الحالة اللي تتشارك بين الخدمة والشاشة ----------------
    static volatile String sBt = "غير متصل";
    static volatile String sLoc = "-";
    static volatile String sHdg = "-";
    static volatile String sSpd = "-";
    static volatile String sTx = "-";
    static volatile String sRdrInfo = "-";
    static volatile String sScInfo = "-";
    static volatile String sEmInfo = "-";
    static volatile int sEmKm = 250;      // مدى فحص الطوارئ (كم)، 0 = متوقف
    static volatile String sCamInfo = "-";
    static volatile boolean sCamForce = false;    // اضغط فحص/تحديث: يجلب كاميرات OSM الحين
    static volatile boolean sWantList = false;
    static volatile String sCamList = null;
    static volatile boolean sRunning = false;
    static volatile int sLgMask = 255;     // أي دوريات يجلبها الجوال
    static volatile int sRange = 40;      // مدى الرادار (كم)
    static volatile int sLogVer = 0;
    static final ArrayList<String> sLog = new ArrayList<>();

    static void log(String s) {
        synchronized (sLog) {
            sLog.add(s);
            while (sLog.size() > 80) sLog.remove(0);
        }
        sLogVer++;
    }

    // الأوضاع اللي تدخل بالميكس المخصص: اسم الأمر + الوصف
    static final String[][] MIXI = {
            { "photos", "الصور" }, { "analog", "ساعة عقارب" }, { "digital", "ساعة رقمية" }, { "weather", "الطقس" },
            { "pendulum", "البندول" }, { "gforce", "قوة الحركة" }, { "alali", "العلي (عربي)" }, { "yousef", "يوسف (عربي)" },
            { "names", "الأسماء" }, { "yousefen", "Yousef إنجليزي" }, { "alalien", "Alali إنجليزي" }, { "mixen", "مكس إنجليزي" },
            { "mixaren", "مكس عربي/إنجليزي" }, { "ymix", "يوسف عربي/إنجليزي" }, { "amix", "Alali إنجليزي/عربي" }, { "hypno", "الخدع البصرية" }, { "compass", "البوصلة (يحتاج موقع)" },
            { "radar", "الرادار" }, { "scores", "النتائج (إذا في مباراة شغالة)" }, { "speed", "السرعة (يحتاج موقع)" }, { "camrad", "رادار الكاميرات (يحتاج موقع)" } };
    static final String MIX_DEF = ",analog,weather,pendulum,gforce,compass,radar,scores,";
    static final int[] MIX_SECS = { 5, 10, 15, 20, 30, 60 };

    private static final int C_BG = Color.rgb(12, 12, 16);
    private static final int C_CARD = Color.rgb(32, 32, 40);
    private static final int C_BLUE = Color.rgb(48, 110, 210);
    private static final int C_PURP = Color.rgb(120, 80, 190);
    private static final int C_ORG = Color.rgb(200, 110, 20);
    private static final int C_GOLD = Color.rgb(180, 130, 20);
    private static final int C_GRN = Color.rgb(30, 140, 80);
    private static final int C_RED = Color.rgb(190, 55, 55);
    private static final int C_GRAY = Color.rgb(70, 70, 82);

    private TextView tv, logTv;
    private Button btn;
    private LinearLayout content;
    private ScrollView scroll;
    private LinearLayout[] panels = new LinearLayout[6];
    private Button[] tabBtns = new Button[6];
    private Button[] subBtns = new Button[4];
    private LinearLayout ctlBody;
    private int tabSel = 0, subSel = 0, lastLogVer = -1;
    private SharedPreferences cfg;
    private final ArrayList<CheckBox> mixBoxes = new ArrayList<>();
    private int mixSec = 10;
    private final Button[] secBtns = new Button[MIX_SECS.length];
    private EditText cmdEdit;
    private EditText mirIpEdit;
    private boolean mirFill = true;
    private int mirQ = 55;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable ui = new Runnable() {
        @Override public void run() {
            tv.setText("الخدمة: " + (sRunning ? "شغالة" : "واقفة") + "   |   البلوتوث: " + sBt
                    + "\nالموقع: " + sLoc + "   |   الاتجاه: " + sHdg + "   |   السرعة: " + sSpd
                    + "\nرادار: " + sRdrInfo + "\nنتائج: " + sScInfo + "\nطوارئ: " + sEmInfo + "\nكاميرات: " + sCamInfo + "\nآخر إرسال: " + sTx);
            btn.setText(sRunning ? "إيقاف" : "ابدأ");
            if (lastLogVer != sLogVer) {
                lastLogVer = sLogVer;
                StringBuilder sb = new StringBuilder();
                synchronized (sLog) {
                    for (int i = sLog.size() - 1; i >= 0; i--) sb.append(sLog.get(i)).append('\n');
                }
                logTv.setText(sb.length() == 0 ? "(ما في ردود لين الحين)" : sb.toString());
            }
            if (sWantList && sCamList != null) { sWantList = false; showCamList(sCamList); }
            h.postDelayed(this, 500);
        }
    };

    // ---------------- أدوات بناء الواجهة ----------------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Button mkBtn(String label, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(6), dp(4), dp(6), dp(4));
        paint(b, color);
        b.setOnClickListener(l);
        return b;
    }

    private void paint(Button b, int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(12));
        b.setBackground(gd);
    }

    private Button cmdBtn(String label, final String cmd, int color) {
        return mkBtn(label, color, new View.OnClickListener() {
            @Override public void onClick(View v) { send(cmd); }
        });
    }

    private void send(String cmd) {
        if (Bridge.sendCmd(cmd)) log("> " + cmd);
        else Toast.makeText(this, "الإطار مو متصل (شغّل الخدمة وانتظر 'متصل')", Toast.LENGTH_SHORT).show();
    }

    private TextView title(String t) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(15);
        x.setTypeface(Typeface.DEFAULT_BOLD);
        x.setTextColor(Color.rgb(255, 205, 90));
        x.setTextDirection(View.TEXT_DIRECTION_RTL);
        x.setPadding(dp(4), dp(14), dp(4), dp(4));
        return x;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    /** شبكة أزرار: كل عنصر {نص، أمر} */
    private LinearLayout grid(String[][] items, int cols, int color) {
        LinearLayout col = vbox();
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                col.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            row.addView(cmdBtn(items[i][0], items[i][1], color), lp);
        }
        int rem = items.length % cols;
        if (rem != 0 && row != null) {
            for (int k = rem; k < cols; k++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(54), 1f);
                row.addView(new View(this), lp);
            }
        }
        return col;
    }

    /** صف أزرار أرقام 1..n لأمر مثل "cmp 3" */
    private LinearLayout numGrid(String prefix, int n, int color) {
        String[][] it = new String[n][2];
        for (int i = 0; i < n; i++) { it[i][0] = String.valueOf(i + 1); it[i][1] = prefix + " " + (i + 1); }
        return grid(it, 5, color);
    }


    /** شبكة أزرار لإجراءات محلية بالتطبيق (مو أوامر للإطار) */
    private LinearLayout grid2(String[][] items, int cols, int color) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) { row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); col.addView(row); }
            final String act = items[i][1];
            Button b = mkBtn(items[i][0], color, new View.OnClickListener() { @Override public void onClick(View v) { mirrorAction(act); } });
            row.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        return col;
    }

    private void mirrorAction(String a) {
        if (a.equals("m:fill")) { mirFill = true; log("الميرور: ملء الدائرة"); }
        else if (a.equals("m:fit")) { mirFill = false; log("الميرور: الصورة كاملة"); }
        else if (a.equals("m:fast")) { mirQ = 40; log("الميرور: سريع"); }
        else if (a.equals("m:clear")) { mirQ = 75; log("الميرور: واضح"); }
        else if (a.equals("m:stop")) { stopService(new Intent(this, MirrorService.class)); send("mirror off"); log("الميرور وقف"); }
        else if (a.equals("m:start")) {
            String host = mirIpEdit != null ? mirIpEdit.getText().toString().trim() : "192.168.4.1";
            if (host.length() == 0) host = "192.168.4.1";
            cfg.edit().putString("mirIp", host).apply();
            send("mirror on");
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), 77);
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 77) return;
        if (res != RESULT_OK || data == null) { log("ما وافقت على التقاط الشاشة"); return; }
        Intent i = new Intent(this, MirrorService.class);
        i.putExtra("code", res);
        i.putExtra("data", data);
        i.putExtra("host", cfg.getString("mirIp", "192.168.4.1"));
        i.putExtra("fill", mirFill);
        i.putExtra("q", mirQ);
        startForegroundService(i);
        log("الميرور شغّال");
    }

    private void selectSub(int i) {
        subSel = i;
        for (int k = 0; k < 4; k++) paint(subBtns[k], k == i ? C_BLUE : C_GRAY);
        ctlBody.removeAllViews();
        if (i == 0) {
            ctlBody.addView(grid(new String[][] {
                    { "الصور", "photos" }, { "ساعة عقارب", "analog" }, { "ساعة رقمية", "digital" }, { "الطقس", "weather" } }, 2, C_BLUE));
        } else if (i == 1) {
            ctlBody.addView(grid(new String[][] {
                    { "العلي", "alali" }, { "يوسف", "yousef" }, { "الأسماء", "names" }, { "Yousef EN", "yousefen" },
                    { "Alali EN", "alalien" }, { "مكس EN", "mixen" }, { "مكس عربي/EN", "mixaren" }, { "يوسف عربي/EN", "ymix" }, { "Alali EN/عربي", "amix" }, { "الخدع", "hypno" },
                    { "القوائم", "list" } }, 2, C_PURP));
        } else if (i == 2) {
            ctlBody.addView(grid(new String[][] {
                    { "البوصلة", "compass" }, { "الرادار", "radar" }, { "النتائج", "scores" }, { "السرعة", "speed" },
                    { "رادار الكاميرات", "camrad" }, { "شكل الكاميرات التالي", "camrad next" },
                    { "لون الكاميرات", "camrad color" }, { "دوران الكاميرات شغّل/وقف", "camrad sweep" },
                    { "شكل البوصلة التالي", "cmp next" }, { "لون البوصلة", "cmp color" },
                    { "شكل السرعة التالي", "spd next" }, { "لون السرعة", "spd color" },
                    { "شكل الرادار التالي", "rdr next" }, { "لف الرادار شغّل/وقف", "rdr sweep" }, { "الدوريات", "sc" } }, 2, C_GOLD));
        } else {
            ctlBody.addView(grid(new String[][] {
                    { "ريست بلوتوث", "rbt" }, { "ريست واي فاي", "rwf" }, { "شغّل الميكس", "mix" }, { "وقّف الميكس", "mix off" },
                    { "حالة الإطار", "status" }, { "تشخيص الشبكة", "net" }, { "الشاشة شغّل/طفي", "screen" } }, 2, C_RED));
        }
    }

    private void selectTab(int i) {
        tabSel = i;
        for (int k = 0; k < 6; k++) paint(tabBtns[k], k == i ? C_BLUE : C_CARD);
        content.removeAllViews();
        content.addView(panels[i]);
        scroll.scrollTo(0, 0);
        if (i == 5) refreshMatches();
    }

    // ---------------- تبويب التحكم ----------------
    private LinearLayout buildControl() {
        LinearLayout p = vbox();
        p.addView(grid(new String[][] { { "◀ السابقة", "sprev" }, { "التالية ▶", "snext" },
                { "↩ رجوع (Back)", "back" }, { "⏎ دخول (Enter)", "enter" },
                { "⏸ إيقاف (تثبيت)", "pin" }, { "▶ استمرار", "unpin" } }, 2, C_GRAY));
        p.addView(grid(new String[][] { { "سطوع −", "bdn" }, { "سطوع +", "bup" }, { "ميكس", "mix" } }, 3, C_GRAY));
        LinearLayout sub = new LinearLayout(this);
        sub.setOrientation(LinearLayout.HORIZONTAL);
        String[] nm = { "SHOW", "NAMES", "TOOLS", "SYS" };
        for (int i = 0; i < 4; i++) {
            final int k = i;
            subBtns[i] = mkBtn(nm[i], C_GRAY, new View.OnClickListener() {
                @Override public void onClick(View v) { selectSub(k); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(dp(3), dp(10), dp(3), dp(6));
            sub.addView(subBtns[i], lp);
        }
        p.addView(sub);
        ctlBody = vbox();
        p.addView(ctlBody);
        selectSub(0);
        return p;
    }

    // ---------------- تبويب الميكس المخصص ----------------
    private boolean mixDefault(String name) { return MIX_DEF.contains("," + name + ","); }

    private LinearLayout buildMix() {
        LinearLayout p = vbox();
        TextView info = new TextView(this);
        info.setText("اختر الأوضاع اللي تدخل بالميكس، والمدة، وبعدها اضغط «طبّق على الإطار». "
                + "البوصلة والسرعة والرادار تطلع بس إذا الموقع واصل، والنتائج لما في مباراة شغالة.");
        info.setTextSize(13);
        info.setTextColor(Color.rgb(170, 170, 180));
        info.setTextDirection(View.TEXT_DIRECTION_RTL);
        p.addView(info);
        p.addView(title("الأوضاع"));
        mixBoxes.clear();
        for (int i = 0; i < MIXI.length; i++) {
            final String name = MIXI[i][0];
            CheckBox cb = new CheckBox(this);
            cb.setText(MIXI[i][1]);
            cb.setTextSize(16);
            cb.setTextColor(Color.WHITE);
            cb.setChecked(cfg.getBoolean("mix_" + name, mixDefault(name)));
            cb.setPadding(dp(6), dp(8), dp(6), dp(8));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    cfg.edit().putBoolean("mix_" + name, on).apply();
                }
            });
            mixBoxes.add(cb);
            p.addView(cb);
        }
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(smallBtn("الكل", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { for (CheckBox c : mixBoxes) c.setChecked(true); }
        }));
        quick.addView(smallBtn("مسح الكل", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) { for (CheckBox c : mixBoxes) c.setChecked(false); }
        }));
        quick.addView(smallBtn("الافتراضي", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                for (int i = 0; i < mixBoxes.size(); i++) mixBoxes.get(i).setChecked(mixDefault(MIXI[i][0]));
            }
        }));
        p.addView(quick);

        p.addView(title("مدة كل وضع (ثواني)"));
        mixSec = cfg.getInt("mixSec", 10);
        LinearLayout secs = new LinearLayout(this);
        secs.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < MIX_SECS.length; i++) {
            final int sec = MIX_SECS[i];
            secBtns[i] = smallBtn(String.valueOf(sec), sec == mixSec ? C_BLUE : C_GRAY, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    mixSec = sec;
                    cfg.edit().putInt("mixSec", sec).apply();
                    for (int k = 0; k < MIX_SECS.length; k++) paint(secBtns[k], MIX_SECS[k] == sec ? C_BLUE : C_GRAY);
                }
            });
            secs.addView(secBtns[i]);
        }
        p.addView(secs);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(dp(3), dp(18), dp(3), dp(4));
        p.addView(mkBtn("طبّق على الإطار", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) { applyMix(false); }
        }), lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        lp2.setMargins(dp(3), dp(4), dp(3), dp(4));
        p.addView(mkBtn("طبّق وشغّل الميكس", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) { applyMix(true); }
        }), lp2);
        return p;
    }

    private Button smallBtn(String t, int color, View.OnClickListener l) {
        Button b = mkBtn(t, color, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMargins(dp(3), dp(6), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private void applyMix(boolean start) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < mixBoxes.size(); i++) {
            if (mixBoxes.get(i).isChecked()) {
                if (sb.length() > 0) sb.append(',');
                sb.append(MIXI[i][0]);
            }
        }
        if (sb.length() == 0) {
            Toast.makeText(this, "اختر وضع واحد على الأقل", Toast.LENGTH_SHORT).show();
            return;
        }
        send("mixset " + sb);
        send("mixsec " + mixSec);
        if (start) send("mix");
    }

    // ---------------- تبويب الإعدادات ----------------
    static int lgMaskLoad(SharedPreferences cfg) { return cfg.contains("lgMask2") ? cfg.getInt("lgMask2", 255) : (cfg.getInt("lgMask", 63) | 192); }

    private LinearLayout buildSettings() {
        LinearLayout p = vbox();
        p.addView(title("الدوريات (يجلبها الجوال)"));
        for (int i = 0; i < Feeds.SLUG.length; i++) {
            final int li = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(Feeds.LG_AR[i]);
            cb.setTextSize(16);
            cb.setTextColor(Color.WHITE);
            cb.setChecked((sLgMask & (1 << i)) != 0);
            cb.setPadding(dp(6), dp(6), dp(6), dp(6));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    if (on) sLgMask |= (1 << li); else sLgMask &= ~(1 << li);
                    cfg.edit().putInt("lgMask2", sLgMask).apply();
                    send("lg " + (li + 1) + (on ? " on" : " off"));
                }
            });
            p.addView(cb);
        }
        p.addView(title("تنبيه طوارئ الطيران (يطلع لحاله على الإطار)"));
        LinearLayout emRow = new LinearLayout(this);
        emRow.setOrientation(LinearLayout.HORIZONTAL);
        final int[] emV = { 100, 250, 0 };
        String[] emT = { "100 كم", "250 كم", "إيقاف" };
        for (int i = 0; i < 3; i++) {
            final int v = emV[i];
            Button eb = mkBtn(emT[i], v == 0 ? C_GRAY : C_RED, new View.OnClickListener() {
                @Override public void onClick(View x) {
                    sEmKm = v;
                    cfg.edit().putInt("emKm", v).apply();
                    Toast.makeText(MainActivity.this, v == 0 ? "تنبيه الطوارئ متوقف" : "مدى الطوارئ " + v + " كم", Toast.LENGTH_SHORT).show();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            emRow.addView(eb, lp);
        }
        p.addView(emRow);
        p.addView(grid(new String[][] { { "طوارئ: طبي", "emtest 1" }, { "طوارئ: خطف", "emtest 2" }, { "طوارئ: عطل اتصال", "emtest 3" }, { "طوارئ: عامة", "emtest 4" }, { "تجربة بطاقة طيارة", "actest" } }, 2, C_GRAY));
        p.addView(title("تنبيه الهدف"));
        p.addView(grid(new String[][] { { "شغّل", "goal on" }, { "طفّي", "goal off" }, { "تجربة", "goal test" } }, 3, C_PURP));
        p.addView(title("بداية المباريات"));
        p.addView(grid(new String[][] { { "تجربة بداية مباراة", "kotest" }, { "تجربة 3 مباريات", "kotest 3" } }, 2, C_PURP));
        p.addView(title("ليفربول ❤"));
        p.addView(grid(new String[][] { { "تنبيهات ليفربول تتجاوز الكتم", "lfc on" }, { "إيقاف التجاوز", "lfc off" },
                { "تجربة هدف ليفربول", "lfctest 1" }, { "تجربة هدف على ليفربول", "lfctest 2" }, { "تجربة بداية ليفربول", "lfctest 3" } }, 2, C_PURP));
        p.addView(title("مدى الرادار (كم)"));
        LinearLayout rr = new LinearLayout(this);
        rr.setOrientation(LinearLayout.HORIZONTAL);
        int[] ranges = { 20, 40, 80, 150, 250 };
        for (int i = 0; i < ranges.length; i++) {
            final int km = ranges[i];
            rr.addView(smallBtn(String.valueOf(km), C_GOLD, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    sRange = km;
                    cfg.edit().putInt("range", km).apply();
                    send("rdr r " + km);
                }
            }));
        }
        p.addView(rr);
        p.addView(title("شكل الرادار (1-9 كلاسيك | 10-18 نقاط، مثلثات، طيارات)"));
        p.addView(numGrid("rdr", 18, C_GOLD));
        p.addView(grid(new String[][] { { "تلقائي", "rdr auto" }, { "لف شغّال", "rdr sweep on" }, { "لف متوقف", "rdr sweep off" } }, 3, C_GRAY));
        p.addView(title("شكل البوصلة (6 إلى 9 عربي)"));
        p.addView(numGrid("cmp", 9, C_BLUE));
        p.addView(grid(new String[][] { { "لون (للعربي 2 و5)", "cmp color" }, { "تلقائي", "cmp auto" } }, 2, C_GRAY));
        p.addView(title("شكل السرعة"));
        p.addView(numGrid("spd", 7, C_RED));
        p.addView(grid(new String[][] { { "لون (للشكل 5)", "spd color" }, { "تلقائي", "spd auto" }, { "صفّر MAX", "spd max" } }, 3, C_GRAY));
        p.addView(title("دوران الشاشة كلها"));
        p.addView(grid(new String[][] { { "عادي", "rot 0" }, { "90 يمين", "rot 90" }, { "مقلوب 180", "rot 180" }, { "90 يسار", "rot 270" }, { "التالي", "rot next" } }, 3, C_ORG));
        p.addView(title("الأسماء: كل شكل ثابت إله نسخة متحركة بنفس الخط"));
        p.addView(grid(new String[][] {
                { "العلي: التالي", "al next" }, { "العلي: متحرك", "al anim" }, { "العلي: ثابت", "al static" },
                { "يوسف: التالي", "ys next" }, { "يوسف: متحرك", "ys anim" }, { "يوسف: ثابت", "ys static" },
                { "Yousef: التالي", "ye next" }, { "Yousef: متحرك", "ye anim" }, { "Yousef: ثابت", "ye static" },
                { "Alali: التالي", "ae next" }, { "Alali: متحرك", "ae anim" }, { "Alali: ثابت", "ae static" } }, 3, C_PURP));
        p.addView(title("ميرور شاشة الجوال (واي فاي)"));
        mirIpEdit = new EditText(this);
        mirIpEdit.setHint("عنوان الإطار، مثل 192.168.4.1");
        mirIpEdit.setHintTextColor(Color.GRAY);
        mirIpEdit.setTextColor(Color.WHITE);
        mirIpEdit.setSingleLine(true);
        mirIpEdit.setText(cfg.getString("mirIp", "192.168.4.1"));
        p.addView(mirIpEdit);
        p.addView(grid2(new String[][] { { "شغّل الميرور", "m:start" }, { "وقّف الميرور", "m:stop" },
                { "ملء الدائرة", "m:fill" }, { "الصورة كاملة", "m:fit" }, { "سريع", "m:fast" }, { "واضح", "m:clear" } }, 2, C_BLUE));
        p.addView(title("رادار الكاميرات: الشكل (1 خريطة، 2 أمامك، 3 الطريق)"));
        p.addView(numGrid("camrad", 3, C_GOLD));
        p.addView(title("رادار الكاميرات: اللون"));
        p.addView(grid(new String[][] { { "أخضر", "camrad color 1" }, { "أزرق", "camrad color 2" }, { "بنفسجي", "camrad color 3" }, { "أبيض", "camrad color 4" } }, 4, C_GOLD));
        p.addView(title("رادار الكاميرات: الدوران والمدى"));
        p.addView(grid(new String[][] { { "دوران شغّال", "camrad sweep on" }, { "دوران متوقف", "camrad sweep off" },
                { "مدى 5 كم", "camrad range 5" }, { "مدى 10 كم", "camrad range 10" }, { "مدى 20 كم", "camrad range 20" } }, 3, C_GOLD));
        p.addView(title("الساعات والطقس"));
        p.addView(numGrid("ana", 6, C_BLUE));
        p.addView(grid(new String[][] { { "رقمي 1", "dig 1" }, { "رقمي 2", "dig 2" }, { "رقمي 3", "dig 3" } }, 3, C_BLUE));
        p.addView(numGrid("wx", 5, C_BLUE));
        return p;
    }

    // ---------------- تبويب المباريات (تنبيهات + تجاهل) ----------------
    private LinearLayout mtBox;
    static final java.util.concurrent.ConcurrentHashMap<Integer, ArrayList<String[]>> sMl = new java.util.concurrent.ConcurrentHashMap<>();

    private java.util.Set<String> mutedSet() {
        java.util.HashSet<String> r = new java.util.HashSet<>();
        String v = cfg.getString("muted", "");
        for (String t : v.split(",")) if (!t.isEmpty()) r.add(t);
        return r;
    }

    private LinearLayout buildMatches() {
        LinearLayout p = vbox();
        p.addView(title("تنبيهات المباريات (هدف، بداية، VAR، كرت أحمر)"));
        p.addView(grid(new String[][] { { "كل التنبيهات شغّالة", "malert on" }, { "كل التنبيهات متوقفة", "malert off" } }, 2, C_GRN));
        p.addView(grid(new String[][] { { "تجربة VAR", "vartest" }, { "تجربة كرت أحمر", "redtest" }, { "تجربة بداية", "kotest" }, { "تجربة هدف", "goal test" } }, 2, C_GRAY));
        p.addView(title("تجاهل دوري كامل"));
        for (int i = 0; i < Feeds.SLUG.length; i++) {
            final int li = i;
            CheckBox cb = new CheckBox(this);
            cb.setText("تجاهل " + Feeds.LG_AR[i]);
            cb.setTextSize(15);
            cb.setTextColor(Color.WHITE);
            cb.setChecked((cfg.getInt("lgMuteMask", 0) & (1 << i)) != 0);
            cb.setPadding(dp(6), dp(5), dp(6), dp(5));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    int m = cfg.getInt("lgMuteMask", 0);
                    m = on ? (m | (1 << li)) : (m & ~(1 << li));
                    cfg.edit().putInt("lgMuteMask", m).apply();
                    send("lgmute " + (li + 1) + (on ? " on" : " off"));
                }
            });
            p.addView(cb);
        }
        p.addView(title("تجاهل مباراة معينة"));
        p.addView(mkBtn("تحديث القائمة", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) { refreshMatches(); }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        mtBox = vbox();
        p.addView(mtBox);
        return p;
    }

    private void refreshMatches() {
        if (mtBox == null) return;
        mtBox.removeAllViews();
        final java.util.Set<String> mu = mutedSet();
        boolean any = false;
        for (int li = 0; li < Feeds.SLUG.length; li++) {
            ArrayList<String[]> l = sMl.get(li);
            if (l == null || l.isEmpty() || (sLgMask & (1 << li)) == 0) continue;
            any = true;
            mtBox.addView(title(Feeds.LG_AR[li]));
            for (final String[] m : l) {
                String st = "1".equals(m[7]) ? "🔴 " : "2".equals(m[7]) ? "✔ " : "";
                String sc = "0".equals(m[7]) ? m[8] : m[5] + "-" + m[6];
                CheckBox cb = new CheckBox(this);
                cb.setText("تجاهل  " + st + m[3] + " " + sc + " " + m[4]);
                cb.setTextSize(14);
                cb.setTextColor(Color.WHITE);
                cb.setChecked(mu.contains(m[0]));
                cb.setPadding(dp(6), dp(5), dp(6), dp(5));
                cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                        java.util.Set<String> cur = mutedSet();
                        if (on) cur.add(m[0]); else cur.remove(m[0]);
                        StringBuilder sb = new StringBuilder();
                        for (String t : cur) { if (sb.length() > 0) sb.append(','); sb.append(t); }
                        cfg.edit().putString("muted", sb.toString()).apply();
                        send((on ? "muteid " : "unmuteid ") + m[0]);
                    }
                });
                mtBox.addView(cb);
            }
        }
        if (!any) {
            TextView t = new TextView(this);
            t.setText("ما في مباريات محمّلة بعد. فعّل الدوريات من الإعدادات وانتظر الاتصال بالإطار.");
            t.setTextSize(13); t.setTextColor(Color.rgb(170, 170, 180));
            t.setTextDirection(View.TEXT_DIRECTION_RTL);
            mtBox.addView(t);
        }
    }

    // ---------------- تبويب الكاميرات ----------------
    private TextView camTv;

    private LinearLayout buildCams() {
        LinearLayout p = vbox();
        camTv = new TextView(this);
        camTv.setText("التنبيه يطلع على الإطار تلقائياً لما تقرب من كاميرا قدامك (بدون صوت). "
                + "اضغط على الشاشة أو زر «تجاهل» وتروح هذي الكاميرا بس.");
        camTv.setTextSize(13);
        camTv.setTextColor(Color.rgb(170, 170, 180));
        camTv.setTextDirection(View.TEXT_DIRECTION_RTL);
        p.addView(camTv);
        p.addView(title("علامات أنت حطيتها"));
        p.addView(grid(new String[][] { { "📍 علّم كاميرا هنا", "cmark" }, { "↩ إلغاء آخر علامة", "cundo" },
                { "تجاهل هذي الكاميرا", "camskip" }, { "تنبيه شغّال/متوقف", "cam" } }, 2, C_RED));
        p.addView(grid(new String[][] { { "تجربة التنبيه", "camtest sim" } }, 1, C_GRAY));
        p.addView(mkBtn("كاميراتي (اختر واحدة للحذف)", C_PURP, new View.OnClickListener() {
            @Override public void onClick(View v) { sCamList = null; sWantList = true; send("clist"); }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        p.addView(title("كاميرات OpenStreetMap"));
        p.addView(mkBtn("فحص: كم كاميرا حولي؟", C_BLUE, new View.OnClickListener() {
            @Override public void onClick(View v) {
                sCamInfo = "جاري الفحص...";
                sCamForce = true;
                Toast.makeText(MainActivity.this, "ينتظر الموقع ويجلب الكاميرات", Toast.LENGTH_SHORT).show();
            }
        }), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        TextView n2 = new TextView(this);
        n2.setText("التطبيق يجلب كاميرات OSM ضمن 25 كم ويرسلها للجهاز تلقائياً (وتتحدث لما تتحرك أو كل نص ساعة). "
                + "إذا الرقم قليل، التغطية ضعيفة، وعلّم كاميراتك بنفسك.");
        n2.setTextSize(12);
        n2.setTextColor(Color.rgb(150, 150, 160));
        n2.setTextDirection(View.TEXT_DIRECTION_RTL);
        n2.setPadding(dp(2), dp(6), dp(2), dp(6));
        p.addView(n2);
        return p;
    }

    private void showCamList(String reply) {
        // الرد: "cu 3 osm 120: 1:29.37590,47.97740 2:..."
        int c = reply.indexOf(':');
        String rest = c >= 0 ? reply.substring(c + 1).trim() : "";
        final ArrayList<String> ids = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        if (rest.length() > 0) {
            for (String t : rest.split(" ")) {
                int k = t.indexOf(':');
                if (k < 1) continue;
                ids.add(t.substring(0, k));
                labels.add("كاميرا " + t.substring(0, k) + "   " + t.substring(k + 1));
            }
        }
        if (ids.isEmpty()) { Toast.makeText(this, "ما عندك كاميرات معلّمة", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle("اختر كاميرا للحذف (آخر 6)")
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) { send("cdel " + ids.get(which)); }
                }).setNegativeButton("إلغاء", null).show();
    }

    // ---------------- تبويب الردود ----------------
    private LinearLayout buildLog() {
        LinearLayout p = vbox();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        cmdEdit = new EditText(this);
        cmdEdit.setHint("أمر مباشر مثل: status");
        cmdEdit.setHintTextColor(Color.GRAY);
        cmdEdit.setTextColor(Color.WHITE);
        cmdEdit.setSingleLine(true);
        cmdEdit.setInputType(InputType.TYPE_CLASS_TEXT);
        row.addView(cmdEdit, new LinearLayout.LayoutParams(0, dp(52), 1f));
        row.addView(smallBtn("إرسال", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String c = cmdEdit.getText().toString().trim();
                if (c.length() > 0) { send(c); cmdEdit.setText(""); }
            }
        }));
        row.addView(smallBtn("مسح", C_GRAY, new View.OnClickListener() {
            @Override public void onClick(View v) {
                synchronized (sLog) { sLog.clear(); }
                sLogVer++;
            }
        }));
        p.addView(row);
        logTv = new TextView(this);
        logTv.setTextSize(13);
        logTv.setTypeface(Typeface.MONOSPACE);
        logTv.setTextColor(Color.rgb(200, 230, 200));
        logTv.setPadding(dp(4), dp(10), dp(4), dp(10));
        p.addView(logTv);
        return p;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = getSharedPreferences("cfg", MODE_PRIVATE);
        sLgMask = lgMaskLoad(cfg);
        sEmKm = cfg.getInt("emKm", 250);
        sRange = cfg.getInt("range", 40);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(36), dp(12), dp(8));
        root.setBackgroundColor(C_BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView ttl = new TextView(this);
        ttl.setText("جسر الإطار");
        ttl.setTextSize(20);
        ttl.setTypeface(Typeface.DEFAULT_BOLD);
        ttl.setTextColor(Color.WHITE);
        top.addView(ttl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btn = mkBtn("ابدأ", C_GRN, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (sRunning) {
                    stopService(new Intent(MainActivity.this, Bridge.class));
                    sRunning = false;
                } else {
                    askAndStart();
                }
            }
        });
        top.addView(btn, new LinearLayout.LayoutParams(dp(110), dp(48)));
        root.addView(top);

        tv = new TextView(this);
        tv.setTextSize(12);
        tv.setLineSpacing(0, 1.25f);
        tv.setTextColor(Color.rgb(200, 200, 212));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        tv.setPadding(dp(2), dp(6), dp(2), dp(6));
        root.addView(tv);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = { "التحكم", "ميكس", "إعدادات", "كاميرات", "المباريات", "الردود" };
        for (int i = 0; i < 6; i++) {
            final int k = i;
            tabBtns[i] = mkBtn(tn[i], C_CARD, new View.OnClickListener() {
                @Override public void onClick(View v) { selectTab(k); }
            });
            tabBtns[i].setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            tabs.addView(tabBtns[i], lp);
        }
        root.addView(tabs);

        scroll = new ScrollView(this);
        content = vbox();
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        panels[0] = buildControl();
        panels[1] = buildMix();
        panels[2] = buildSettings();
        panels[3] = buildCams();
        panels[4] = buildMatches();
        panels[5] = buildLog();
        selectTab(0);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        lastLogVer = -1;
        h.post(ui);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(ui);
    }

    private void askAndStart() {
        ArrayList<String> need = new ArrayList<>();
        need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(Manifest.permission.BLUETOOTH_SCAN);
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        ArrayList<String> missing = new ArrayList<>();
        for (String p : need) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            startBridge();
        } else {
            requestPermissions(missing.toArray(new String[0]), 7);
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= 31) {
            ok = ok && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        if (ok) startBridge();
        else sBt = "لازم توافق على الأذونات";
    }

    private void startBridge() {
        Intent i = new Intent(this, Bridge.class);
        startForegroundService(i);
        sRunning = true;
    }

    // ------------------------------------------------------------------
    // الخدمة اللي تشتغل بالخلفية: موقع + اتجاه + بلوتوث + جلب الرادار والنتائج
    // ------------------------------------------------------------------
    @SuppressLint("MissingPermission")
    public static class Bridge extends Service {
        static final UUID NUS = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
        static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
        static final String CH = "gpsbridge";

        static volatile Bridge sInst = null;

        private final Handler h = new Handler(Looper.getMainLooper());
        private LocationManager lm;
        private SensorManager sm;
        private BluetoothAdapter ad;
        private BluetoothLeScanner scanner;
        private volatile BluetoothGatt gatt;
        private volatile BluetoothGattCharacteristic rx;
        private volatile boolean ready = false;
        private volatile boolean discStarted = false;
        private boolean scanning = false;
        private boolean started = false;
        private boolean dead = false;
        private PowerManager.WakeLock wl;

        private Location loc;
        private long locAt = 0;
        private float compass = -1f;

        // طابور الكتابة: سطر كل 40 مللي ثانية
        private final ArrayDeque<String> queue = new ArrayDeque<>();
        private boolean pumping = false;
        private int writeFails = 0;
        private int payload = 20;                  // أكبر سطر نقدر نرسله (MTU - 3)

        // جلب البيانات من الإنترنت
        private final ExecutorService ex = Executors.newSingleThreadExecutor();
        private volatile boolean fetching = false;
        private long radarAt = 0;
        private long camAt = 0;
        private double camLat = 0, camLon = 0;
        private volatile boolean camBusy = false;
        private String lastCamHash = "";
        private final ArrayDeque<String> camLines = new ArrayDeque<>();
        private final long[] lgAt = new long[8];
        private final int[] lgLive = new int[8];   // 0 عادي، 1 قرّب يبدأ، 2 شغّالة

        static boolean sendCmd(String c) {
            final Bridge b = sInst;
            if (b == null || !b.ready) return false;
            final String cc = c;
            b.h.post(new Runnable() { @Override public void run() { b.enqueue(cc, false); } });
            return true;
        }

        @Override public IBinder onBind(Intent i) { return null; }

        @Override public int onStartCommand(Intent in, int flags, int id) {
            if (!started) {
                started = true;
                dead = false;
                sInst = this;
                goForeground();
                initAll();
            }
            return START_STICKY;
        }

        private void goForeground() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    CH, "جسر الموقع", NotificationManager.IMPORTANCE_LOW));
            Intent open = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH)
                    .setContentTitle("جسر الإطار شغال")
                    .setContentText("يرسل الموقع والرادار والنتائج للإطار")
                    .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            } else {
                startForeground(1, n);
            }
        }

        private void initAll() {
            SharedPreferences cfg = getSharedPreferences("cfg", MODE_PRIVATE);
            sLgMask = lgMaskLoad(cfg);
            sRange = cfg.getInt("range", 40);

            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gpsbridge:wl");
            wl.acquire();

            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            try {
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0,
                            ll, Looper.getMainLooper());
                } else {
                    sLoc = "شغّل الموقع GPS";
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0,
                            ll, Looper.getMainLooper());
                }
            } catch (Exception e) {
                sLoc = "خطأ: " + e.getMessage();
            }

            sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (rv != null) {
                sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
            } else {
                sHdg = "ما في حساس اتجاه";
            }

            BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
            ad = bm.getAdapter();
            if (ad == null || !ad.isEnabled()) {
                sBt = "شغّل البلوتوث";
            }
            startScan();
            h.postDelayed(tick, 1000);
        }

        // ---------------- الموقع ----------------
        private final LocationListener ll = new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                // نفضّل GPS على الشبكة إذا كان GPS حديث
                if (loc != null && LocationManager.GPS_PROVIDER.equals(loc.getProvider())
                        && !LocationManager.GPS_PROVIDER.equals(l.getProvider())
                        && System.currentTimeMillis() - locAt < 5000) {
                    return;
                }
                loc = l;
                locAt = System.currentTimeMillis();
                sLoc = String.format(Locale.US, "%.4f , %.4f", l.getLatitude(), l.getLongitude());
                pushGps(l);                                  // نرسل فور وصول القراءة (بدون ما ننتظر مؤقت الثانية)
            }
            @Override public void onStatusChanged(String p, int s, Bundle e) { }
            @Override public void onProviderEnabled(String p) { }
            @Override public void onProviderDisabled(String p) { }
        };

        // ---------------- البوصلة ----------------
        private final SensorEventListener sl = new SensorEventListener() {
            final float[] R = new float[9];
            final float[] R2 = new float[9];
            final float[] o = new float[3];
            float sx = 0f, sy = 0f;
            boolean has = false;

            @Override public void onSensorChanged(SensorEvent e) {
                SensorManager.getRotationMatrixFromVector(R, e.values);
                float[] use = R;
                // الجوال واقف (مثبت بالسيارة): نستخدم اتجاه الكاميرا الخلفية
                if (Math.abs(R[8]) < 0.7f) {
                    SensorManager.remapCoordinateSystem(R, SensorManager.AXIS_X,
                            SensorManager.AXIS_Z, R2);
                    use = R2;
                }
                SensorManager.getOrientation(use, o);
                double az = Math.toDegrees(o[0]);
                if (loc != null) {
                    GeomagneticField g = new GeomagneticField((float) loc.getLatitude(),
                            (float) loc.getLongitude(), (float) loc.getAltitude(),
                            System.currentTimeMillis());
                    az += g.getDeclination();
                }
                double r = Math.toRadians(az);
                float cx = (float) Math.cos(r), cy = (float) Math.sin(r);
                if (!has) { sx = cx; sy = cy; has = true; }
                else { sx = sx * 0.85f + cx * 0.15f; sy = sy * 0.85f + cy * 0.15f; }
                compass = (float) ((Math.toDegrees(Math.atan2(sy, sx)) + 360.0) % 360.0);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) { }
        };

        // ---------------- البلوتوث ----------------
        private void startScan() {
            if (dead) return;
            try {
                if (ad == null || !ad.isEnabled()) {
                    sBt = "شغّل البلوتوث";
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                scanner = ad.getBluetoothLeScanner();
                if (scanner == null) {
                    h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 4000);
                    return;
                }
                if (scanning) return;
                scanning = true;
                sBt = "يدور على الإطار...";
                scanner.startScan(scb);
            } catch (Exception e) {
                scanning = false;
                sBt = "خطأ بحث: " + e.getMessage();
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        }

        private void stopScan() {
            try {
                if (scanning && scanner != null) scanner.stopScan(scb);
            } catch (Exception ignored) { }
            scanning = false;
        }

        private final ScanCallback scb = new ScanCallback() {
            @Override public void onScanResult(int type, ScanResult r) {
                if (gatt != null || dead) return;
                String n = null;
                ScanRecord sr = r.getScanRecord();
                if (sr != null) n = sr.getDeviceName();
                if (n == null) n = r.getDevice().getName();
                if (n != null && n.startsWith("Photo")) {
                    stopScan();
                    sBt = "يتصل...";
                    discStarted = false;
                    gatt = r.getDevice().connectGatt(Bridge.this, false, cb,
                            BluetoothDevice.TRANSPORT_LE);
                }
            }
            @Override public void onScanFailed(int err) {
                scanning = false;
                sBt = "فشل البحث (" + err + ")";
                h.postDelayed(new Runnable() { @Override public void run() { startScan(); } }, 5000);
            }
        };

        private void startDiscovery(BluetoothGatt g) {
            if (discStarted) return;
            discStarted = true;
            g.discoverServices();
        }

        private void markReady() {
            if (ready) return;
            ready = true;
            sBt = "متصل";
            radarAt = 0;                                   // أول ما نتصل نجيب البيانات فوراً
            for (int i = 0; i < lgAt.length; i++) lgAt[i] = 0;
            log("— اتصل بالإطار —");
        }

        private final BluetoothGattCallback cb = new BluetoothGattCallback() {
            @Override public void onConnectionStateChange(final BluetoothGatt g, int status, int ns) {
                if (ns == BluetoothGatt.STATE_CONNECTED) {
                    sBt = "متصل (يجهز)";
                    if (!g.requestMtu(185)) startDiscovery(g);
                    h.postDelayed(new Runnable() {
                        @Override public void run() { startDiscovery(g); }
                    }, 2500);
                } else {
                    ready = false;
                    rx = null;
                    gatt = null;
                    queue.clear();
                    pumping = false;
                    try { g.close(); } catch (Exception ignored) { }
                    sBt = "انقطع، يعيد المحاولة";
                    if (!dead) {
                        h.postDelayed(new Runnable() {
                            @Override public void run() { startScan(); }
                        }, 3000);
                    }
                }
            }

            @Override public void onMtuChanged(BluetoothGatt g, int mtu, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS && mtu > 23) payload = mtu - 3;
                startDiscovery(g);
            }

            @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
                BluetoothGattService s = g.getService(NUS);
                BluetoothGattCharacteristic c = (s == null) ? null : s.getCharacteristic(RX);
                if (c == null) {
                    sBt = "خدمة الإطار مو موجودة";
                    g.disconnect();
                    return;
                }
                c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                rx = c;
                // نشترك بردود الإطار (TX) عشان تطلع بتبويب الردود
                boolean waiting = false;
                try {
                    BluetoothGattCharacteristic t = s.getCharacteristic(TX);
                    if (t != null) {
                        g.setCharacteristicNotification(t, true);
                        BluetoothGattDescriptor d = t.getDescriptor(CCCD);
                        if (d != null) {
                            d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            waiting = g.writeDescriptor(d);
                        }
                    }
                } catch (Exception ignored) { }
                if (waiting) {
                    h.postDelayed(new Runnable() { @Override public void run() { markReady(); } }, 1500);
                } else {
                    markReady();
                }
            }

            @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
                markReady();
            }

            @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
                try {
                    byte[] v = c.getValue();
                    if (v == null) return;
                    String t = new String(v, StandardCharsets.UTF_8).trim();
                    if (t.startsWith("cu ")) sCamList = t;
                    if (t.startsWith("mreq ")) sendDetails(t);
                    if (t.length() > 0) log("< " + t);
                } catch (Exception ignored) { }
            }
        };

        // ---------------- طابور الكتابة ----------------
        private void enqueue(String line, boolean front) {
            if (!ready) return;
            if (queue.size() > 160) return;
            String l = line;
            if (l.length() > payload) {                    // أطول من الحزمة: ما نرسله مقطوع (يخرب الأمر)
                if (!l.startsWith("rp ") && !l.startsWith("sm ")) log("! الأمر أطول من حجم الحزمة (" + payload + ")");
                return;
            }
            if (front) queue.addFirst(l); else queue.addLast(l);
            if (!pumping) {
                pumping = true;
                h.post(pump);
            }
        }

        private boolean writeLine(BluetoothGatt g, BluetoothGattCharacteristic c, String line) {
            byte[] b = line.getBytes(StandardCharsets.US_ASCII);
            if (Build.VERSION.SDK_INT >= 33) {
                return g.writeCharacteristic(c, b, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) == 0;
            }
            c.setValue(b);
            return g.writeCharacteristic(c);
        }

        private final Runnable pump = new Runnable() {
            @Override public void run() {
                BluetoothGatt g = gatt;
                BluetoothGattCharacteristic c = rx;
                if (!ready || g == null || c == null) { queue.clear(); pumping = false; return; }
                String line = queue.pollFirst();
                if (line == null) { pumping = false; return; }
                boolean ok = false;
                try { ok = writeLine(g, c, line); } catch (Exception ignored) { }
                if (!ok && ++writeFails < 20) {
                    queue.addFirst(line);                  // الخط مشغول: نعيد بعد شوي
                    h.postDelayed(this, 80);
                    return;
                }
                writeFails = 0;
                h.postDelayed(this, 40);
            }
        };

        // ---------------- جلب الرادار والنتائج ----------------
        private void startFetch(final boolean radar, final int li, final double lat, final double lon, final int range) {
            fetching = true;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> lines;
                        int live = 0;
                        if (radar) {
                            List<String> rl = Feeds.radar(lat, lon, range);
                            ArrayList<String> all = new ArrayList<>(rl);
                            all.addAll(Feeds.routes());                       // من وين لوين (بدون ما نوقف الرادار إذا فشل)
                            lines = all;
                            sRdrInfo = (lines.size() == 1 && lines.get(0).equals("rp 0 0") ? 0 : countRp(lines))
                                    + " طيارة | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        } else {
                            Feeds.Scores sc = Feeds.scores(li);
                            lines = sc.lines;
                            live = sc.live ? 2 : sc.soon ? 1 : 0;
                            sMl.put(li, sc.ms);
                            sScInfo = Feeds.LG_AR[li] + ": " + (lines.size() == 1 && lines.get(0).endsWith(" 0 0") ? 0 : lines.size())
                                    + " مباراة | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        }
                        if (!radar) lgLive[li] = live;
                        h.post(new Runnable() {
                            @Override public void run() {
                                for (String l : lines) enqueue(l, false);
                            }
                        });
                    } catch (Exception e) {
                        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        if (radar) sRdrInfo = "خطأ: " + m; else sScInfo = "خطأ: " + m;
                    } finally {
                        fetching = false;
                    }
                }
            });
        }

        // الإطار طلب تفاصيل مباراة: mreq <li> <id>
        private volatile boolean detBusy = false;
        private void sendDetails(String t) {
            if (detBusy) return;
            String[] p = t.split(" ");
            if (p.length < 3) return;
            final int li; try { li = Integer.parseInt(p[1]); } catch (Exception e) { return; }
            if (li < 0 || li >= Feeds.SLUG.length) return;
            final String id = Feeds.clean(p[2], 11);
            detBusy = true;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> ls = Feeds.details(li, id, payload);
                        h.post(new Runnable() { @Override public void run() { for (String l : ls) enqueue(l, true); } });
                    } catch (Exception e) {
                        log("! تفاصيل المباراة: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
                    } finally { detBusy = false; }
                }
            });
        }

        private int countRp(List<String> l) { int c = 0; for (String x : l) if (x.startsWith("rp ")) c++; return c; }

        private volatile boolean emBusy = false;
        private long emAt = 0;

        // فحص الطوارئ بمدى واسع (كل 30 ثانية) ويرسل للإطار فقط إذا في طيارة بحالة طوارئ
        private void emStep() {
            if (!ready || emBusy || sEmKm <= 0 || queue.size() > 20) return;
            long now = SystemClock.elapsedRealtime();
            Location l = loc;
            if (l == null || System.currentTimeMillis() - locAt > 60000 || (emAt != 0 && now - emAt < 30000)) return;
            emAt = now;
            emBusy = true;
            final double la = l.getLatitude(), lo = l.getLongitude();
            final int km = sEmKm;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        final List<String> lines = Feeds.emergencies(la, lo, km);
                        if (!lines.isEmpty()) sEmInfo = lines.size() + " طوارئ | " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
                        h.post(new Runnable() { @Override public void run() { for (String x : lines) enqueue(x, true); } });
                    } catch (Exception ignored) {
                    } finally { emBusy = false; }
                }
            });
        }

        private void feedStep() {
            if (!ready || fetching || payload < 100 || queue.size() > 30) return;
            long now = SystemClock.elapsedRealtime();
            Location l = loc;
            if (l != null && System.currentTimeMillis() - locAt < 60000 && (radarAt == 0 || now - radarAt >= 15000)) {
                radarAt = now;
                startFetch(true, 0, l.getLatitude(), l.getLongitude(), sRange);
                return;
            }
            for (int li = 0; li < Feeds.SLUG.length; li++) {
                if ((sLgMask & (1 << li)) == 0) continue;
                long every = lgLive[li] == 2 ? 5000 : lgLive[li] == 1 ? 20000 : 120000;   // شغّالة 5 ثواني، قرّبت 20، غيرها دقيقتين
                if (lgAt[li] == 0 || now - lgAt[li] >= every) {
                    lgAt[li] = now;
                    startFetch(false, li, 0, 0, 0);
                    return;
                }
            }
        }

        // ---------------- كاميرات OSM ----------------
        private void camStep() {
            // نفرّغ أسطر الكاميرات للطابور بالتدريج (ما نزحم الأوامر الثانية)
            if (ready && !camLines.isEmpty() && queue.size() < 12) {
                for (int i = 0; i < 6 && !camLines.isEmpty(); i++) enqueue(camLines.pollFirst(), false);
            }
            if (camBusy) return;
            Location l = loc;
            if (l == null || System.currentTimeMillis() - locAt > 60000) return;
            long now = SystemClock.elapsedRealtime();
            boolean force = sCamForce;
            boolean moved = false;
            if (camAt != 0) {
                float[] r = new float[1];
                Location.distanceBetween(camLat, camLon, l.getLatitude(), l.getLongitude(), r);
                moved = r[0] > 6000;
            }
            if (!force && !(ready && (camAt == 0 || moved || now - camAt >= 30 * 60 * 1000L))) return;
            if (!force && payload < 100) return;
            sCamForce = false;
            camBusy = true;
            camAt = now;
            camLat = l.getLatitude(); camLon = l.getLongitude();
            final double la = camLat, lo = camLon;
            final boolean fc = force;
            ex.submit(new Runnable() {
                @Override public void run() {
                    try {
                        List<int[]> base;
                        try { base = Feeds.bundled(getAssets().open("kw_cams.csv")); } catch (Exception e) { base = new ArrayList<>(); }
                        List<int[]> osm;
                        String osmErr = "";
                        try { osm = Feeds.cameras(la, lo, 25000); }
                        catch (Exception e) { osm = new ArrayList<>(); osmErr = " | OSM ما رد"; }
                        List<int[]> cams = Feeds.mergeCams(base, osm, la, lo, 2900);
                        int near5 = 0;
                        for (int[] c : cams) if (c[2] <= 5000) near5++;
                        String stamp = new java.text.SimpleDateFormat("HH:mm", Locale.US).format(new java.util.Date());
                        sCamInfo = cams.size() + " كاميرا (" + base.size() + " جاهزة + " + osm.size() + " OSM، " + near5 + " ضمن 5 كم) | " + stamp
                                + osmErr + (cams.isEmpty() ? " | علّم كاميراتك" : "");
                        StringBuilder hs = new StringBuilder();
                        for (int[] c : cams) hs.append(c[0]).append(',').append(c[1]).append(' ');
                        final String hash = cams.size() + ":" + hs.toString().hashCode();
                        if (!fc && hash.equals(lastCamHash)) return;           // نفس القائمة: ما نكتب بذاكرة الجهاز
                        final ArrayList<String> lines = new ArrayList<>();
                        lines.add("cclr");
                        int max = Math.max(40, payload - 6);
                        StringBuilder cur = new StringBuilder();
                        for (int[] c : cams) {
                            String t = c[0] + "," + c[1];
                            if (cur.length() + t.length() + 1 > max) { lines.add("cadd " + cur.toString().trim()); cur.setLength(0); }
                            cur.append(t).append(' ');
                        }
                        if (cur.length() > 0) lines.add("cadd " + cur.toString().trim());
                        lines.add("csave");
                        lastCamHash = hash;
                        h.post(new Runnable() {
                            @Override public void run() { camLines.clear(); camLines.addAll(lines); }
                        });
                    } catch (Exception e) {
                        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                        sCamInfo = "خطأ: " + m;
                        camAt = SystemClock.elapsedRealtime() - (30 * 60 * 1000L - 60000);   // نعيد بعد دقيقة
                    } finally {
                        camBusy = false;
                    }
                }
            });
        }

        private long lastGpsTx = 0;
        /** يرسل قراءة GPS للإطار: سرعة واتجاه من نفس القراءة */
        private void pushGps(Location l) {
            try {
                if (!ready || l == null) return;
                float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                int hdg = -1;
                if (kmh >= 7f && l.hasBearing()) hdg = Math.round(l.getBearing()) % 360;
                else if (compass >= 0f) hdg = Math.round(compass) % 360;
                String line = String.format(Locale.US, "gps %.5f %.5f %d %d",
                        l.getLatitude(), l.getLongitude(), hdg, Math.round(kmh));
                if (queue.size() < 40) enqueue(line, true);
                lastGpsTx = SystemClock.elapsedRealtime();
                sTx = new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
            } catch (Exception ignored) { }
        }

        // ---------------- الإرسال كل ثانية ----------------
        private final Runnable tick = new Runnable() {
            @Override public void run() {
                try {
                    Location l = loc;
                    long age = System.currentTimeMillis() - locAt;
                    if (l != null) {
                        float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
                        int hdg = -1;
                        if (kmh >= 7f && l.hasBearing()) hdg = Math.round(l.getBearing()) % 360;
                        else if (compass >= 0f) hdg = Math.round(compass) % 360;
                        sHdg = hdg < 0 ? "-" : hdg + "°";
                        sSpd = Math.round(kmh) + " km/h";
                        if (age > 15000) sLoc = "الموقع قديم، انتظر GPS";
                        if (ready && age < 15000 && SystemClock.elapsedRealtime() - lastGpsTx > 1500) pushGps(l);   // احتياط إذا ما وصلت قراءة جديدة
                    } else if (!sLoc.startsWith("شغّل") && !sLoc.startsWith("خطأ")) {
                        sLoc = "ينتظر إشارة GPS...";
                    }
                    camStep();
                    feedStep();
                    emStep();
                } catch (Exception ignored) { }
                if (!dead) h.postDelayed(this, 1000);
            }
        };

        @Override public void onDestroy() {
            dead = true;
            started = false;
            sInst = null;
            h.removeCallbacksAndMessages(null);
            try { ex.shutdownNow(); } catch (Exception ignored) { }
            try { lm.removeUpdates(ll); } catch (Exception ignored) { }
            try { sm.unregisterListener(sl); } catch (Exception ignored) { }
            stopScan();
            try {
                BluetoothGatt g = gatt;
                if (g != null) { g.disconnect(); g.close(); }
            } catch (Exception ignored) { }
            gatt = null;
            ready = false;
            try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
            sRunning = false;
            sBt = "غير متصل";
            super.onDestroy();
        }
    }
}
