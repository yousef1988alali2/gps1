package com.yousef.gpsbridge;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;

/** ملفات الإطار: قراءة القائمة من ردود البلوتوث، وتحويل الصور والفيديو لصيغة الإطار (466x466، JPG / MJP1). */
final class FileMgr {
    private FileMgr() { }

    static final int S = 466, FPS = 15;
    interface Progress { void on(String msg, int pct); }

    // ---- قائمة الملفات (تتحدث من ردود الإطار) ----
    static final ArrayList<String[]> list = new ArrayList<>();      // {name, size, video(0/1)}
    static volatile long total = 0, used = 0;
    static volatile boolean done = false;
    static volatile int delOk = 0, delErr = 0;

    static synchronized void onLine(String t) {
        if (t.startsWith("FLH ")) {
            String[] p = t.split(" ");
            list.clear(); done = false;
            try { total = Long.parseLong(p[1]); used = Long.parseLong(p[2]); } catch (Exception ignored) { }
        } else if (t.startsWith("FLI ")) {
            String[] p = t.split(" ");
            if (p.length >= 4) list.add(new String[] { p[1], p[2], p[3] });
        } else if (t.equals("FLE")) {
            done = true;
        } else if (t.startsWith("FDEL OK")) delOk++;
        else if (t.startsWith("FDEL ERR")) delErr++;
    }
    static synchronized ArrayList<String[]> snapshot() { return new ArrayList<>(list); }

    static String fmt(long b) { return b >= 1048576 ? String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0) : (b / 1024) + " KB"; }

    // ---- صورة: JPG 466x466 (قص من الوسط) ----
    private static Bitmap cover(Bitmap src) {
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(0xFF000000);
        float sc = Math.max((float) S / src.getWidth(), (float) S / src.getHeight());
        float w = src.getWidth() * sc, h = src.getHeight() * sc;
        Matrix m = new Matrix();
        m.postScale(sc, sc);
        m.postTranslate((S - w) / 2f, (S - h) / 2f);
        c.drawBitmap(src, m, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        return out;
    }

    private static byte[] jpg(Bitmap b, int q) {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(60 * 1024);
        b.compress(Bitmap.CompressFormat.JPEG, q, bo);
        return bo.toByteArray();
    }

    static File photoToJpg(Context ctx, Uri u, File outDir) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = cr.openInputStream(u);
        try { BitmapFactory.decodeStream(in, null, o); } finally { if (in != null) in.close(); }
        int ss = 1;
        while (o.outWidth / (ss * 2) >= S * 2 && o.outHeight / (ss * 2) >= S * 2) ss *= 2;
        o = new BitmapFactory.Options(); o.inSampleSize = ss;
        Bitmap bmp;
        in = cr.openInputStream(u);
        try { bmp = BitmapFactory.decodeStream(in, null, o); } finally { if (in != null) in.close(); }
        if (bmp == null) throw new IOException("ما قدرت أفتح الصورة");
        int rot = 0;
        try {
            in = cr.openInputStream(u);
            try {
                int ori = new android.media.ExifInterface(in).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = ori == 6 ? 90 : ori == 3 ? 180 : ori == 8 ? 270 : 0;
            } finally { if (in != null) in.close(); }
        } catch (Exception ignored) { }
        if (rot != 0) { Matrix m = new Matrix(); m.postRotate(rot); Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true); bmp.recycle(); bmp = r; }
        Bitmap c = cover(bmp); bmp.recycle();
        byte[] data = jpg(c, 90); c.recycle();
        File f = new File(outDir, "up.jpg");
        FileOutputStream fo = new FileOutputStream(f);
        try { fo.write(data); } finally { fo.close(); }
        return f;
    }

    // ---- فيديو: MJP1 (12 بايت: "MJP1"، fps، 3 أصفار، عدد الإطارات) ثم [طول 4 بايت][JPEG] لكل إطار ----
    static File videoToMjp(Context ctx, Uri u, int maxSec, int quality, long freeBytes, File outDir, Progress pr) throws IOException {
        MediaMetadataRetriever mr = new MediaMetadataRetriever();
        File f = new File(outDir, "up.mjp");
        RandomAccessFile raf = null;
        try {
            mr.setDataSource(ctx, u);
            long durMs = 0;
            try { durMs = Long.parseLong(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)); } catch (Exception ignored) { }
            if (durMs <= 0) throw new IOException("ما قدرت أقرأ مدة الفيديو");
            long useMs = maxSec > 0 ? Math.min(durMs, maxSec * 1000L) : durMs;
            int n = (int) (useMs * FPS / 1000);
            if (n < 1) throw new IOException("الفيديو قصير جداً");
            raf = new RandomAccessFile(f, "rw");
            raf.setLength(0);
            byte[] hdr = new byte[12];
            hdr[0] = 'M'; hdr[1] = 'J'; hdr[2] = 'P'; hdr[3] = '1'; hdr[4] = (byte) FPS;
            raf.write(hdr);
            long bytes = 12; int written = 0;
            for (int i = 0; i < n; i++) {
                Bitmap fr = mr.getFrameAtTime(i * 1000000L / FPS, MediaMetadataRetriever.OPTION_CLOSEST);
                if (fr == null) { if (written == 0) continue; else break; }
                Bitmap c = cover(fr); fr.recycle();
                byte[] d = jpg(c, quality); c.recycle();
                byte[] L = { (byte) d.length, (byte) (d.length >> 8), (byte) (d.length >> 16), (byte) (d.length >> 24) };
                raf.write(L); raf.write(d);
                bytes += 4 + d.length; written++;
                if (freeBytes > 0 && bytes > freeBytes - 65536) throw new IOException("المساحة ما تكفي، قلّل المدة أو احذف ملفات");
                if (pr != null && i % 3 == 0) pr.on("تحويل الفيديو " + (i * 100 / n) + "% (" + fmt(bytes) + ")", i * 100 / n);
            }
            if (written == 0) throw new IOException("جوالك ما يقدر يفتح هذا الفيديو. جرّب فيديو بصيغة MP4");
            raf.seek(8);
            raf.write(new byte[] { (byte) written, (byte) (written >> 8), (byte) (written >> 16), (byte) (written >> 24) });
        } finally {
            try { if (raf != null) raf.close(); } catch (Exception ignored) { }
            try { mr.release(); } catch (Exception ignored) { }
        }
        return f;
    }
}
