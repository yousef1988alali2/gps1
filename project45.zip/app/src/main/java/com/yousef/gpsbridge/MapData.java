package com.yousef.gpsbridge;

import android.util.JsonReader;
import android.util.JsonToken;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** خرائط الطرق من OpenStreetMap: تنزيل بخلايا 0.1 درجة وتخزين بالجوال، وتجهيز أوامر الإرسال للإطار. */
final class MapData {
    private MapData() { }

    /** ترتيب المعالم لازم يطابق مجسمات الإطار (pfx_lm.h): مفتاح، اسم إنجليزي (regex)، اسم عربي (regex) */
    static final String[][] LMS = {
        { "kt", "Kuwait Towers", "أبراج الكويت" },
        { "hm", "Al[ -]Hamra Tower|Hamra Tower", "برج الحمراء" },
        { "lt", "Liberation Tower", "برج التحرير" },
        { "bx", "Boursa Kuwait|Kuwait Stock Exchange", "بورصة الكويت" },
        { "ar", "Arraya", "برج الراية" },
        { "gm", "Kuwait Grand Mosque|Grand Mosque", "المسجد الكبير" },
        { "sp", "Seif Palace|Sief Palace", "قصر السيف" },
        { "by", "Bayan Palace", "قصر بيان" },
        { "mb", "Mubarakiya|Mubarakiyah", "المباركية" },
        { "av", "The Avenues|Avenues Mall", "الأفنيوز|الأفنيو" },
        { "m3", "360 Mall", "360 مول|مول 360" },
        { "mm", "Marina Mall", "مارينا مول" },
        { "sc", "Scientific Center", "المركز العلمي" },
        { "jc", "Jaber Al[ -]Ahmad Cultural|Sheikh Jaber Al[ -]Ahmad Cultural", "مركز جابر الأحمد الثقافي" },
        { "sh", "Al[ -]Shaheed Park|Shaheed Park", "حديقة الشهيد" },
        { "jb", "Jaber Causeway|Jaber Al[ -]Ahmad Al[ -]Sabah Causeway|Jaber Bridge", "جسر الشيخ جابر|جسر جابر" },
        { "ap", "Kuwait International Airport", "مطار الكويت الدولي" },
        { "ck", "Clock Tower", "برج الساعة" },
        { "kc", "Khiran Resort|Khiran Chalets", "شاليهات الخيران" },
        { "km", "Khiran Mall", "الخيران مول" },
        { "ss", "Souq Sharq|Souk Sharq", "سوق شرق" },
        { "mc", "Marina Crescent", "مارينا كريسنت" },
        { "gi", "Green Island", "الجزيرة الخضراء" },
        { "ec", "Entertainment City", "مدينة الكويت للملاهي|مدينة الملاهي" },
        { "rf", "Red Fort|Red Palace", "القصر الأحمر" },
        { "ak", "Al[ -]Kout Mall", "الكوت مول" },
        { "fw", "Fahaheel Waterfront|Al[ -]Kout Beach", "واجهة الفحيحيل" },
        { "ms", "Messilah Beach|Messila Beach", "شاطئ المسيلة" },
        { "mf", "Mishref Fairground|Kuwait International Fair|Mishref Exhibition", "أرض المعارض" },
        { "mi", "Ministry of Information", "وزارة الإعلام" },
        { "jz", "Jal Az[ -]Zor|Jal Al[ -]Zor", "جال الزور" },
        { "mt", "Mutla Ridge|Mutla'a Ridge", "تل المطلاع|الجرف المطلى" },
        { "ah", "Ahmadi Hill", "تل الأحمدي" },
        { "ab", "Sabah Al[ -]Salem Stadium|Al[ -]Arabi.*Stadium", "ملعب نادي العربي|استاد صباح السالم" },
        { "qs", "Mohammed Al[ -]Hamad Stadium|Al[ -]Qadsia.*Stadium|Qadsia.*Stadium", "ملعب نادي القادسية|استاد محمد الحمد" },
        { "js", "Jaber Al[ -]Ahmad International Stadium|Jaber.*Stadium", "استاد جابر الأحمد الدولي|استاد جابر" },
    };

    static final String[] SERVERS = {
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    };
    private static final String UA = "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    static final class Way { long id; int cls; String name = "", ref = ""; int[] la, lo; }
    static final class Place { String name; int la, lo; }
    static final class Cell { final ArrayList<Way> ways = new ArrayList<>(); final ArrayList<Place> places = new ArrayList<>(); }

    interface Prog { void p(String s); }

    // ---------------- ملفات الخلايا ----------------
    static File dir(File base) { File d = new File(base, "map"); if (!d.exists()) d.mkdirs(); return d; }
    static File cellFile(File base, int ci, int cj) { return new File(dir(base), "c_" + ci + "_" + cj + ".gz"); }
    static int cellOf(double deg) { return (int) Math.floor(deg * 10.0 + 1e-9); }

    static int cachedCells(File base) { String[] a = dir(base).list(); int n = 0; if (a != null) for (String x : a) if (x.startsWith("c_")) n++; return n; }
    static long cacheBytes(File base) { long s = 0; File[] a = dir(base).listFiles(); if (a != null) for (File f : a) s += f.length(); return s; }

    // ---------------- مناطق التنزيل ----------------
    /** 0 الكويت، 1 الشرقية (الخفجي - الجبيل - الدمام)، 2 البحرين */
    static ArrayList<int[]> regionCells(int type) {
        ArrayList<int[]> out = new ArrayList<>();
        if (type == 0) {
            for (int ci = cellOf(28.5); ci <= cellOf(30.15); ci++) for (int cj = cellOf(46.5); cj <= cellOf(48.6); cj++) out.add(new int[] { ci, cj });
        } else if (type == 2) {
            for (int ci = cellOf(25.75); ci <= cellOf(26.35); ci++) for (int cj = cellOf(50.35); cj <= cellOf(50.85); cj++) out.add(new int[] { ci, cj });
        } else {
            double[][] line = { { 28.7, 48.30 }, { 28.43, 48.49 }, { 27.47, 48.50 }, { 27.02, 49.66 }, { 26.43, 50.10 }, { 26.2, 50.2 } };
            for (int ci = cellOf(26.0); ci <= cellOf(28.75); ci++) for (int cj = cellOf(48.0); cj <= cellOf(50.6); cj++) {
                double la = ci / 10.0 + 0.05, lo = cj / 10.0 + 0.05, best = 9e9;
                for (int k = 0; k + 1 < line.length; k++) best = Math.min(best, segDist(la, lo, line[k][0], line[k][1], line[k + 1][0], line[k + 1][1]));
                if (best <= 0.3) out.add(new int[] { ci, cj });
            }
        }
        return out;
    }

    private static double segDist(double py, double px, double ay, double ax, double by, double bx) {
        double dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy, t = L == 0 ? 0 : ((px - ax) * dx + (py - ay) * dy) / L;
        t = Math.max(0, Math.min(1, t));
        double qx = ax + t * dx, qy = ay + t * dy;
        return Math.hypot(px - qx, py - qy);
    }

    // ---------------- التنزيل ----------------
    private static InputStream open(String server, String query) throws IOException {
        String u = server + "?data=" + URLEncoder.encode(query, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(40000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        if (code != 200) { c.disconnect(); throw new IOException("HTTP " + code); }
        return new BufferedInputStream(c.getInputStream(), 65536);
    }

    private static final long[] badUntil = new long[3];
    private static final int[] srvFails = new int[3];
    private static volatile Prog curPg;
    static volatile String lastErr = "";

    /** السيرفرات مرتبة: السليمة أول، واللي فشل وايد ينحط آخر ويرتاح دقيقة */
    private static synchronized int[] srvOrder() {
        long now = System.currentTimeMillis();
        Integer[] o = { 0, 1, 2 };
        java.util.Arrays.sort(o, (x, y) -> {
            boolean bx = badUntil[x] > now, by = badUntil[y] > now;
            if (bx != by) return bx ? 1 : -1;
            return srvFails[x] - srvFails[y];
        });
        return new int[] { o[0], o[1], o[2] };
    }
    private static synchronized void srvOk(int i) { srvFails[i] = 0; badUntil[i] = 0; }
    private static synchronized void srvBad(int i) { if (++srvFails[i] >= 3) { badUntil[i] = System.currentTimeMillis() + 60000; srvFails[i] = 0; } }

    static File detailMark(File base, int ci, int cj) { return new File(dir(base), "d_" + ci + "_" + cj); }

    /** ينزّل خلية وحدة. detail=false: الطرق الرئيسية والمناطق (خفيف)، detail=true: شوارع الأحياء تنضاف للخلية */
    static void fetchCell(File base, int ci, int cj, boolean detail) throws IOException {
        double s = ci / 10.0, w = cj / 10.0, n = s + 0.1, e = w + 0.1;
        String q;
        if (detail) q = String.format(Locale.US, "[out:json][timeout:40];way[\"highway\"~\"^(unclassified|residential)$\"](%.4f,%.4f,%.4f,%.4f);out geom;", s, w, n, e);
        else q = String.format(Locale.US, "[out:json][timeout:30];(way[\"highway\"~\"^(motorway|motorway_link|trunk|trunk_link|primary|primary_link|secondary|secondary_link|tertiary|tertiary_link)$\"](%.4f,%.4f,%.4f,%.4f);"
                + "node[\"place\"~\"^(city|town|suburb|neighbourhood|village|quarter)$\"](%.4f,%.4f,%.4f,%.4f););out geom;", s, w, n, e, s, w, n, e);
        IOException last = null;
        for (int round = 0; round < 2; round++) {
            for (int si : srvOrder()) {
                try {
                    InputStream in = open(SERVERS[si], q);
                    Cell c;
                    try { c = parse(in); } finally { try { in.close(); } catch (IOException ignored) { } }
                    srvOk(si);
                    File f = cellFile(base, ci, cj);
                    if (detail) {
                        Cell old = readCell(f);
                        old.ways.addAll(c.ways);
                        writeCell(f, old);
                        detailMark(base, ci, cj).createNewFile();
                    } else writeCell(f, c);
                    return;
                } catch (IOException ex) {
                    last = ex; srvBad(si); lastErr = String.valueOf(ex.getMessage());
                    try { Thread.sleep(String.valueOf(ex.getMessage()).contains("429") ? 6000 : 2500); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new IOException("stopped"); }
                }
            }
        }
        throw last != null ? last : new IOException("فشل");
    }

    /** ينزّل خلايا المنطقة (4 خيوط بالتوازي). detail=true: شوارع الأحياء للخلايا اللي نزلت. يرجع عدد الفاشل */
    static int downloadCells(final File base, List<int[]> cells, final Prog pg, final AtomicBoolean stop, final boolean detail) {
        final int total = cells.size();
        final java.util.concurrent.atomic.AtomicInteger done = new java.util.concurrent.atomic.AtomicInteger(), fetched = new java.util.concurrent.atomic.AtomicInteger(), fail = new java.util.concurrent.atomic.AtomicInteger();
        final java.util.concurrent.ConcurrentLinkedQueue<int[]> q = new java.util.concurrent.ConcurrentLinkedQueue<>();
        for (int[] c : cells) {
            boolean have = cellFile(base, c[0], c[1]).exists();
            if (detail ? (!have || detailMark(base, c[0], c[1]).exists()) : have) { done.incrementAndGet(); continue; }
            q.add(c);
        }
        Thread[] th = new Thread[2];
        for (int t = 0; t < th.length; t++) {
            th[t] = new Thread(new Runnable() {
                @Override public void run() {
                    int[] c;
                    while (!stop.get() && (c = q.poll()) != null) {
                        try { fetchCell(base, c[0], c[1], detail); fetched.incrementAndGet(); }
                        catch (IOException e) { if (stop.get()) return; fail.incrementAndGet(); }
                        done.incrementAndGet();
                        if (pg != null) pg.p(done.get() + "/" + total + " خلية | جديد " + fetched.get() + (fail.get() > 0 ? " | فشل " + fail.get() + " (" + lastErr + ")" : ""));
                        try { Thread.sleep(1200); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
                    }
                }
            });
            th[t].start();
        }
        for (Thread t : th) { try { t.join(); } catch (InterruptedException e) { stop.set(true); } }
        if (pg != null) pg.p((stop.get() ? "⏹ توقف: " : "✓ انتهى: ") + done.get() + "/" + total + " خلية | جديد " + fetched.get() + (fail.get() > 0 ? " | فشل " + fail.get() + " (أعد المحاولة)" : "") + " | " + (cacheBytes(base) / 1048576) + " MB");
        return fail.get();
    }

    // ---------------- قراءة JSON (ستريم عشان الذاكرة) ----------------
    private static boolean ascii(String s) { for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 126) return false; return true; }

    private static Cell parse(InputStream in) throws IOException {
        Cell cell = new Cell();
        JsonReader r = new JsonReader(new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8), 65536));
        r.beginObject();
        while (r.hasNext()) {
            String nm = r.nextName();
            if (!nm.equals("elements")) { r.skipValue(); continue; }
            r.beginArray();
            while (r.hasNext()) readElement(r, cell);
            r.endArray();
        }
        return cell;
    }

    private static void readElement(JsonReader r, Cell cell) throws IOException {
        String type = "";
        long id = 0;
        double lat = 0, lon = 0;
        int[] gla = new int[0], glo = new int[0];
        String name = "", nameEn = "", ref = "", hw = "";
        r.beginObject();
        while (r.hasNext()) {
            String k = r.nextName();
            if (k.equals("type")) type = r.nextString();
            else if (k.equals("id")) id = r.nextLong();
            else if (k.equals("lat")) lat = r.nextDouble();
            else if (k.equals("lon")) lon = r.nextDouble();
            else if (k.equals("geometry")) {
                ArrayList<int[]> pts = new ArrayList<>();
                r.beginArray();
                while (r.hasNext()) {
                    if (r.peek() == JsonToken.NULL) { r.skipValue(); continue; }
                    double a = 0, b = 0;
                    r.beginObject();
                    while (r.hasNext()) { String kk = r.nextName(); if (kk.equals("lat")) a = r.nextDouble(); else if (kk.equals("lon")) b = r.nextDouble(); else r.skipValue(); }
                    r.endObject();
                    pts.add(new int[] { (int) Math.round(a * 100000.0), (int) Math.round(b * 100000.0) });
                }
                r.endArray();
                gla = new int[pts.size()]; glo = new int[pts.size()];
                for (int i = 0; i < gla.length; i++) { gla[i] = pts.get(i)[0]; glo[i] = pts.get(i)[1]; }
            } else if (k.equals("tags")) {
                r.beginObject();
                while (r.hasNext()) {
                    String tk = r.nextName();
                    if (tk.equals("name")) name = r.nextString();
                    else if (tk.equals("name:en")) nameEn = r.nextString();
                    else if (tk.equals("ref")) ref = r.nextString();
                    else if (tk.equals("highway")) hw = r.nextString();
                    else r.skipValue();
                }
                r.endObject();
            } else r.skipValue();
        }
        r.endObject();
        String nice = nameEn.length() > 0 ? nameEn : (ascii(name) ? name : "");
        if (nice.length() > 21) nice = nice.substring(0, 21);
        if (type.equals("way")) {
            if (gla.length < 2) return;
            Way w = new Way();
            w.id = id; w.name = nice; w.cls = clsOf(hw);
            int sc = ref.indexOf(';'); if (sc > 0) ref = ref.substring(0, sc);
            ref = ref.trim();
            w.ref = (ref.length() > 0 && ref.length() <= 6 && ascii(ref)) ? ref : "";
            int[][] sp = simplify(gla, glo, 3.0);
            w.la = sp[0]; w.lo = sp[1];
            if (w.la.length >= 2) cell.ways.add(w);
        } else if (type.equals("node") && nice.length() > 0) {
            Place p = new Place(); p.name = nice; p.la = (int) Math.round(lat * 100000.0); p.lo = (int) Math.round(lon * 100000.0);
            cell.places.add(p);
        }
    }

    static int clsOf(String hw) {
        if (hw.startsWith("motorway") || hw.startsWith("trunk")) return 3;
        if (hw.startsWith("primary") || hw.startsWith("secondary")) return 2;
        if (hw.startsWith("tertiary") || hw.equals("unclassified")) return 1;
        return 0;
    }

    // ---------------- تبسيط الخطوط (دوغلاس-بوكر) ----------------
    private static int[][] simplify(int[] la, int[] lo, double epsM) {
        int n = la.length;
        double cl = Math.cos(Math.toRadians(la[0] / 100000.0));
        double[] x = new double[n], y = new double[n];
        for (int i = 0; i < n; i++) { x[i] = lo[i] * 1.1132 * cl; y[i] = la[i] * 1.1132; }
        boolean[] keep = new boolean[n];
        keep[0] = true; keep[n - 1] = true;
        dp(x, y, 0, n - 1, epsM, keep);
        int m = 0; for (boolean b : keep) if (b) m++;
        int[] a = new int[m], b = new int[m];
        int j = 0; for (int i = 0; i < n; i++) if (keep[i]) { a[j] = la[i]; b[j] = lo[i]; j++; }
        return new int[][] { a, b };
    }

    private static void dp(double[] x, double[] y, int s, int e, double eps, boolean[] keep) {
        ArrayList<int[]> st = new ArrayList<>();
        st.add(new int[] { s, e });
        while (!st.isEmpty()) {
            int[] r = st.remove(st.size() - 1);
            int a = r[0], b = r[1];
            if (b <= a + 1) continue;
            double dx = x[b] - x[a], dy = y[b] - y[a], L = Math.hypot(dx, dy), best = -1; int bi = -1;
            for (int i = a + 1; i < b; i++) {
                double d = L < 1e-9 ? Math.hypot(x[i] - x[a], y[i] - y[a]) : Math.abs(dy * (x[i] - x[a]) - dx * (y[i] - y[a])) / L;
                if (d > best) { best = d; bi = i; }
            }
            if (best > eps) { keep[bi] = true; st.add(new int[] { a, bi }); st.add(new int[] { bi, b }); }
        }
    }

    // ---------------- تخزين الخلية ----------------
    private static void writeCell(File f, Cell c) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        DataOutputStream o = new DataOutputStream(new GZIPOutputStream(new FileOutputStream(tmp), 32768));
        try {
            o.writeInt(0x4D415001);
            o.writeInt(c.ways.size());
            for (Way w : c.ways) {
                o.writeLong(w.id); o.writeByte(w.cls); o.writeUTF(w.name); o.writeUTF(w.ref); o.writeShort(w.la.length);
                for (int i = 0; i < w.la.length; i++) { o.writeInt(w.la[i]); o.writeInt(w.lo[i]); }
            }
            o.writeInt(c.places.size());
            for (Place p : c.places) { o.writeUTF(p.name); o.writeInt(p.la); o.writeInt(p.lo); }
        } finally { o.close(); }
        if (!tmp.renameTo(f)) throw new IOException("ما انحفظ");
    }

    static Cell readCell(File f) {
        Cell c = new Cell();
        if (f == null || !f.exists()) return c;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new FileInputStream(f), 32768), 32768));
            try {
                if (in.readInt() != 0x4D415001) return c;
                int nw = in.readInt();
                for (int k = 0; k < nw; k++) {
                    Way w = new Way();
                    w.id = in.readLong(); w.cls = in.readByte(); w.name = in.readUTF(); w.ref = in.readUTF();
                    int n = in.readShort();
                    w.la = new int[n]; w.lo = new int[n];
                    for (int i = 0; i < n; i++) { w.la[i] = in.readInt(); w.lo[i] = in.readInt(); }
                    c.ways.add(w);
                }
                int np = in.readInt();
                for (int k = 0; k < np; k++) { Place p = new Place(); p.name = in.readUTF(); p.la = in.readInt(); p.lo = in.readInt(); c.places.add(p); }
            } finally { in.close(); }
        } catch (IOException ignored) { }
        return c;
    }

    // ---------------- المعالم: نجيب مواقعها من OSM بالاسم ----------------
    static File landmarkFile(File base) { return new File(base, "landmarks.csv"); }

    /** يرجع عدد المعالم اللي لقينا موقعها. السطر: رقم,la5,lo5 */
    static int locateLandmarks(File base, Prog pg, AtomicBoolean stop) {
        StringBuilder sb = new StringBuilder();
        int found = 0;
        for (int i = 0; i < LMS.length; i++) {
            if (stop.get()) break;
            String q = "[out:json][timeout:40];(nwr[\"name:en\"~\"" + LMS[i][1].replace("\"", "") + "\",i](28.4,46.4,30.3,48.7);nwr[\"name\"~\"" + LMS[i][2].replace("\"", "") + "\"](28.4,46.4,30.3,48.7););out center 3;";
            boolean ok = false;
            for (int t = 0; t < 3 && !ok; t++) {
                try {
                    String body = Feeds.get(SERVERS[t] + "?data=" + URLEncoder.encode(q, "UTF-8"), 50000);
                    org.json.JSONObject o = new org.json.JSONObject(body);
                    org.json.JSONArray a = o.optJSONArray("elements");
                    if (a != null && a.length() > 0) {
                        org.json.JSONObject e = a.getJSONObject(0);
                        double la, lo;
                        if (e.has("lat")) { la = e.getDouble("lat"); lo = e.getDouble("lon"); }
                        else { org.json.JSONObject c = e.getJSONObject("center"); la = c.getDouble("lat"); lo = c.getDouble("lon"); }
                        sb.append(i).append(',').append(Math.round(la * 100000.0)).append(',').append(Math.round(lo * 100000.0)).append('\n');
                        found++;
                    }
                    ok = true;
                } catch (Exception e) {
                    try { Thread.sleep(2500); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            }
            if (pg != null) pg.p("المعالم: " + (i + 1) + "/" + LMS.length + " | لقيت " + found);
            try { Thread.sleep(800); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
        }
        try {
            FileOutputStream fo = new FileOutputStream(landmarkFile(base));
            try { fo.write(sb.toString().getBytes(StandardCharsets.UTF_8)); } finally { fo.close(); }
        } catch (IOException ignored) { }
        if (pg != null) pg.p((stop.get() ? "⏹ " : "✓ ") + "المعالم: لقيت موقع " + found + " من " + LMS.length);
        return found;
    }

    static List<int[]> loadLandmarks(File base) {
        ArrayList<int[]> out = new ArrayList<>();
        File f = landmarkFile(base);
        if (!f.exists()) return out;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
            String ln;
            while ((ln = br.readLine()) != null) {
                String[] t = ln.split(",");
                if (t.length < 3) continue;
                try { out.add(new int[] { Integer.parseInt(t[0]), Integer.parseInt(t[1]), Integer.parseInt(t[2]) }); } catch (NumberFormatException ignored) { }
            }
            br.close();
        } catch (IOException ignored) { }
        return out;
    }

    // ---------------- تجهيز الخريطة للإطار ----------------
    static final class Item { int cls; float minD; String name, ref; float[] e, n; }
    static final class Built {
        ArrayList<String> lines = new ArrayList<>();
        ArrayList<Item> items = new ArrayList<>();
        ArrayList<int[]> missing = new ArrayList<>();
        int pts, ways;
        int la5, lo5;
    }
    static volatile Built last = null;

    static Built build(File base, double lat, double lon, List<int[]> lms, int maxLine, int budgetPts) {
        final double R = 2200.0, KEEP = R * 1.15;
        Built b = new Built();
        b.la5 = (int) Math.round(lat * 100000.0); b.lo5 = (int) Math.round(lon * 100000.0);
        double cl = Math.cos(Math.toRadians(lat)), dLat = KEEP / 111320.0, dLon = KEEP / (111320.0 * cl);
        HashSet<Long> seen = new HashSet<>();
        ArrayList<Item> items = new ArrayList<>();
        ArrayList<Place> places = new ArrayList<>();
        for (int ci = cellOf(lat - dLat - 0.0001); ci <= cellOf(lat + dLat); ci++) {
            for (int cj = cellOf(lon - dLon - 0.0001); cj <= cellOf(lon + dLon); cj++) {
                File f = cellFile(base, ci, cj);
                if (!f.exists()) { b.missing.add(new int[] { ci, cj }); continue; }
                Cell c = readCell(f);
                places.addAll(c.places);
                for (Way w : c.ways) {
                    if (!seen.add(w.id)) continue;
                    int n = w.la.length;
                    float[] e = new float[n], nn = new float[n];
                    for (int i = 0; i < n; i++) { e[i] = (float) ((w.lo[i] - b.lo5) * 1.1132 * cl); nn[i] = (float) ((w.la[i] - b.la5) * 1.1132); }
                    int s = -1;
                    for (int i = 0; i <= n; i++) {
                        boolean in = i < n && Math.abs(e[i]) <= KEEP && Math.abs(nn[i]) <= KEEP;
                        if (in && s < 0) s = i;
                        if ((!in || i == n) && s >= 0) {
                            int len = i - s;
                            if (len >= 2) {
                                float[] re = new float[len], rn = new float[len]; float md = 1e9f;
                                for (int k = 0; k < len; k++) { re[k] = e[s + k]; rn[k] = nn[s + k]; md = Math.min(md, (float) Math.hypot(re[k], rn[k])); }
                                if (!(w.cls == 0 && md > 1300) && md <= R + 300) {
                                    Item it = new Item(); it.cls = w.cls; it.minD = md; it.name = w.name; it.ref = w.ref; it.e = re; it.n = rn; items.add(it);
                                }
                            }
                            s = -1;
                        }
                    }
                }
            }
        }
        Collections.sort(items, new Comparator<Item>() {
            @Override public int compare(Item a, Item c) {
                int pa = a.cls >= 2 ? 0 : a.cls == 1 ? 1 : 2, pc = c.cls >= 2 ? 0 : c.cls == 1 ? 1 : 2;
                if (pa != pc) return pa - pc;
                return Float.compare(a.minD, c.minD);
            }
        });
        b.lines.add("mclr " + b.la5 + " " + b.lo5);
        int pts = 0;
        ArrayList<Item> used = new ArrayList<>();
        for (Item it : items) {
            if (pts + it.e.length > budgetPts) { if (it.cls >= 2) continue; else break; }
            pts += it.e.length; used.add(it);
            StringBuilder sb = new StringBuilder();
            int px = 0, py = 0, lx = 0, ly = 0;
            for (int k = 0; k < it.e.length; k++) {
                int x = Math.round(it.e[k]), y = Math.round(it.n[k]);
                if (sb.length() == 0) { sb.append("mway ").append(it.cls).append(' ').append(x).append(',').append(y); px = x; py = y; }
                else {
                    String tok = " " + (x - px) + "," + (y - py);
                    if (sb.length() + tok.length() > maxLine) { b.lines.add(sb.toString()); sb.setLength(0); sb.append("mway ").append(it.cls).append(' ').append(lx).append(',').append(ly); px = lx; py = ly; tok = " " + (x - px) + "," + (y - py); }
                    sb.append(tok); px = x; py = y;
                }
                lx = x; ly = y;
            }
            if (sb.length() > 0) b.lines.add(sb.toString());
            b.ways++;
        }
        b.pts = pts; b.items = used;
        // أرقام الطرق: كل رقم بأكثر من مكان بينهم 700م على الأقل
        HashMap<String, ArrayList<float[]>> refs = new HashMap<>();
        int nref = 0;
        for (Item it : used) {
            if (it.ref.length() == 0 || it.cls < 2) continue;
            int m = it.e.length / 2; float x = it.e[m], y = it.n[m];
            ArrayList<float[]> l = refs.get(it.ref); if (l == null) { l = new ArrayList<>(); refs.put(it.ref, l); }
            boolean far = true; for (float[] q : l) if (Math.hypot(q[0] - x, q[1] - y) < 700) far = false;
            if (far && l.size() < 3 && nref < 18) { l.add(new float[] { x, y }); nref++; b.lines.add("mlbl 1 " + Math.round(x) + " " + Math.round(y) + " " + it.ref); }
        }
        int np = 0;
        HashSet<String> pn = new HashSet<>();
        for (Place p : places) {
            double e = (p.lo - b.lo5) * 1.1132 * cl, n = (p.la - b.la5) * 1.1132;
            if (Math.abs(e) > 3000 || Math.abs(n) > 3000 || np >= 20 || !pn.add(p.name)) continue;
            b.lines.add("mlbl 0 " + Math.round(e) + " " + Math.round(n) + " " + p.name); np++;
        }
        if (lms != null) for (int[] m : lms) {
            double e = (m[2] - b.lo5) * 1.1132 * cl, n = (m[1] - b.la5) * 1.1132;
            if (Math.abs(e) <= 2800 && Math.abs(n) <= 2800) b.lines.add("mlm " + m[0] + " " + Math.round(e) + " " + Math.round(n));
        }
        b.lines.add("mdone");
        return b;
    }

    /** اسم الشارع الحالي من آخر خريطة جهزناها (أقرب شارع له اسم ضمن 35م) */
    static String streetAt(Built b, double lat, double lon) {
        if (b == null) return "";
        double cl = Math.cos(Math.toRadians(lat));
        double px = (lon * 100000.0 - b.lo5) * 1.1132 * cl, py = (lat * 100000.0 - b.la5) * 1.1132;
        double best = 35; String nm = "";
        for (Item it : b.items) {
            if (it.name.length() == 0) continue;
            for (int k = 0; k + 1 < it.e.length; k++) {
                double d = segDist(py, px, it.n[k], it.e[k], it.n[k + 1], it.e[k + 1]) - it.cls * 3.0;
                if (d < best) { best = d; nm = it.name; }
            }
        }
        return nm;
    }
}
